
public class ContaTeste {
	void deposita() throws MinhaExcecao{
		
	}
	
}
