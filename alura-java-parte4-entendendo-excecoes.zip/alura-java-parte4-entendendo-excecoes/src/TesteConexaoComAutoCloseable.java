
public class TesteConexaoComAutoCloseable {
	
	public static void main(String[] args) {
		
		//a partir do java 1.7
		//(o try-with-resources.)
		try (Conexao con = new Conexao()) {			 
			con.leDados();
		} catch(IllegalStateException e) {
			System.out.println("deu erro na conexao");
			e.printStackTrace();
		}		
	}

}
