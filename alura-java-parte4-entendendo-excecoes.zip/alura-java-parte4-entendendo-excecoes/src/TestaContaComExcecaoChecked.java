
public class TestaContaComExcecaoChecked {
	public static void main(String[] args) {
		ContaTeste c = new ContaTeste();
		try {
			c.deposita();
		} catch (MinhaExcecao e) {
			System.out.println("tratamento");
		}
	}
}
