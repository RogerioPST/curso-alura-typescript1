package br.com.rog.Conta;

public class TesteSacaComException {
public static void main(String[] args) {
	Conta conta = new ContaCorrente(123, 475);
	
	conta.deposita(200);
	try {
		
		conta.saca(210);
	} catch(SaldoInsuficienteException e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
	}
	
	System.out.println(conta.getSaldo());
	
}
}
