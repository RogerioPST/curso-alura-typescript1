var appe = require('./config/custom-express')();

appe.listen(3000, function(){
    console.log('servidor rodando na porta 3000');
});

