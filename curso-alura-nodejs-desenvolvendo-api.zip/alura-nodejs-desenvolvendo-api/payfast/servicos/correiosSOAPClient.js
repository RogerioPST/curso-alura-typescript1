var soap = require('soap');

function CorreiosSOAPClient(){
    this._url = 'http://ws.correios.com.br/calculador/CalcPrecoPrazo.asmx?wsdl';
}

module.exports = function(){
    return CorreiosSOAPClient;
}
//consumindo o ws dos correios
// ao inves de receber o retorno, vai receber o cliente dentro da funcao de callback
// sempre q invoca uma op, sempre tenho q fazer um get do wsdl antes
//se sempre vai tem q consultar, n tem pq invocar em outro lugar.

CorreiosSOAPClient.prototype.calculaPrazo= function(args, callback){

    soap.createClient(this._url,
        function(erro, cliente){
            console.log('cliente soap criado');
            //as fuincoes ficam disponiveis dentro do cliente - calPrazo, por ex
            //a propria lib soap vai converter o json p xml
            cliente.CalcPrazo( args, callback);
        });
}
