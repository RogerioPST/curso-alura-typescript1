var express = require('express');

var consign = require('consign');

var bodyParser = require('body-parser');

var expressValidator = require('express-validator');

// morgan - fornece um meio para integrar com o log -  trabalha muito bem com o express
// intercepta a requisição e abre o filtro para a gente escrever o log como middleware, por ex.
var morgan = require('morgan');

var logger = require('../servicos/logger.js');

module.exports = function(){
    var app = express();

    //common é o formato def pelo padrão apache de log
    app.use(morgan("common", {
        stream: {
            write: function(mensagem){
                logger.info(mensagem);
            }
        }
    }));

    app.use(bodyParser.urlencoded({extended: true}));
    app.use(bodyParser.json());    
    app.use(expressValidator());

    consign()
        .include('controllers')
        .then('persistencia')
        .then('servicos')
        //a partir do app, consigo navegar pelos diretorios
        .into(app);

    return app;
}

