var logger = require('../servicos/logger.js');

module.exports = function(app){
    app.get('/pagamentos', function(req, res){
        console.log('recebida req teste na porta 3000');
        res.send('ok');
    });

    app.get('/pagamentos/pagamento/:id', function(req, res){
      var id = req.params.id;
      console.log('consultando pagamento:' + id);
      logger.info('consultando pagamento:' + id);

      var memcachedClient = app.servicos.memcachedClient();

      memcachedClient.get('pagamento-'+ id, function(erro, retorno){
        if(erro || !retorno){
            console.log('MISS - chave n encontrada');

            //a partir dA VARIAVEL app (e por causa do uso do consign com o app), consigo navegar pelos diretorios
            var connection = app.persistencia.connectionFactory();
            var pagamentoDao = new app.persistencia.PagamentoDao(connection);

            pagamentoDao.buscaPorId(id, function(erro, resultado){
              if(erro){
                console.log('erro ao consultar no banco: '+ erro);
                res.status(500).send(erro);
                return;
              }
              //JSON.stringify(resultado) - usar assim qdo concatenar o obj json com string
              console.log('pagamento encontrado: '+ JSON.stringify(resultado));
              res.status(200).json(resultado);
              return;
            });
        } else{
            console.log('HIT - valor: '+ JSON.stringify(retorno));
            res.status(200).json(retorno);
            return;
        }
    
    });

      

    });

    app.delete('/pagamentos/pagamento/:id', function(req, res){
      var id = req.params.id;
      
      var pagamento ={};
      pagamento.id = id;
      pagamento.status = 'CANCELADO';

      //a partir dA VARIAVEL app (e por causa do uso do consign com o app), consigo navegar pelos diretorios
      var connection = app.persistencia.connectionFactory();
      var pagamentoDao = new app.persistencia.PagamentoDao(connection);

      pagamentoDao.atualiza(pagamento, function(erro){
        if (erro){
          res.status(500).send(erro);
          return;
        }
        console.log('Pgto cancelado');
        //204 - no content
        res.status(204).send(pagamento);

      });      

    });

    app.put('/pagamentos/pagamento/:id', function(req, res){
      var id = req.params.id;
      
      var pagamento ={};
      pagamento.id = id;
      pagamento.status = 'CONFIRMADO';

      //a partir dA VARIAVEL app (e por causa do uso do consign com o app), consigo navegar pelos diretorios
      var connection = app.persistencia.connectionFactory();
      var pagamentoDao = new app.persistencia.PagamentoDao(connection);

      pagamentoDao.atualiza(pagamento, function(erro){
        if (erro){
          res.status(500).send(erro);
          return;
        }
        console.log('Pgto confirmado');
        res.send(pagamento);

      });      
    });

    app.post('/pagamentos/pagamento', function(req, res){
        // o express-validator torna possivel que o assert, ja presente n node, seja invocado a partir do request
        req.assert("pagamento.forma_de_pagamento", "Forma de pgto eh obrigatoria").notEmpty();
        req.assert("pagamento.valor", "valor obrigatorio e deve ser decimal" ).notEmpty().isFloat();
        req.assert("pagamento.moeda", "Moeda é valor obrigatorio e deve ter 3 caracteres" ).notEmpty().len(3,3);

        var erros = req.validationErrors();

        if (erros){
            console.log('erros de validacao encontrados');
            res.status(400).send(erros);
            return;
        }
       

        var pagamento = req.body["pagamento"];
        console.log('LOG: ',pagamento);
        console.log('processando uma requisição de um novo pagamento');
        

        pagamento.status = 'CRIADO';
        pagamento.data = new Date;

        console.log('LOG: ',pagamento);
        //a partir dA VARIAVEL app (e por causa do uso do consign com o app), consigo navegar pelos diretorios
        var connection = app.persistencia.connectionFactory();
        var pagamentoDao = new app.persistencia.PagamentoDao(connection);


        pagamentoDao.salva(pagamento, function(erro, resultado){
            if(erro){
              console.log('Erro ao inserir no banco:' + erro);
              res.status(500).send(erro);
            } else {
              pagamento.id = resultado.insertId;
              console.log('pagamento criado');

              var memcachedClient = app.servicos.memcachedClient();
              memcachedClient.set('pagamento-'+pagamento.id, pagamento, 60000, function(erro){
                console.log('nova chave adicionada ao cache: pagamento-' + pagamento.id);
            });

              if(pagamento.forma_de_pagamento == "cartao"){
                var cartao = req.body["cartao"];
                console.log(cartao);

                var clienteCartoes = new app.servicos.clienteCartoes();
                
                // o retorno eh a invocação do post do clienteCartoes.js
                clienteCartoes.autoriza(cartao, function(exception, request, response, retorno){
                  if (exception){
                    console.log(exception);
                    res.status(400).send(exception);
                    return;
                  }
                  // loga o retorno do serviço de cartoes    
                  console.log(retorno);



                  res.location('/pagamentos/pagamento/' +
                    pagamento.id);
                  
                    var response = {
                      dados_do_pagamento: pagamento, 
                      cartao: retorno,
                      links: [
                        {
                          href: "http://localhost:3000/pagamentos/pagamento/" + pagamento.id,
                          rel: "confirmar",
                          method: "PUT"
                        },
                        {
                          href: "http://localhost:3000/pagamentos/pagamento/" + pagamento.id,
                          rel: "cancelar",
                          method: "DELETE"
                        }
                      ]
                    }

                  res.status(201).json(response);
                  return;
                });
                
              } else{
                res.location('/pagamentos/pagamento/' +
                    pagamento.id);
              //hypermedia = verbo + recurso = operação rest  
              //                   + headers 
              //                   + body
              //                   + parametros
              //                   + hyperlinks  
              //informar ao usuario os prox possiveis caminhos no proprio body  ==  HATEOAS
              //HATEOAS eh usar o proprio hypermedia p usar essa def p quem está consumindo o nosso serviço
              var response = {
                dados_do_pagamento: pagamento, 
                links: [
                  {
                    href: "http://localhost:3000/pagamentos/pagamento/" + pagamento.id,
                    rel: "confirmar",
                    method: "PUT"
                  },
                  {
                    href: "http://localhost:3000/pagamentos/pagamento/" + pagamento.id,
                    rel: "cancelar",
                    method: "DELETE"
                  }
                ]
              }
        
              res.status(201).json(response);
              }
          }});
          

        //pagamentoDao.salva(pagamento, function(erro, resultado){
         //   console.log('pgto criado pelo mysql');
          //  res.json(pagamento);
        //});

        //res.send(pagamento);
        //res.json(pagamento);
    });

}