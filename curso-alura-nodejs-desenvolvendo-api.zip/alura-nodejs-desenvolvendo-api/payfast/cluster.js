var cluster = require('cluster');

var os = require('os');

var cpus = os.cpus();

//console.log('cpus:'+ JSON.stringify(cpus));


console.log('executando thread');

if(cluster.isMaster){
    console.log('exec thread master');

    cpus.forEach(function(){
        // cluster.fork() = cria uma nova thread - filha/slave
        //a função desse nó é executar o arquivo do qual ele foi criado
        cluster.fork();
    });

    cluster.on('listening', function(worker){
        console.log('cluster conectado: ' + JSON.stringify(worker.process.pid));
    });

    cluster.on('exit', worker => {
        console.log('cluster %d desconectado', worker.process.pid);
        cluster.fork();
    });


} else{
    console.log(   'thread slave');
    //Cada slave que surge deve somente ser responsável por iniciar o a aplicação de fato, invocando o arquivo index.js.
    // como se executasse novamente node index.js para cada cluster slave
    require('./index.js');
}