var fs = require('fs');

//arquivo vem via parametro do comando da linha de comando
var arquivo = process.argv[2];

fs.readFile(arquivo, function(error, buffer){
    console.log("arquivo lido");
    console.log(buffer);

    fs.writeFile('2'+arquivo, buffer, function(err){
        console.log('arquivo escrito');
    });
});