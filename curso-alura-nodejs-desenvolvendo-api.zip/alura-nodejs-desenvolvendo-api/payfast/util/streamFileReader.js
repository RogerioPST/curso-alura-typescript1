var fs = require('fs');

//arquivo vem via parametro do comando da linha de comando
var arquivo = process.argv[2];

fs.createReadStream(arquivo)
    .pipe(fs.createWriteStream('novo-'+arquivo))
    .on('finish', function(){
        console.log('arquivo escrito com stream');
    });
    