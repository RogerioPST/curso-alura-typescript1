var mysql = require('mysql');

function createDBConnection() {
    const con = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'Rogerio&123456',
        database: 'payfast',
        port: 3306
    });

con.connect(function (err) {
    if (err) throw err;
    console.log("----[LOG] Conectado ao banco...");
});

return con;
}

module.exports = function () {
    return createDBConnection;
}