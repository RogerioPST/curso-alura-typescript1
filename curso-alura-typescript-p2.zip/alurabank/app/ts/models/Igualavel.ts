export interface Igualavel<T> {

    ehIgual(objeto: T): boolean;
}

