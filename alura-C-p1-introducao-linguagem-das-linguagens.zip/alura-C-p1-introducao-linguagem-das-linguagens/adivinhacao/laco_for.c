#include <stdio.h>

int main(){
    //imprime o cabecalho do nosso jogo
    for (int i =1; i<101; i++){
        printf("o resultado foi %d \n", i);

    }
}

