//diretiva include 
//header file
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
//diretiva define para definir constantes
//#define NUMERO_DE_TENTATIVAS 5

int main()
{
    //imprime o cabecalho do nosso jogo
    printf("**************************************\n");
    printf("bem vindo ao nosso jogo de adivinhação\n");
    printf("**************************************\n");

    int segundos = time(0); //devolve o epoch
    //passo o epoch como semente para funcao srand (seed rand), 
    //pois rand usa esse srand p gerar o numero randomico
    srand(segundos); 


    //gera um numero aleatorio a partir da semente do srand.
    int numeroGrande = rand();

    //na matematica, um truque para pegar um numero entre 0 e 101, por exemplo, 
    //eh pegar o resta da divisao de um numero por 101 
    int numeroSecreto = numeroGrande % 100; 

    int chute;

    
    int ganhou = 0;
    int tentativas = 1;

    double pontos = 1000;

    int acertou = 0;

    int nivel;
    printf("qual o nivel de dificuldade?\n");
    printf("(1) Facil (2) Medio (3) Dificil\n\n");
    printf("Escolha: ");
    scanf("%d", &nivel);

    int numeroDeTentativas;
    if (nivel ==1){
        numeroDeTentativas = 20;
    } else if (nivel ==2){
        numeroDeTentativas = 15;
    } else{
        numeroDeTentativas = 6;
    }

    for (int i=1; i<=numeroDeTentativas; i++){
    //while (1)
    //{
        //while(ganhou ==0){

        //printf("tentativa %d de %d:\n", i, numeroDeTentativas);
        printf("tentativa %d :\n", tentativas);
        printf("qual eh o seu chute?\n");

        scanf("%d", &chute);
        //%d - eh a mascara
        printf("seu chute foi %d \n", chute);
        if (chute < 0)
        {
            printf("vc n pode chutar numeros negativos!\n");
            //i--;
            continue;
        }

        acertou = (chute == numeroSecreto); //devolve 1 para se forem iguais e 0 para diferentes
        int maior = chute > numeroSecreto;
        //int menor = chute < numeroSecreto;

        if (acertou)
        {
            
            //break;
            //ganhou = 1;
            break;
        }
        else if (maior)
        {
            printf("chute maior que numero secreto");
        }
        else
        {
            printf("chute menor");
        }

        tentativas++;
        //Precisamos fazer o casting para que a operação aritmética seja feita com ponto flutuante. Senão, a divisão será feita inteira, e não teremos casas decimais.
        //double pontosperdidos = (chute - numeroSecreto)/2.0;
        //a funcao abs devolve sempre o valor positivo
        double pontosperdidos = abs(chute - numeroSecreto)/(double)2; //casting
        //double pi = 3.1415
        //int piConvertido = (int) pi; //=3;
        pontos -= pontosperdidos;
    }

    if (acertou){
        printf("parabens. vc acertou");
        printf("vc acertou em %d tentativas\n", tentativas);
        printf("Total de pontos: %.1f \n",pontos); //%.1f - 1 casa decimal
    }else{
        printf("vc perdeu. tente de novo \n");
    }
    
}

