#include <stdio.h>

int main(){
    //imprime o cabecalho do nosso jogo
    int i = 1;
    while(i<=100){
        printf("o resultado foi %d \n", i);
        i++;

    }
}

