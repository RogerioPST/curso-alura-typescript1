#include <stdio.h>

int main(){
    //imprime o cabecalho do nosso jogo
    printf("**************************************\n");
    printf("multiplicacao\n");
    printf("**************************************\n");
    int n1, n2, resultado;


    printf("digite duas variaveis para ver a multiplicacao!!\n");

    scanf("%d", &n1);
    scanf("%d", &n2);

    resultado = n1 * n2;

    //%d - eh a mascara
    printf("o resultado foi %d \n", resultado);
}

