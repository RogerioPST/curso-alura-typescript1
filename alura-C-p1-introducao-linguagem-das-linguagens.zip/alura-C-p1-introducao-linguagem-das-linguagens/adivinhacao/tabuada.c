#include <stdio.h>
#include <time.h>
#include <stdlib.h>

//#define TABUADA 2

int main(){

    int segundos = time(0);

    srand(segundos);

    int numeroAleatorio = rand() % 10;

    for (int i =1; i<=10;i++ ){
        int resultado = numeroAleatorio * i;
        printf("%d * %d = %d\n", numeroAleatorio, i, resultado);
    }    
}

