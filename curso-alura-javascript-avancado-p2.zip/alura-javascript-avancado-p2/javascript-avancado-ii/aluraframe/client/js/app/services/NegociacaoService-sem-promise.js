class NegociacaoService{
    /*
    callback abaixo eh toda essa funcao aqui:
    (erro, negociacoes) => {
            if(erro){
                this._mensagem.texto = erro;
                return;
            } 

            negociacoes.forEach(negociacao => this._listaNegociacoes.adiciona(negociacao));
            this._mensagem.texto = "Negociacoes importadas com sucesso";
        }
    */
    obterNegociacoesDaSemana(callback){
        let xhr = new XMLHttpRequest();

        xhr.open('GET', 'negociacoes/semana');
        //Uma requisição passa por estados, por isso o nome da propriedade em português é pronto para mudança de estado. Podemos passar uma função que verifica os estados e executará uma ação
        xhr.onreadystatechange = () => {
            /*
            status de uma requisição ajax
            0 - req ainda n iniciada
            1 - conexao com o servidor estabelecida
            2 - req recebida
            3 - processando req
            4 - req concluida e a resposta estah pronta
            */

            if (xhr.readyState ==4){
                if (xhr.status == 200){
                    console.log('obtendo as neg');
                    console.log(xhr.responseText);
                    console.log(JSON.parse(xhr.responseText));

                    callback(null, 
                    JSON.parse(xhr.responseText)
                        .map(objeto => {
                            console.log('objeto: ', objeto.data);
                            
                            let neg = new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor);
                            console.log('neg: ', neg);
                            return neg;
                        }));
                        
                        
                    
                } else{
                    
                    
                    console.log(xhr.responseText);
                    callback('nao foi possivel obter as negociacoes do servidor', null);
                }
                
            }
        };

        xhr.send();
    }

    obterNegociacoesDaSemanaAnterior(cb) {

        let xhr = new XMLHttpRequest();
        xhr.open('GET', 'negociacoes/anterior');
        xhr.onreadystatechange = () => {
            if(xhr.readyState == 4) {
                if(xhr.status == 200) {
  
                  cb(null, JSON.parse(xhr.responseText)
                        .map(objeto => new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor)));
  
                } else {
                    console.log(xhr.responseText);
                    cb('Não foi possível obter as negociações da semana', null);
                }  
            }
        }
  
        xhr.send();
    }

    obterNegociacoesDaSemanaRetrasada(cb) {

        let xhr = new XMLHttpRequest();
        xhr.open('GET', 'negociacoes/retrasada');
        xhr.onreadystatechange = () => {
            if(xhr.readyState == 4) {
                if(xhr.status == 200) {
  
                  cb(null, JSON.parse(xhr.responseText)
                        .map(objeto => new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor)));
  
                } else {
                    console.log(xhr.responseText);
                    cb('Não foi possível obter as negociações da semana', null);
                }  
            }
        }
  
        xhr.send();
    }
  }  

