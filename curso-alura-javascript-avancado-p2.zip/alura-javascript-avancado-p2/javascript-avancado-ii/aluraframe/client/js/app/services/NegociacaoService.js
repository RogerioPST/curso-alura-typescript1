class NegociacaoService{    
    constructor(){
        this._http = new HttpService();
    }

    obterNegociacoes() {

        return Promise.all([
            this.obterNegociacoesDaSemana(),
            this.obterNegociacoesDaSemanaAnterior(),
            this.obterNegociacoesDaSemanaRetrasada()
        ]).then(periodos => {

            let negociacoes = periodos
                .reduce((dados, periodo) => dados.concat(periodo), []);

            return negociacoes;

        }).catch(erro => {
            throw new Error(erro);
        });

    } 

    obterNegociacoesDaSemana() {
      
//A ideia é a seguinte, se uma função then possui um retorno, este retorno é acessível para quem encadear uma nova chamada à função then. Sendo assim, onde há resolve trocaremos por um return. Mas cuidado, não esqueça de remover também os () do resolve!
        

            return this._http
                .get('negociacoes/semana')
                .then(negociacoes => {
                    return negociacoes.map(objeto => new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor));
                })
                .catch(erro => {
                    console.log(erro);
                    return 'Não foi possível obter as negociações da semana';
                    //ou lanço erro // throw new Error('Não foi possível obter as negociações da semana');
                })
       
    }

   
    obterNegociacoesDaSemanaAnterior() {

        
    
            return this._http
                .get('negociacoes/anterior')
                .then(negociacoes => {
                    console.log(negociacoes);
                    return negociacoes.map(objeto => new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor));
    
                })
                .catch(erro => {
                    console.log(erro);
                    return 'Não foi possível obter as negociações da semana anterior';
                    //ou lanço erro // throw new Error('Não foi possível obter as negociações da semana');
                })
        
    }
    
    obterNegociacoesDaSemanaRetrasada() {
        //A ideia é a seguinte, se uma função then possui um retorno, este retorno é acessível para quem encadear uma nova chamada à função then. Sendo assim, onde há resolve trocaremos por um return. Mas cuidado, não esqueça de remover também os () do resolve!

        //Mas ainda não acabou! E se um erro acontecer? No lugar de usarmos reject, lançamos uma exceção em seu lugar:
  
    
            return this._http
                .get('negociacoes/retrasada')
                .then(negociacoes => {
                    console.log(negociacoes);
                    return negociacoes.map(objeto => new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor));
    
                })
                .catch(erro => {
                    console.log(erro);
                    
                    return 'Não foi possível obter as negociações da semana retrasada';
                    //ou lanço erro // throw new Error('Não foi possível obter as negociações da semana');
                })
        
    }
  }  


