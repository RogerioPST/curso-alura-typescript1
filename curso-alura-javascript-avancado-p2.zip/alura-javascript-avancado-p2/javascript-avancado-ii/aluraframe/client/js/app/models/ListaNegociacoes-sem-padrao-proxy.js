class ListaNegociacoes{
    constructor(armadilha){
        this._negociacoes = [];
        //armadilha sao funcoes passadas pelo construtor da classe q serao executadas toda vez q chamarmos adicona e esvazia
        //para atualizar a view
        this._armadilha = armadilha;
        // esse codigo abaixo funciona sem usar arrow function!
        // com arrow function, como muda o esopo lexico de this, n precisamos desse codigo abaixo.
        //mas nesse caso, tem q passar o contexto no construtor
        //this._contexto = contexto;

    }

    adiciona(negociacao){
        this._negociacoes.push(negociacao);

        this._armadilha(this);
        // esse codigo abaixo funciona sem usar arrow function!
        // com arrow function, como muda o esopo lexico de this, n precisamos desse codigo abaixo.
        //primeiro parametro, - o metodo q quero executar
        //segundo parametro - o contexto (this) q quero executar
        //terceiro parametro - parametros, no caso, a propria lista = this
        //Reflect.apply(this._armadilha, this._contexto, [this] );
    }

    get negociacoes(){
        //esse eh um truque de programação defensiva = return [].concat(this._negociacoes);
        //pois vai criar uma copia da lista e não vai mexer na original.
        return [].concat(this._negociacoes);
    }

    esavazia(){
        this._negociacoes =[];
        this._armadilha(this);
        // esse codigo abaixo funciona sem usar arrow function!
        // com arrow function, como muda o esopo lexico de this, n precisamos desse codigo abaixo.
        //Reflect.apply(this._armadilha, this._contexto, [this] );
    }
}