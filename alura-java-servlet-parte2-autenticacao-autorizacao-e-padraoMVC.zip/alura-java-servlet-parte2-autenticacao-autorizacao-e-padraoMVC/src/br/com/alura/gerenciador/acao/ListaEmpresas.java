package br.com.alura.gerenciador.acao;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.alura.gerenciador.modelo.Banco;

public class ListaEmpresas implements Acao {

	public String executa(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {				
		
		
		
		Banco lista = new Banco();

		System.out.println("listando empresas: ");
		System.out.println("JSessionID:" + request.getSession().getId());		

		request.setAttribute("empresas", lista.getEmpresas());
		
		
		
		return "forward:listaEmpresas.jsp";

//		PrintWriter out = response.getWriter();
//		
//		out.println("<html>");
//		out.println("<body>");
//		out.println("<ul>");
//		for (Empresa empresa : lista.getEmpresas()) {
//			out.println("<li>empresa cadastrada: " + empresa.getNome() + "</li>");
//		}
//		out.println("</ul>");
//		out.println("</html>");
	}

}
