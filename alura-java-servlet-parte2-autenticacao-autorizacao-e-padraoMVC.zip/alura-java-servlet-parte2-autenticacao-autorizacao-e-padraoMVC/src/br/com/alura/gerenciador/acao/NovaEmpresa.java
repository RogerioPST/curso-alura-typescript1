package br.com.alura.gerenciador.acao;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.alura.gerenciador.modelo.Banco;
import br.com.alura.gerenciador.modelo.Empresa;
import br.com.alura.gerenciador.modelo.IdNaoExisteException;

public class NovaEmpresa implements Acao {

	public String executa(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nome = request.getParameter("nome");
		String dataEmpresa = request.getParameter("data");
		Date dataAbertura = null;

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			dataAbertura = sdf.parse(dataEmpresa);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServletException(e);
		}

		System.out.println("cadastrando nova empresa: " + nome);

		Empresa empresa = new Empresa();

		empresa.setNome(nome);
		empresa.setDataAbertura(dataAbertura);

		Banco banco = new Banco();
		banco.adiciona(empresa);

//		PrintWriter out = response.getWriter();
//		out.println("<html>");
//		out.println("<body>");
//		out.println("empresa cadastrada: " + nome);
//		out.println("</html>");
		request.setAttribute("empresa", empresa.getNome());
		/*
		 * Nessa aula aprendemos: o problema de reenviar uma requisi��o a diferen�a
		 * entre redirecionamento pelo cliente e servidor para redirecionar pelo
		 * navegador usamos o m�todo response.sendRedirect("endere�o") o c�digo de
		 * resposta para redirecionamento HTTP � 30X (301 ou 302)
		 * 
		 */
		return "redirect:entrada?acao=ListaEmpresas";

//		RequestDispatcher rd = request.getRequestDispatcher("/listaEmpresas");
//		request.setAttribute("empresa", empresa.getNome());
//		rd.forward(request, response);
	}

}
