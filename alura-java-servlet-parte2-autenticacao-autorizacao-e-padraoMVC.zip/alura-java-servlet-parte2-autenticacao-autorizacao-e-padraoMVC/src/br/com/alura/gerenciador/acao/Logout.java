package br.com.alura.gerenciador.acao;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.alura.gerenciador.modelo.Banco;
import br.com.alura.gerenciador.modelo.Usuario;

public class Logout implements Acao {

	public String executa(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession sessao = request.getSession();
		
		
		//sessao.removeAttribute("usuarioLogado");
		//remove todos os atributos e tb remove o cookie
		sessao.invalidate();
		

		return "redirect:entrada?acao=LoginForm";

//		PrintWriter out = response.getWriter();
//		
//		out.println("<html>");
//		out.println("<body>");
//		out.println("<ul>");
//		for (Empresa empresa : lista.getEmpresas()) {
//			out.println("<li>empresa cadastrada: " + empresa.getNome() + "</li>");
//		}
//		out.println("</ul>");
//		out.println("</html>");
	}

}
