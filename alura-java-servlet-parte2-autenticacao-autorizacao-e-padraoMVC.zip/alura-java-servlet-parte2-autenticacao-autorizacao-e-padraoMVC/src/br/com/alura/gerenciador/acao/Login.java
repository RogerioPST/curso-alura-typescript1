package br.com.alura.gerenciador.acao;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.alura.gerenciador.modelo.Banco;
import br.com.alura.gerenciador.modelo.Usuario;

public class Login implements Acao {

	public String executa(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		String login = request.getParameter("login");
		String senha = request.getParameter("senha");
		
		System.out.println("logado :" + login);
		
		Banco banco = new Banco();
		
		Usuario usuario = banco.existeUsuario(login,senha);
		
		if (usuario != null) {
			System.out.println("usuario existe");
			
			System.out.println("JSessionID:" + request.getSession().getId());			
			HttpSession sessao = request.getSession();			
			sessao.setAttribute("usuarioLogado", usuario);
			
			return "redirect:entrada?acao=ListaEmpresas";
		} else {
			return "redirect:entrada?acao=LoginForm";
		}
		
		
		
		
		

		
		

//		PrintWriter out = response.getWriter();
//		
//		out.println("<html>");
//		out.println("<body>");
//		out.println("<ul>");
//		for (Empresa empresa : lista.getEmpresas()) {
//			out.println("<li>empresa cadastrada: " + empresa.getNome() + "</li>");
//		}
//		out.println("</ul>");
//		out.println("</html>");
	}

}
