package br.com.alura.gerenciador.servlet;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.alura.gerenciador.acao.Acao;

//@WebFilter(urlPatterns = "/entrada") // = @WebServlet("/entrada")
public class ControladorFilter implements Filter {
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	
	}
	
	@Override
	public void destroy() {
		
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		
		System.out.println("ControladorFilter");
		
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		
		
		String paramAcao = request.getParameter("acao");
		
System.out.println("JSessionID:" + request.getSession().getId());
		
		

		System.out.println(paramAcao);
		
		String nomeDaClasse = "br.com.alura.gerenciador.acao." +  paramAcao;
		
		String redirecionaPara;
		try {
			Class classe = Class.forName(nomeDaClasse);
			Object obj = classe.newInstance();		
			Acao acao = (Acao) obj;
			redirecionaPara = acao.executa(request, response);
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			throw new ServletException(e);
		}
		
		
		

//		if (paramAcao.equals("listaEmpresas")) {
//			System.out.println("listando empresas");
//			ListaEmpresas acao = new ListaEmpresas();
//			redirecionaPara = acao.executa(request, response);
//
//		} else if (paramAcao.equals("removeEmpresa")) {
//			System.out.println("removendo empresas");
//			RemoveEmpresa acao = new RemoveEmpresa();
//			redirecionaPara = acao.executa(request, response);
//		} else if (paramAcao.equals("mostraEmpresa")) {
//			System.out.println("mostrando empresas");
//			MostraEmpresa acao = new MostraEmpresa();
//			redirecionaPara = acao.executa(request, response);
//		} else if (paramAcao.equals("alteraEmpresa")) {
//			System.out.println("alterando empresas");
//			AlteraEmpresa acao = new AlteraEmpresa();
//			redirecionaPara = acao.executa(request, response);
//		} else if (paramAcao.equals("novaEmpresa")) {
//			System.out.println("nova empresas");
//			NovaEmpresa acao = new NovaEmpresa();
//			redirecionaPara = acao.executa(request, response);
//		}else if (paramAcao.equals("novaEmpresaForm")) {
//			System.out.println("nova empresas");
//			NovaEmpresaForm acao = new NovaEmpresaForm();
//			redirecionaPara = acao.executa(request, response);
//		}

		String[] tipoEEndereco = redirecionaPara.split(":");

		if (tipoEEndereco[0].equals("forward")) {
			RequestDispatcher rd = request.getRequestDispatcher("WEB-INF/view/" + tipoEEndereco[1]);
			rd.forward(request, response);

		} else {
			response.sendRedirect(tipoEEndereco[1]);
		}
	}

}
