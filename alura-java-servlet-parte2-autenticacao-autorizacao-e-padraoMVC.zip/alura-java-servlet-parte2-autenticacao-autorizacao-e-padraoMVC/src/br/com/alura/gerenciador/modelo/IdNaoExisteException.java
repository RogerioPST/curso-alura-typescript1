package br.com.alura.gerenciador.modelo;

public class IdNaoExisteException extends Exception {
	
	public IdNaoExisteException(String msg) {
		super(msg);
	}

}
