package br.com.alura.forum.config.validacao;

/*
 * Nessa classe, o que preciso ter de informações para mandar para o JSON? Só duas informações. Primeiro, qual foi o campo que deu erro. E o segundo, é uma string também, que é qual é a mensagem, qual o erro. É isso. São dois campos. Qual o campo e qual o erro.

[07:23] E aí vou usar o atalho para gerar os getters e setters. Só que no caso, como já estou recebendo os parâmetros do construtor, só vou gerar os getters.

[07:37] Esse Dto representa o erro de algum campo. Ele tem o nome do campo e uma mensagem de erro. Era só o que eu queria. Para cada campo, só quero o nome do campo e a mensagem.
 */
public class ErroDeFormularioDTO {

	private String campo;
	private String erro;

	public ErroDeFormularioDTO(String campo, String erro) {
		this.campo = campo;
		this.erro = erro;
		// TODO Auto-generated constructor stub
	}

	public String getCampo() {
		return campo;
	}

	public String getErro() {
		return erro;
	}

}
