package br.com.alura.forum.config.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;

import br.com.alura.forum.repository.UsuarioRepository;

@EnableWebSecurity
@Configuration //com essa anotacao, no startup, o spring vai carregar as config dessa classe
public class SecurityConfigurations extends WebSecurityConfigurerAdapter{
	
	@Autowired
	AutenticacaoService autenticacaoService;
	
	@Autowired
	private TokenService tokenService;
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	
	@Override
	@Bean //com essa anotacao, o spring consegue injetar no nosso controller
	protected AuthenticationManager authenticationManager() throws Exception {
		// TODO Auto-generated method stub
		return super.authenticationManager();
	}

	//serve p config de autenticacao (controle de acesso, login etc)// aqui a gente ensina p o spring como vai ser
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		// TODO Auto-generated method stub
		auth.userDetailsService(autenticacaoService).passwordEncoder(new BCryptPasswordEncoder());

	}
	
	//serve p config de autorizacao (quem pode acessar), perfil de acesso
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
			
			.antMatchers(HttpMethod.GET, "/topicos").permitAll()
			.antMatchers(HttpMethod.GET, "/topicos/*").permitAll()
			//.antMatchers("/h2-console/**").permitAll()
			//.antMatchers("/h2-console/*").permitAll()
//			.antMatchers( "/h2-console/**").permitAll()
			//.antMatchers(HttpMethod.GET, "/favicon.ico").permitAll()			
			.antMatchers(HttpMethod.POST, "/auth").permitAll()
			.antMatchers(HttpMethod.GET, "/actuator/**").permitAll()
			.anyRequest().authenticated()//qualquer outra req precisar estar autenticada.
			//.and().formLogin() //formulario padrao do spring q identifica q vai usar o JSessionId
			.and().csrf().disable() //csrf , a gente desabilita, pq a nossa aplicacao esta livre, mas normalmente, habilita.
			.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)//assim, aviso q vou usar o token q n eh p criar sessao, mas vou precisar criar o controller: AutenticacaoController
			.and().addFilterBefore(new AutenticacaoViaTokenFilter(tokenService, usuarioRepository), UsernamePasswordAuthenticationFilter.class); //aqui habilito o filter criado por nos para ser chamado antes do filtro padrao de autenticacao do Spring
			
		
	}
	
	//serve p config de recursos estaticos (js, css, imagens etc)
	@Override
	public void configure(WebSecurity web) throws Exception {
		// TODO Auto-generated method stub
		
		 web.ignoring()
	        .antMatchers("/**.html", "/v2/api-docs", "/webjars/**", "/configuration/**", "/swagger-resources/**");
	}
	
//	public static void main(String[] args) {
//		System.out.println(new BCryptPasswordEncoder().encode("123456"));
//	}
}
