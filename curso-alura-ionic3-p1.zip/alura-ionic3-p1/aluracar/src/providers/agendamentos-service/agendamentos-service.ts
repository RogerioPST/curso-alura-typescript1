import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Agendamento } from '../../modelos/agendamento';




@Injectable()
export class AgendamentosServiceProvider {

  private _url = 'http://localhost:8080/api';

  constructor(private _http: HttpClient) {
    console.log('Hello AgendamentosServiceProvider Provider');
     
  }

  agenda(agendamento: Agendamento){
    // qdo dá erro no post, o 'do' não é executado.
    // com o 'post' dah erro, se tivermos o 'catch', vai capturar o erro e qdo devolvemos um observable, la
    // no cadastro.ts, verificamos o erro.
    return this._http
      .post(this._url + '/agendamento/agenda', agendamento)
      .do(()=> {
        agendamento.enviado = true;
      })
      .catch((err) => Observable.of(new Error('falha no agendamento')));
      ;
  }

}
