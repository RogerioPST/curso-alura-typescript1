import { Injectable } from '@angular/core';
import { Agendamento } from '../../modelos/agendamento';
import { Observable } from 'rxjs/Observable';

import {Storage} from '@ionic/storage'


@Injectable()
export class AgendamentoDaoProvider {

  constructor(private _storage : Storage) {
    console.log('Hello AgendamentoDaoProvider Provider');
  }

  private _geraChave(agendamento: Agendamento){
    return agendamento.emailCliente + agendamento.data.substr(0,10);

  }

  salva(agendamento: Agendamento){
    let chave = this._geraChave(agendamento);
  
    let promise = this._storage.set(chave, agendamento);

    //para transformar uma promise num Observable, usamos o metodo fromPromise e o importamos no app.module:

    return Observable.fromPromise(promise);
  }

  // retorna um observable com true ou false, dependendo do retorno do metodo get do storage
  ehDuplicado(agendamento: Agendamento){
    let chave = this._geraChave(agendamento);

    let promise = this._storage
                .get(chave)
                .then(dado=> dado ? true : false);
    return Observable.fromPromise(promise);
  }

}
