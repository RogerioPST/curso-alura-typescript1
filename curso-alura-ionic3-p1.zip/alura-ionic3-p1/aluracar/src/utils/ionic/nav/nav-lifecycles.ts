export interface NavLifeCycles{
    //o interrogação eh soh p dizer q eh um metodo opcional  e q n precisa ser implementado
    ionViewDidLoad?(): void;
}