import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, Alert } from 'ionic-angular';
import { Carro } from '../../modelos/carro';
import { AgendamentosServiceProvider } from '../../providers/agendamentos-service/agendamentos-service';
import { HomePage } from '../home/home';
import { Agendamento } from '../../modelos/agendamento';
import { AgendamentoDaoProvider } from '../../providers/agendamento-dao/agendamento-dao';


// @IonicPage() - para funcionar o lazy loading
@IonicPage()
@Component({
  selector: 'page-cadastro',
  templateUrl: 'cadastro.html',
})
export class CadastroPage {
  public carro: Carro;
  public precoTotal : number;
  private _alerta : Alert;

  
  public nome : string ='Teste';
  public endereco: string = '';
  public email: string = '';
  public data : string = new Date().toISOString();
  

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private _agendamentosService: AgendamentosServiceProvider,
    private _alertCtrl: AlertController,
    private _agendamentoDAO: AgendamentoDaoProvider
    ) {
    this.carro =   this.navParams.get('carroSelecionado');
    this.precoTotal = this.navParams.get('precoTotal');  
  }

  agenda(){
    console.log(this.nome);
    console.log(this.endereco);
    console.log(this.email);
    console.log(this.data);

    if(!this.nome || !this.endereco || !this.email ){
      this._alertCtrl.create({
        title: 'Preenchimento obrigatório',
        subTitle: 'Preencha todos os campos',
        buttons:[{ text: 'ok'}]
      }).present();
      return;
    }
    //dados sao preenchidos, pois estamos usando o two way data binding no cadastro.html (ngModel)
    let agendamento : Agendamento ={
      nomeCliente: this.nome,
      enderecoCliente: this.endereco,
      emailCliente: this.email,
      modeloCarro: this.carro.nome,
      precoTotal: this.precoTotal,
      confirmado : false,
      enviado : false,
      data: this.data
    };

    this._alerta = this._alertCtrl.create(
      {title: 'Aviso',
      buttons: [{
        text: 'ok', 
        handler: () =>{
          this.navCtrl.setRoot(HomePage);
        }
      }
      ]});

      let mensagem ='';

    // primeiro, verifico se o agendamento eh duplicado, se ele ja existe.
    // ele retorna um observable e eu preciso juntar o retorno dele com o restante do codigo
    //para isso,   eh soh juntar com o mergeMap.
    this._agendamentoDAO.ehDuplicado(agendamento)
      .mergeMap(ehDuplicado =>{
        console.log('eins');
        if(ehDuplicado){
          throw new Error('Agendamento existente');
        }
        return this._agendamentosService.agenda(agendamento);
      })  
    //esse mergeMap vai receber o retorno do sucesso do mergeMap acima e soh vai ser executado caso o primeiro
    //mergeMap retorne sucesso
    //em seguida, vai ser executado o subscribe e por ultimo o finally
    .mergeMap((valor) => 
    {
      console.log('zwei');      
      let observable = this._agendamentoDAO.salva(agendamento);
      if(valor instanceof Error){
        throw valor;
      }
      return observable;
    })
    .finally(()=>{
      console.log('vier');
      this._alerta.setSubTitle(mensagem);
      this._alerta.present();
    })
    .subscribe(
      () =>{        
        console.log('drei sucesso');
      console.log(' agendou');
      mensagem ='agendamento realizado';
      
    },
    (err: Error) =>{
      console.log('drei erro');
      console.log('deu erro no agendamento');      
      mensagem =err.message;
    });

  }

  

  ionViewDidLoad() {
    console.log('ionViewDidLoad CadastroPage');
  }

}
