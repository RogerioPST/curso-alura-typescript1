import { Component } from '@angular/core';
import { NavController, LoadingController, AlertController } from 'ionic-angular';
import { Carro } from '../../modelos/carro';
import { HttpErrorResponse} from '@angular/common/http'
import { CarrosServiceProvider } from '../../providers/carros-service/carros-service';
import { NavLifeCycles } from '../../utils/ionic/nav/nav-lifecycles';
import { EscolhaPage } from '../escolha/escolha';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage implements NavLifeCycles {
  
  public carros : Carro[];
  
  constructor(
    public navCtrl: NavController,     
    private _loadingCtrl: LoadingController,
    private _alertCtrl : AlertController, 
    private carrosService: CarrosServiceProvider
    ) {     
  }

  //esse metodo ser p indicar q o carregamento da nossa pagina terminou
  ionViewDidLoad() {
    let loading = this._loadingCtrl.create({
      content: 'Carregando carross...'
    });

    loading.present();

    this.carrosService.lista()
    .subscribe(carros =>{
        this.carros = carros;
        loading.dismiss();

    }, (erro : HttpErrorResponse) =>{
        loading.dismiss();

        console.log(erro.message);
        this._alertCtrl.create({
          title: 'Falha na conexão',
          subTitle: 'Nao foi possivel carregar a lista',
          buttons: [
            {text: 'Ok'            }
          ]
        }).present();
    }
    );
 
 
 /*
  this.carros = [
    {nome: 'Brasilia Amarela', preco: 2000},
    {nome: 'Gol 1.0', preco: 3000},
    {nome: 'Gol 2.0', preco: 4000},
    {nome: 'Gol 3.0', preco: 5000},
  ];
  */
  }

  selecionaCarro(carro: Carro){
    console.log(carro);
    // para abrir a pagina de escolha; empilha a nova pagina
    //this.navCtrl - recebido por injeção de dependência; eh  o controlador de navegação do Ionic, 
    this.navCtrl.push(EscolhaPage.name,{
      carroSelecionado: carro 
    }
      );
  }

}
