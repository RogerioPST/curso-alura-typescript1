$('#botao-placar').click(mostraPlacar);
$('#botao-sync').click(sincronizaPlacar);


function inserePlacar(){
    //placar eh a section, mas como quero a table, posso usar a funcao find, do jquery, q vai descer os nós-filhos do html e achar a table a partir do section c classe placar
    //var tabela = $('.placar').find('table');
    //console.log(tabela);
    var corpoTabela = $('.placar').find('tbody');
    console.log(corpoTabela);
    var ususario = $('#usuarios').val();
    var numPalavras = $('#contador-palavras').text();
    //var botaoRemover = '<a href="#">    <i class="small material-icons">delete</i></a>';

    //var linha = '<tr>' +                  '<td>' + ususario + '</td>' +                 '<td>' + numPalavras + '</td>' +                  '<td>' + botaoRemover + '</td>' +                  '</tr>';

    var linha = novaLinha(ususario, numPalavras);

    //criar um obj dentro do jquery, dentro do javascript.
    //como eh um elem html, consigo buscar o botao e add um EVENTO de click num elem q ainda n foi criado
    //e c isso, ela ja pode ser removida assim q for colocada no placar
    linha.find('.botao-remover').click(removeLinha);

    //funcao do jquery p acrescentar um item no final;
    //corpoTabela.append(linha);
    //funcao do jquery p acrescentar um item no inicio;
    corpoTabela.prepend(linha);

    //para mostrar a placar assim q terminar o jogo
    $('.placar').slideDown(500);
   // scrollPlacar();

}

function scrollPlacar(){
    //essa função offset tem atributos como top, left que mostram onde o objeto se encontra naquele momento na pagina
    var posicaoPlacar = $('.placar').offset().top;

    //a funcao animate recebe dois parametros: um objeto e o tempo
    //scrollTop vai fazer uma animação até essa posição do elemento.
    $('body').animate(
        {            
            scrollTop: posicaoPlacar+'px'

        }, 1000);
}

function novaLinha(usuario, palavras){
    //criando um elemento html com jquery
    var linha = $('<tr>');
    var colunaUsuario = $('<td>').text(usuario);
    var colunaPalavras = $('<td>').text(palavras);
    var colunaRemover = $('<td>');
    var link = $('<a>').addClass('botao-remover').attr('href', '#');

    var icone = $('<i>').addClass('small').addClass('material-icons').text('delete');

    link.append(icone);


    colunaRemover.append(link);
    linha.append(colunaUsuario);
    linha.append(colunaPalavras);
    linha.append(colunaRemover);

    return linha;
}


function removeLinha(){
    event.preventDefault();
    //por padrao, o href='#', vai para o topo da pagina
    //se eu quiser q de o focus num elemento c id 'teste', eh soh fazer href='#teste' no a.
    console.log(this);
    //para dar poderes a um elemento do html, tenho q envolve-lo com o $ do jquery
    //para remover a propria lixeira
    //$(this).remove();
    var linha = $(this).parent().parent();
    //tambem tem o fadeIn e tambem tem o fadeToggle();
    linha.fadeOut(1000);
    //eh necessario usar o remove dentro do setTimeOut com o mesmo tempo de 1000 milisegundos q o fadeout, 
    //se n, o remove(), se usado logo depois, corta a animação do fadeout
    setTimeout(function(){
        linha.remove();
    }, 1000);
    

}

function mostraPlacar(){
    //$('.placar').css('display', 'block');
    //$('.placar').show() ou $('.placar').hide()
    //equivale a toggle: esconde e mostra; como se tivesse um if , else, verificando se estah ligado, p fazer o oposto. 
    //$('.placar').toggle();
    //caso eu queira uma animaçãozinha, p n ficar tao abrupto, tem o slideDown() e slideUp()
    //mas tb tem o slideToggle();
    //$('.placar').slideToggle(600);
    //o jquery tem uma função stop() q serve p parar qualquer animação q ele esteja fazendo e exec a proxima
    $('.placar').stop().slideToggle(600);
    //$('.promocoes').toggleClass('invisivel'); 
    //A função toogleClass (não confundir com a função toggle) adiciona uma classe caso ela não exista no elemento. Se existir, ela remove a classe.

}

function sincronizaPlacar(){
    var placar = [];
    var linhas = $('tbody>tr');

    linhas.each(function(){
        var usuario = $(this).find('td:nth-child(1)').text();
        var palavras = $(this).find('td:nth-child(2)').text();

        var score = {
            usuario: usuario,
            pontos: palavras
        };

        placar.push(score);
    })

    console.log(placar);

    var dados = {
        placar: placar
    };

    $.post('http://localhost:3000/placar',dados, function(){
        console.log('salvou os dados no server');
        $('.tooltip').tooltipster('open').tooltipster('content', 'Sucesso ao sincronizar');
    }).fail(function(){
        setTimeout(function(){
            $('.tooltip').tooltipster('open').tooltipster('content', 'Falha ao sincronizar');
        }, 1200);
    })
    .always(function(){
        setTimeout(function(){
            $('.tooltip').tooltipster('close');
        }, 1200);
    });


}

function atualizaPlacar(){
    $.get('http://localhost:3000/placar', function(data){
    //data , desse jeito, eh um objeto javascript normal
    //para poder ter acesso ao each, precisamos envolve-lo com o $()    -> $(data)
    //data.each(function(){
    $(data).each(function(){
            var linha = novaLinha(this.usuario, this.pontos);
            linha.find('.botao-remover').click(removeLinha);
            $('tbody').prepend(linha);
        })
    });
}
