var tempoInicial = $('#tempo-digitacao').text();
var campo = $('.campo-digitacao');

//funcao q eh ativada assim q a pagina estah carregada, assim como a  $(document).ready
//$function(){    atualizaTamanhoFrase();    inicializaContadores();    inicializaCronometro();    $('#botao-reiniciar').click(reiniciaJogo);});

$(document).ready(function(){
    atualizaTamanhoFrase();
    inicializaContadores();
    inicializaCronometro();
    inicializaMarcadores();
    $('#botao-reiniciar').click(reiniciaJogo);
    atualizaPlacar();
    $('#usuarios').selectize({
        create: true,
        sortField: 'text'
    }); 

    $('.tooltip').tooltipster({
        trigger: "custom"
    });
}); 

function atualizaTempoInicial(tempo){
    tempoInicial = tempo;
    $('#tempo-digitacao').text(tempo);
}

function atualizaTamanhoFrase(){
    //var frase = jQuery('.frase');
    //atalho ao jQuery = $
    var frase = $('.frase');

    console.log(frase);
    //.text() - conteudo do elemento
    console.log(frase.text());

    var numPalavras = frase.text().split(" ").length;

    console.log(numPalavras);

    var todas_elem_li = $('li');

    var tamanhoFrase = $('#tamanho-frase');

    console.log(tamanhoFrase.text());

    //nesse caso, atribui o numPalavras para o text
    tamanhoFrase.text(numPalavras);
}





function inicializaContadores(){
    // o evento de input serve para quando uma tecla eh pressionada e soltada
    campo.on('input', function(){
        console.log('cliquei');
        //.val() - o value de um input, textarea etc
        console.log(campo.val());
        var conteudo = campo.val();
        //desse jeito, conta como se cada espaço fosse uma palavra
        //var qtdPalavras = conteudo.split(' ').length;
        // //desse jeito, conta como se cada espaço fosse uma palavra
        //uma regex q busca por qq tipo de espaço vazio- quebra de linhas, multiplos espaços
        var qtdPalavras = conteudo.split(/\S+/).length -1;
        $('#contador-palavras').text(qtdPalavras);
    
        var qtdCaracteres = conteudo.length;
    
        $('#contador-caracteres').text(qtdCaracteres);
    });
}



function inicializaCronometro(){
    
    
    //o evento on é executado varias vezes
    //campo.on
    // o evento one eh executado apenas uma vez
    campo.one('focus', function(){
        var tempoRestante = $('#tempo-digitacao').text();
        $("#botao-reiniciar").attr("disabled",true);
        let cronometroId = setInterval(function(){
            tempoRestante--;        
            $('#tempo-digitacao').text(tempoRestante);
    
            console.log('valor do atributo rows', campo.attr('rows'));
            if(tempoRestante < 1){
                clearInterval(cronometroId);
                finalizaJogo();
                inserePlacar();
                
            }
        }, 1000);
    
    });;
}

function finalizaJogo(){
    // nós utilizamos a função attr. Mas como ele não recebe nenhum valor, temos que informar isso, "habilitando-o" na função, passando o valor true (verdadeiro) por parâmetro.
    //Assim, a função .attr() vai se comportar como uma outra função do jQuery, a .removeAttr(), que tem como objetivo remover atributos de elementos. Um outro código que também conseguiria remover o attr seria o :$(".post").removeAttr("disabled");
    campo.attr('disabled', true);
    //para de funcionar a funcao setInterval p n ficar negativo o cronometro/contador de segundos
    $("#botao-reiniciar").attr("disabled", false);
    //alterando o css
    //campo.css('background-color', 'lightgray');
    //melhor pratica eh deixar os estilos no arq css e add ou remove class pelo js
    campo.addClass('campo-desativado');

}

$('#botao-reiniciar').on('click', function(){
    console.log('botao clicado');
});



/*
Como o JavaScript está evoluindo e melhorando já existe uma forma mais fácil de verificar se uma string faz parte da outra string. Se o seu navegador já der suporte ao ECMA Script 6 você pode simplesmente executar:

 var digitouCorreto = frase.startsWith(digitado);
if(digitouCorreto) {
 campo.addClass("borda-verde");
} else {
 campo.addClass("borda-vermelha");
}
*/
function inicializaMarcadores(){
    

    campo.on('input', function(){
        var frase = $('.frase').text();
        var digitado = campo.val();
        var comparavel = frase.substr(0, digitado.length);
        console.log('digitado:',digitado);
        console.log('frase c:',comparavel);
        //p dar na mesma, daria p usar o startswith do es6 - frase.startsWith(digitado);
        if (digitado == comparavel){
            console.log('vc estah digitando exatamente o trecho da frase acima');
            campo.addClass('borda-verde');
            campo.removeClass('borda-vermelha');
        }
        else{
            console.log('vc NAO estah digitando exatamente o trecho da frase acima');
            campo.addClass('borda-vermelha');
            campo.removeClass('borda-verde');
        }
    
    });

}


function reiniciaJogo(){
    console.log('botao clicado coma função click() q eh igual a on("click")');
    campo.attr('disabled', false);
    campo.val('');
    $('#contador-palavras').text('0');
    $('#contador-caracteres').text('0');
    $('#tempo-digitacao').text(tempoInicial);
    inicializaCronometro();
    //add e remove class eh tao comum q o jquery tem o .toggleClass, q se tiver c a classe, retira e se n tiver, coloca a classe.
    campo.removeClass('campo-desativado');
    campo.removeClass('borda-verde');
    campo.removeClass('borda-vermelha');
}
$('#botao-reiniciar').click(reiniciaJogo);