$(function(){
    $('.slider').slick({
        dots: true, 
        infinite: true,
        spped: 300,
        slidesToShow: 1,
        adaptiveHeight: true
    });
});