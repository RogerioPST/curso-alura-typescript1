$('#botao-frase').click(fraseAleatoria);
$('#botao-frase-id').click(buscaFrase);


function fraseAleatoria(){
    $('#spinner').toggle();

    $.get('http://localhost:3000/frases', trocaFraseAleatoria)
    .fail(function(){
        $('#erro').show();
        setTimeout(function(){
            $('#erro').toggle();
        },2000);
    })
    //a função always eh executada independente de dar algum erro ou nao.
    .always(function(){
        $('#spinner').toggle();
    })    
}

function trocaFraseAleatoria(data){
    console.log('fiz a req no server e voltei');
    //o parametro data contem os dados do servidor trazidos
    console.log(data);

    var frase = $('.frase');

    var numeroAleatorio = Math.floor(Math.random() * data.length);
    console.log(numeroAleatorio);
    frase.text(data[numeroAleatorio].texto);

    atualizaTamanhoFrase();
    atualizaTempoInicial(data[numeroAleatorio].tempo);


}

function buscaFrase(){
    $('#spinner').toggle();

    var fraseId = $('#frase-id').val();
    var dados = { id: fraseId}

    $.get('http://localhost:3000/frases', dados, trocaFrase)
    .fail(function(){
        $('#erro').show();
        setTimeout(function(){
            $('#erro').toggle();
        },2000);
    })
    //a função always eh executada independente de dar algum erro ou nao.
    .always(function(){
        $('#spinner').toggle();
    })    

}

function trocaFrase(data){
    console.log('busquei: ', data);
    var frase = $('.frase');
    frase.text(data.texto);
    atualizaTamanhoFrase();
    atualizaTempoInicial(data.tempo);
}

