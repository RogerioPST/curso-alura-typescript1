class NegociacoesView extends View{
    constructor(elemento){
        super(elemento);
    }

    // map me devolve um array
    //o template string me devolve uma string
    //p cada negociacao q estou varrendo ,estou criando uma nova lista com uma tr e com os dados da negociacao
    //para o objeto negociacao , estou criando um novo array, soh q o novo elemento desse array eh uma string interpolada com os dados da negociacao
    //
    //no final, retornaria um array;
    //entao eh por isso, q coloco o .join('') 
    //qdo chamo o join, coloco como criterio de juncao a string em branco. 
    //pq vai varrer a lista, vai criar uma nova, soh q essa nova lista soh vai ter string
    template(model){
        return `
        <table class="table table-hover table-bordered">
            <thead>
                <tr>
                    <th>DATA</th>
                    <th>QUANTIDADE</th>
                    <th>VALOR</th>
                    <th>VOLUME</th>
                </tr>
            </thead>
            
            <tbody>
            ${model.negociacoes.map((n)=>{
                return `
                    <tr>
                        <td>${DateHelper.dataParaTexto(n.data)}</td>
                        <td>${n.quantidade}</td>
                        <td>${n.valor}</td>
                        <td>${n.volume}</td>
                    </tr>
                `

            }).join('')}
            </tbody>

            <tfoot>
            <td colspan="4">
            MODO DE FAZER USANDO O JAVASCRIPT ANTES DO ECMASCRIPT 6 =
            Porém, dentro da expressão, precisamos retornar um valor. Só que quando usamos uma instrução, não podemos adicionar uma sequência de instruções. Seremos espertos e adicionaremos uma função dentro do $. Utilizaremos uma Immediately-invoked function expression (IIFE) ou a função imediata. Trata-se de um recurso usado na criação de escopo em JavaScript, que nos ajudará a colocar um bloco na expressão, sendo executado imediatamente. No caso, o $ receberá o total.
            </td>
            </tfoot>
            
            <tfoot>
                <td colspan="3">MODO DE FAZER USANDO O JAVASCRIPT ANTES DO ECMASCRIPT 6</td>
                <td>${
                    (function(){
                        let total = 0;
                        model.negociacoes.forEach(n => total+= n.volume);
                        return total;
                    })()
                }

                </td>
            </tfoot>
            <tfoot>
                <td colspan="3">MODO DE FAZER USANDO REDUCE DO ECMASCRIPT 6</td>
                <td>${model.negociacoes.reduce(function(total, n){
                    return total + n.volume;
                }, 0.0)}

                </td>
            </tfoot>
        </table>
        `;
    }

    
}