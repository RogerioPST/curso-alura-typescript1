class ListaNegociacoes{
    constructor(){
        this._negociacoes = [];

    }

    adiciona(negociacao){
        this._negociacoes.push(negociacao);
    }

    get negociacoes(){
        //esse eh um truque de programação defensiva = return [].concat(this._negociacoes);
        //pois vai criar uma copia da lista e não vai mexer na original.
        return [].concat(this._negociacoes);
    }
}