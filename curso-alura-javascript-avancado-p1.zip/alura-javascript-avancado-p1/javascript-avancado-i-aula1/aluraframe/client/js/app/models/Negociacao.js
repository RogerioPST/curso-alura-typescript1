//M é o modelo, uma abstração do mundo real, os dados da aplicação e suas regras de negócio.

 
//O padrão MVC permite que alterações de layout na view não acarretem alterações no modelo.
class Negociacao{
    constructor(data, quantidade, valor){

        //PROGRAMACAO DEFENSIVA
        // vou devolver uma nova referencia, um novo objeto
        //getTime(0 - devolve o EPOCH da data =  um numero grande desde 1970+- = um numero q representa essa data)
        // no construtor do date, aceita o EPOCH p fazer uma nova data
        //como eh um novo objeto, se tentar alterar a data fora no index, vc soh estah alterando a copia e n vai estar alterando o interno
        this._data = new Date(data.getTime());
        this._quantidade =quantidade;
        this._valor =valor;
        // como eu n posso alterar uma negociação depois de feita, uso Object.freeze(this), onde
        // this representa a propria instancia do objeto Negociacao
        //para verificar se um objeto estah freeze, fazemos Object.isFrozen();
        // n funciona quando a referencia eh um outro objeto, como em new Date(); -> nesse caso, usar programação defensiva.
        //Object.freeze() eh shallow (raso), ele será aplicado nas propriedades do objeto, mas as propriedade que são objetos não serão todas congeladas. A ação ficará apenas na superfície. Para resolver esta questão, falamos um pouco sobre programação defensiva.
        Object.freeze(this);
    }

    get volume(){
        return this._quantidade * this._valor;
    }

    get data(){
        //PROGRAMACAO DEFENSIVA
        // vou devolver uma nova referencia, um novo objeto
        //getTime(0 - devolve o EPOCH da data =  um numero grande desde 1970+- = um numero q representa essa data)
        // no construtor do date, aceita o EPOCH p fazer uma nova data
        //como eh um novo objeto, se tentar alterar a data fora no index, vc soh estah alterando a copia e n vai estar alterando o interno
        return new Date(this._data.getTime());
    }

    get quantidade(){
        return this._quantidade;
    }

    get valor(){
        return this._valor;
    }
}