import { Component, Input } from "@angular/core";

@Component({
    selector: 'alurapic-photo',
    templateUrl: 'photo.component.html'
})
export class PhotoComponent{
  @Input() alt = '';
  @Input() url = '';

}