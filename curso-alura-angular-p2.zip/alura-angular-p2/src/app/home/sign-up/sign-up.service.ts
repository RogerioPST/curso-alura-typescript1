import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { NewUser } from "./new-user";


const API_URL = "http://localhost:3000";

// unica instancia para  a aplicacao inteira! = providedin: 'root', mas como n precisa ser assim, 
// pois n eh todo lugar q precisa, vou colocar no home.module.ts o seguinte:
// "providers: [SignUpService]
@Injectable()
export class SignUpService{
    constructor(private http : HttpClient){

    }
    // o validador n suporta injecao de dependencia.
    checkUserNameTaken(userName : string){
        return this.http.get(API_URL + '/user/exists/' + userName);
    }


    signUp( newUser : NewUser){
        return this.http.post(API_URL + '/user/signup', newUser );
    }
}