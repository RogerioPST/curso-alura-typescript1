import { AbstractControl } from "@angular/forms";

export function lowerCaseValidator(control : AbstractControl){
    if (control.value.trim() && !/^[a-z0-9_\-]+$/.test(control.value)){
        // esse nome ' lowerCase' q vou retornar no template
        return { lowerCase: true }
    }
    // se n houver erro de validação, retorno null
    return null;
}