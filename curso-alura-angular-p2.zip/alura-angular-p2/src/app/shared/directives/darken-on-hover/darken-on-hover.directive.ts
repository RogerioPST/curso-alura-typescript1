import { Directive, ElementRef, HostListener, Renderer, Input } from "@angular/core";

//Podemos usar uma diretiva como atributo envolvendo o valor do seu seletor entre colchetes
@Directive({
    selector: '[apDarkenOnHover]'
})
export class DarkenOnHoverDirective{

    @Input() brightness = '70%';

    //vou pegar o elem do dom onde esta diretiva esta sendo usada
    constructor(private el: ElementRef, private render: Renderer){


    }
    //a diretiva atraves de HostListener pode ouvir aos eventos disparados no elemento host, isto é, aquele no qual a diretiva foi associada.
    @HostListener('mouseover')
    darkenOn(){
        this.render.setElementStyle(this.el.nativeElement, 'filter', `brightness(${this.brightness})`);
    }

    @HostListener('mouseleave')
    darkenOff(){
        this.render.setElementStyle(this.el.nativeElement, 'filter', 'brightness(100%)');
    }

}