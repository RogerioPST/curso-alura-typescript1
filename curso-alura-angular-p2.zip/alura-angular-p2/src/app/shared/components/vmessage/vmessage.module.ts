import { NgModule } from "@angular/core";
import { VMessageComponent } from "./vmessage.componen";

@NgModule({
    declarations: [VMessageComponent],
    exports: [VMessageComponent]

})
export class VMessageModule{

}