import { Injectable } from "@angular/core";
import { TokenService } from "../token/token.service";
import { BehaviorSubject } from "rxjs";
import { User } from "./user";
import * as jwt_decode from 'jwt-decode';

@Injectable({
    providedIn: 'root'
})
export class UserService{
    //utilizar esse behaviorsubject para qdo recarregar a pagina n perder o usuario logado.    
    //O BehaviorSubject armazena a última emissão até que alguém apareça para consumi-la.
    // soh subject perdia ; ele ja emitia e ela se perdia.   
    private userSubject = new BehaviorSubject<User>(null);

    private userName: string;

    constructor(private tokenService: TokenService){
        // so faço o decodeAndNotify , se tiver token
        this.tokenService.hasToken() && this.decodeAndNotify();

    }

    setToken(token : string){
        this.tokenService.setToken(token);
        this.decodeAndNotify();
    }
    private decodeAndNotify() {
        const token = this.tokenService.getToken();
        //fazendo um casting para User
        //decodifico o token
        //pego o valor do payload dele e transformo para o tipo User
        const user = jwt_decode(token) as User;
        this.userName = user.name;
        //esse cara q vou emitir atraves do meu userSubject.
        this.userSubject.next(user);
    }

    getUser(){
        // quem chamar, vai receber o Observable, e no observable, posso fazer o subscribe.
        return this.userSubject.asObservable();
    }

    logout(){
        this.tokenService.removeToken();
        // vou pedir p o subject emtitr um valor null para sumir o nome q esta la no header.
        this.userSubject.next(null);
    }

    isLogged(){
        return this.tokenService.hasToken();
    }

    getUserName(){
        return this.userName;
    }


}