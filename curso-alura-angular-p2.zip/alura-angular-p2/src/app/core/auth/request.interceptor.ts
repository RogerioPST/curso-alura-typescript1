import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent, HttpHeaderResponse, HttpProgressEvent, HttpResponse, HttpUserEvent, HttpSentEvent } from "@angular/common/http";
import { Observable } from "rxjs";
import { TokenService } from "../token/token.service";

@Injectable()
export class RequestInterceptor implements HttpInterceptor{
    constructor(private tokenService : TokenService){

    }
    //se eu fizer somente "return next.handle(req);", n vou mudar nada ao interceptar!
    //preciso modificar o 'req'
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpSentEvent
        | HttpHeaderResponse | HttpProgressEvent | HttpResponse<any> | HttpUserEvent<any>> {
            if (this.tokenService.hasToken()){
                const token = this.tokenService.getToken();
                req = req.clone({
                    setHeaders:{
                        'x-access-token': token
                    }
                })
            }
            return next.handle(req);
    }

}