import { Injectable, Inject, PLATFORM_ID } from "@angular/core";
import { isPlatformBrowser } from "@angular/common";

@Injectable({
    providedIn: 'root'
})
export class PlatformDetectorService {
    //serviço para identificar se eh um browser
    constructor(@Inject(PLATFORM_ID) private plaformId: string){

    }

    isPlatformBrowser(){
        return isPlatformBrowser(this.plaformId);
    }

}