
const BaseControlador = require('../controladores/base-controlador');
const baseControlador = new BaseControlador();




//estou exportando do meu modulo uma função em q recebi como parametro app
module.exports = (app) => {

    const rotasBase = BaseControlador.rotas();
  

    // essa funcao get so vai ser executada qdo o nosso servidor receber uma requisição do nosso cliente
    //no mundo javascript, funcoes q sao executadas dada a ocorrencia de um evento, elas sao chamadas de funcao callback.   
    app.get(rotasBase.home, baseControlador.home());

    app.route(rotasBase.login)
        .get(baseControlador.login())
        .post(baseControlador.efetuaLogin());
    


    /*
        sem promise
        livroDao.lista(function(erro, resultados){
            resp.marko(
                require('../views/livros/lista/lista.marko'),
                {
                    livros: resultados
                }
            );
        });
        */

        // de tal forma q n vem do banco de dados
        /* 
        resp.marko(
                require('../views/livros/lista/lista.marko'),
                {
                    livros: [
                        { 
                            id: 1,
                            titulo: 'Fundamentos do Node'
                        },
                        { 
                            id: 2,
                            titulo: 'Node Avançado'
                        }
                    ]
                }
            );
        */
};