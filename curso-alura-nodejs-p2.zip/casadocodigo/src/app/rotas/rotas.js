
const livroRotas = require('./livro-rotas');
const baseRotas = require('./base-rotas');

//estou exportando do meu modulo uma função em q recebi como parametro app
module.exports = (app) => {
    baseRotas(app);
    livroRotas(app);
};