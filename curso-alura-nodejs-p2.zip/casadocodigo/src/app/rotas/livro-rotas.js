

const LivroControlador = require('../controladores/livro-controlador');
const BaseControlador = require('../controladores/base-controlador');
const livroControlador = new LivroControlador();



const Livro = require('../modelos/livro');


//estou exportando do meu modulo uma função em q recebi como parametro app
module.exports = (app) => {


    const rotasLivro = LivroControlador.rotas();

    //verificando se esta autenticado    
    //criando um middleware p verificar as rotas e se o usuario esta autenticado
    app.use(rotasLivro.autenticadas, function(req, resp, next)  {
        if(req.isAuthenticated()){
            next();
        } else{
            resp.redirect(BaseControlador.rotas().login);

        }
    });
            
    app.get(rotasLivro.lista, livroControlador.lista());
    //Na realidade, o que estamos fazendo ao passar um array como segundo parâmetro do método post() é adicionar um conjunto de validadores (todos eles middlewares que serão executados antes do callback da rota passado como terceiro parâmetro do post()), cada um deles retornando o que o Express Validator chama de validation chain! O validation chain nada mais é do que o encadeamento das validações, que nos possibilita, dentre outras coisas, definir qual a validação que será feita no campo e, inclusive, customizar a mensagem de erro da validação! Exatamente um recurso que veremos um pouco mais a frente, ainda nesse capítulo do curso! Portanto, sempre que fazemos check('nomeDoCampo'), obtemos um validation chain que podemos utilizar para configurar a validação, a mensagem de erro e muito mais!
    app.route(rotasLivro.cadastro)    
        .get(livroControlador.formularioCadastro())
        .post(Livro.validacoes(), livroControlador.cadastra())
        .put(livroControlador.edita());         
        
        
    app.get(rotasLivro.edicao, livroControlador.formularioEdicao());       

    app.delete(rotasLivro.delecao, livroControlador.remove());        

    /*
        sem promise
        livroDao.lista(function(erro, resultados){
            resp.marko(
                require('../views/livros/lista/lista.marko'),
                {
                    livros: resultados
                }
            );
        });
        */

        // de tal forma q n vem do banco de dados
        /* 
        resp.marko(
                require('../views/livros/lista/lista.marko'),
                {
                    livros: [
                        { 
                            id: 1,
                            titulo: 'Fundamentos do Node'
                        },
                        { 
                            id: 2,
                            titulo: 'Node Avançado'
                        }
                    ]
                }
            );
        */
};