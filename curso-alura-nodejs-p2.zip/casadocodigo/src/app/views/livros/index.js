module.exports = {
    lista : require('./lista/lista.marko'),    
    form : require('./form/form.marko')
}