module.exports = {
    //por padrao, o node procura um arquivo index.js qdo se faz um require
    base: require('./base'),
    livros: require('./livros'),
}