const {validationResult } = require('express-validator/check');

const LivroDao = require('../infra/livro-dao');
const db = require('../../config/database');

const templates = require('../views/templates');

class LivroControlador{
    
    //retorna todas as rotas da app
    static rotas(){
        return {
            autenticadas: '/livros*',
            lista: '/livros',
            cadastro: '/livros/form',
            edicao: '/livros/form/:id',
            delecao: '/livros/:id'
        };
    }

    lista(){
        //retorna o callback, q vai ser acionado qdo a rota de listar for acionada
        return function(req, resp) {

            const livroDao = new LivroDao(db);
            //com promise 
            livroDao.lista()
                    .then(livros => resp.marko(templates.livros.lista,
                        {
                            livros: livros
                        }
                    ))
                    .catch(erro => console.log(erro));
        };
    }
    formularioCadastro(){
        return function(req, resp) {
            resp.marko(templates.livros.form, { livro: {} });
        };
    }

    formularioEdicao() {
        return function(req, resp) {
            const id = req.params.id;
            const livroDao = new LivroDao(db);
    
            livroDao.buscaPorId(id)
                    .then(livro => 
                        resp.marko(
                            templates.livros.form, 
                            { livro: livro }
                        )
                    )
                    .catch(erro => console.log(erro));
        };
    }

    cadastra() {
        return function(req, resp) {
            console.log(req.body);
            const livroDao = new LivroDao(db);
            // qdo chamamos essa função, retorna o obj contendo os erros na req.
            // e esse obj contem os atributos: location, msg e param (erros.array())
            const erros = validationResult(req);
    
            if (!erros.isEmpty()) {
                return resp.marko(
                    templates.livros.form,
                    { 
                        // Aqui que acontece a mágica!
                        // O livro passado ao template recebe
                        // os dados passados pelo formulário
                        // previamente preenchido!
                        livro: req.body, 
                        errosValidacao: erros.array()
                    }
                );
            }
    
            livroDao.adiciona(req.body)
                    .then(resp.redirect(LivroControlador.rotas().lista))
                    .catch(erro => console.log(erro));
        };
    }

    edita() {
        return function(req, resp) {
            console.log(req.body);
            const livroDao = new LivroDao(db);
            
            livroDao.atualiza(req.body)
                    .then(resp.redirect(LivroControlador.rotas().lista))
                    .catch(erro => console.log(erro));
        };
    }

    remove() {
        return function(req, resp) {
            const id = req.params.id;
    
            const livroDao = new LivroDao(db);
            //com promise
            livroDao.remove(id)
                    .then(() => resp.status(200).end())
                    .catch(erro => console.log(erro));
        };
    }
}

module.exports = LivroControlador;