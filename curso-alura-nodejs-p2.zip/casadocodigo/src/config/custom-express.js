// modulo do marko p habilitar p  trabalhar c node
require('marko/node-require').install();
//modulo do marko p habilitar p trabalhar c express
require('marko/express');

//nesse arquivo, a gente vai deixar num unico lugar a configuração do express
// de forma customizada
// vai procurar o nome 'express' na pasta node_modules
const express = require('express');
const app = express();

const templates = require('../app/views/templates');

//definindo o middleware
/*
o método use() do Express pode receber dois parâmetros, sendo o primeiro uma string que define as URLs que serão atendidas pelo middleware e como segundo parâmetro uma função. É essa função que irá definir o que o middleware deverá fazer e, por sua vez, recebe três parâmetros, a requisição, a resposta e uma função (normalmente chamada de next) que deve ser invocada para que o Express avance para o próximo middleware existente e caso não exista mais nenhum, passa a execução para a rota ativada. Sendo assim, a ordem em que os middlewares são definidos é de extrema importância! Além disso, um detalhe a ser observado, é que tudo que estiver antes da chamada da função next será executado antes da rota ativada e o que estiver após a chamada da função next será executado somente ao término da rota ativada!
*/
const bodyParser = require('body-parser');
const methodOverride = require('method-override');

app.use('/estatico', express.static('src/app/public'));

app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(methodOverride(function (req, res) {
    if (req.body && typeof req.body === 'object' && '_method' in req.body) {
      // look in urlencoded POST bodies and delete it
      var method = req.body._method;
      delete req.body._method;
      return method;
    }
}));
// fim da def

const sessaoAutenticacao = require('./sessao-autenticacao');
sessaoAutenticacao(app);

//importação do modulo criado por nós: rotas.js
// e colocando numa constante 'rotas'
const rotas = require('../app/rotas/rotas');

// dessa forma , consigo passar um parametro ('app') para a função exportada dentro de rotas.js
rotas(app);

//Muito bem, aluno! Está correto! Essa também é uma alternativa! Contanto que os middlewares de tratamento de erro sejam os últimos, o Node conseguirá idenficar qual é o de tratamento de erro interno da aplicação através do parâmetro erro.
// criando mais um middleware para filtrar as requisições para, caso tenha alguma rota que não 
//exista, redirecionar para uma página de erro.
//Muito bem, aluno! Está correto! Essa é a forma de tratamento de erros para quando um determinado recurso/página não é encontrado na aplicação.
app.use(function(req, resp, next){
  //devolver para o usuário a pag contendo o erro de 404 qdo der erro 404
  //eu faço com q seja retornado um status 404 e exibo a pag certa
  return resp.status(404).marko(templates.base.erro404);
});

// criando mais um middleware para filtrar os erros, pois vai ser acionado qdo ocorrer um erro na minha app
//Muito bem, aluno! Está correto! Essa é a forma de tratamento de erros internos da aplicação, como quando acessamos uma propriedade inexistente de um objeto ou uma exceção é lançada.
app.use(function(erro, req, resp, next){
  //devolver para o usuário a pag contendo o erro de 500 qdo der erro 500
  //eu faço com q seja retornado um status 500 e exibo a pag certa
  return resp.status(500).marko(templates.base.erro500);
});

module.exports = app;