package br.com.solid.LSP.liskov_heranca_composicao.apos_refatoracao_um;

public class ContaEstudante {
	
	private ManipuladorDeSaldo manipulador;
	private int milhas;
	
	public ContaEstudante() {
		this.manipulador = new ManipuladorDeSaldo();
	}
	
	public void deposita(double valor) {
		manipulador.deposita(valor);
		this.milhas += (int)valor;
	}
	
	public int getMilhas() {
		return milhas;
	}		
}
