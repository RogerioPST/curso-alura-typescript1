package br.com.solid.LSP.liskov_heranca_composicao.antes;

import java.util.ArrayList;
import java.util.List;

/*
 * se o banco so tiver contacomum, td vai funcionar, mas se o banco tiver contadeestudante, o codigo n vai funcionar, pq o metodo rende
 * vai lan�ar uma excecao.
 * 
 * essa classe filho quebra o comportamento das outras classes q usavam a abstracao da contacomum.
 * 
 * outro exemplo: classe retangulo e a classe filha: classe quadrado.
 * 
 * 
 * para usar heranca, tem q pensar mto bem nas pre condicoes (por ex, metodo qdo recebe parametros) da sua classe e nas pos 
 * condicoes da sua classe.
 * as pre condicoes do quadrado (dois lados iguais) e dos retangulos sao diferentes (dois lados diferentes).
 * 
 * PRE-CONDICOES:
 * O principio de Liskov diz q vc nunca pode apertar as pre condicoes dos filhos, q essas pre condicoes nos filhos n podem ser mais
 * restritas; a classe filho soh pode afrouxar as pre condicoes da classe mae.
 * imagina q a classe mae pode receber inteiros de 1  a 100 e imagina q a classe filha pode receber inteiros de 1 a 50, ou seja, 
 * apertou as pre condicoes e a classe filha vai ter comportamento inesperado.
 * 
 * POS-CONDICOES: 
 * a classe filha nunca pode afrouxar as pos condicoes da classe mae. 
 * eu tenho um metodo da classe mae q retorna um int de 1 a 100 e eu tenho uma classe filha q devolve um int de 1 a 200 e isso pode 
 * quebrar as classes clientes. imagina q a classe cliente esta esperando um valor de 1 a 100 e eh isso q ela trata e a classe filha 
 * devole um valor 150, q o cliente n espera.
 * 
 * Para favorecer a composi��o, seguir os passos:
 * 1�: ver o q as classes tem de semelhante, no caso o saldo e levar para uma classe separada "ManipuladorDeSaldo", q vai ter o saldo, 
 * os metodos getSaldo, deposita, saca, rende
 * 2�: daih no construtor da classe ContaComum, inicia o atributo privado ManipuladorDeSaldo com new e no metodo rende, faz 
 * manipulador.rende(), no metodo deposita, faz manipulador.deposita(valor)
 * 3�: a mesma coisa para a classe COntaEstudante.
 * 
 */
public class ProcessadorDeInvestimentos {

    public static void main(String[] args) {
    	List<ContaComum> contasDoBanco = new ArrayList<>();

        for (ContaComum conta : contasDoBanco) {
        	
            conta.rende();

            System.out.println("Novo Saldo:");
            System.out.println(conta.getSaldo());
        }
    }
}