package br.com.solid.LSP.liskov_heranca_composicao.antes;

public class ContaNaoRendeException extends RuntimeException {

}
