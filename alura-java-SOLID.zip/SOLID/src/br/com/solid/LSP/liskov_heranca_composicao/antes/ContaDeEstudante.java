package br.com.solid.LSP.liskov_heranca_composicao.antes;

public class ContaDeEstudante extends ContaComum {

    public void rende()  {
        throw new ContaNaoRendeException();
    }
}