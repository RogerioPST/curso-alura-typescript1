package br.com.solid.LSP.liskov_heranca_composicao.apos_refatoracao_um;

public class ManipuladorDeSaldo {
	private double saldo;
	
	public void deposita(double valor) {
        this.saldo += valor;
    }

    public double getSaldo() {
        return saldo;
    }
    
    public void saca(double valor) {
    	if (valor <= this.saldo) {
    		this.saldo -= valor;    		
    	} else {
    		throw new IllegalArgumentException();
    	}
    }
    
    public void rende(double taxa) {
    	this.saldo *= taxa;
    }

}
