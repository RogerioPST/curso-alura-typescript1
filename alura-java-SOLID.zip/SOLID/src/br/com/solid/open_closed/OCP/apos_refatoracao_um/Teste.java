package br.com.solid.open_closed.OCP.apos_refatoracao_um;

public class Teste {
	
	public static void main(String[] args) {
		
		TabelaDePreco tabela = new TabelaDePrecoDiferenciada();
		ServicoDeEntrega entrega = new Frete();
		CalculadoraDePrecos calculadoraDePrecos = new CalculadoraDePrecos(tabela, entrega);
	}

}
