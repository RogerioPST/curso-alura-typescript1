package br.com.solid.open_closed.OCP.apos_refatoracao_um;

public interface TabelaDePreco {
	
	public double descontoPara(double valor);

}
