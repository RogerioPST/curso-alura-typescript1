package br.com.solid.open_closed.OCP.antes;



/*
 * o sistema abaixo funciona, mas imagina q a regra cresceu e q agora eu tenho a tabelaDePrecoDiferenciada e outra forma de entrega alem
 * dos correios, temos duas possibilidades: colocar if para regra1, e outro if para regra2 e a mesma coisa para o frete. nao parece uma 
 * ideia, pois codigo vai ficar complicado, a classe vai perder coesao, pq come�a saber de mta coisa, o acoplamento vai crescer pq ela 
 * vai depender da tabela de precos padrao, da diferenciada, dos correios, da empresa xpto e assim por diante.
 * 
 * as classes devem ser abertas - OCP:
 *	a ideia eh q as classes sejam abertas p extensao, ou seja, tenho q conseguir extender ela, ou seja, mudar o comportamento dela de 
 *maneira facil e ela tem q estar fechada para alteracao, ou seja, n tenho q ficar o tempo todo indo nela p mexer num if a mais, para
 *fazer uma modificacao ou coisa do tipo
 *
 *o objetivo eh evitar qualquer tipo de if
 *
 *PASSOS PARA REFATORACAO:
 *1�: a primeira coisa q preciso fazer eh pensar em uma abstracao, ja q tenho diferentes tabelas de preco, preciso pensar em uma 
 *abstracao comum entre todas elas e por enquanto, eh o metodo "double descontoPara(double valor)", para isso, crio a interface 
 *TabelaDePreco com esse metodo e TabelaPadrao implementa ela.
 *2�: crio a interface ServicoEntrega com o metodo "para(String cidade)" e Frete implementa essa interface.
 *
 *o new dessa classe abaixo me incomoda. o ponto eh q eu preciso fazer com que seja possivel trocar a implementacao da tabela de preco
 *e servi�o de entrega, como fazer isso?
 *R. receber pelo construtor e guardar em atributos da classe: 
 * "public CalculadoraDePrecos(TabelaDePreco tabela, ServicoDeEntrega entrega) {
		this.tabela = tabela;
		this.entrega = entrega;			}
 *
 *3�: jogo os dois news fora, pq vou receber os objetos usados no metodo calcula pelo construtor
 *4�: para ver essa mudan�a de comportamento da nova classe CalculadoraDePrecos sendo alterada, vou criar uma classe Teste:
 *"
 *TabelaDePreco tabela = new TabelaDePrecoDiferenciada();
		ServicoDeEntrega entrega = new Frete();
		CalculadoraDePrecos calculadoraDePrecos = new CalculadoraDePrecos(tabela, entrega);		"
		
		se eu der um new na tabelaDePrecoPadrao, o codigo continua funcionando, mas com comportamento diferente, pq eu mudei a 
		dependencia q ela recebe. isso q eh uma classe aberta para extensao e est� fechado, pq n vou precisar mexer nele.
		

 * isso eh programar OO: pensar em abstracao, pq qdo tenho uma abstracao, eu consigo evoluir o sistema implementacoes das abstracoes
 * criadas anteriormente
 * 
 * DIP - Principio de Inversao de Dependencia:
 * a ideia eh sempre q vc for depender, dependa de alguem mais estavel q vc; o principio vai mais longe: se vc esta numa classe, tenta 
 * depender de abstracao ; n pode depender de implementacoes e se vc esta numa abstracao, a ideia eh q a asbtracao n conhe�a a 
 * implementacao, mas sim apenas outras abstracoes
 * 
 * no caso, vai depender de duas interfaces mais estaveis : ServicoDeEntrega e TabelaDePrecos
 */
public class CalculadoraDePrecos {

    public double calcula(Compra produto) {
        TabelaDePrecoPadrao tabela = new TabelaDePrecoPadrao();
        Frete entrega = new Frete();

        double desconto = tabela.descontoPara(produto.getValor());
        double frete = entrega.para(produto.getCidade());

        return produto.getValor() * (1-desconto) + frete;
    }
}