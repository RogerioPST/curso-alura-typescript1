package br.com.solid.open_closed.OCP.apos_refatoracao_um;

public class TabelaDePrecoDiferenciada implements TabelaDePreco {

	@Override
	public double descontoPara(double valor) {
		// TODO Auto-generated method stub
		return 0;
	}

}
