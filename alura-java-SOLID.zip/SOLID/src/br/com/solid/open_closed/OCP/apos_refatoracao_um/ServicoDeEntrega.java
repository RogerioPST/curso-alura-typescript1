package br.com.solid.open_closed.OCP.apos_refatoracao_um;

public interface ServicoDeEntrega {
	
	public double para(String cidade);

}
