package br.com.solid.open_closed.OCP.antes;

public class Compra {

	public String getCidade() {
		// TODO Auto-generated method stub
		return null;
	}

	public double getValor() {
		// TODO Auto-generated method stub
		return 0;
	}

}
