package br.com.solid.acoplamento_e_estabilidade.antes;

public class NotaFiscalDao {

	public void persiste(NotaFiscal nf) {
		// TODO Auto-generated method stub
		System.out.println("salva no banco");
		
	}

}
