package br.com.solid.acoplamento_e_estabilidade.antes;

public class EnviadorDeEmail {

	public void enviaEmail(NotaFiscal nf) {
		// TODO Auto-generated method stub
		System.out.println("enviando email");
		
	}

}
