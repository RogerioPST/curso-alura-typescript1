package br.com.solid.acoplamento_e_estabilidade.antes;

/*
 * qual o problema desse codigo? do ponto de vista de acoplamento desse codigo?
 * imagina q amanha q ele tb vai ter q mandar p o SAP, enviar SMS, disparar outro sist da empresa etc., vai passar a depender de mtas 
 * outras classes.
 * 
 * pq acoplamento eh ruim? GeradorDeNotaFiscal -> EnviardoDeEmail - GeradorDeNotaFiscal depende de EnviadorDeEmail
 * o gde problema do acoplamento eh q uma mudan�a em qq uma das classes das q dependo e der um problema, o problema vai ser propagado
 * p a minha classe GeradorDeNotaFiscal.
 * a partir do momento q eu tenho varias dependencias, q a minha classe depende de varias, quer dizer q tenho mtas outras classes q podem 
 * propagar problemas p a minha classe principal. por isso o acoplamento eh ruim e a classe GeradorDeNotaFiscal fica FRAGIL.
 * 
 * classe GeradorDeNotaFiscal depende SAP, EnviadorDeEmail, DAO - acoplamento eferente - eu, classe, dependo de outras
 * classe ArrayList, LinkedList dependem de List - acoplamento aferente - quais classes q dependem de mim, isso faz c q essa classe List
 * seja estavel.
 * 
 * a ideia eh criar uma interface AcaoAposGerarNota, q vai ser mais estavel, pois vai ter classes q a implementam, q dependem dela
 * 
 * 
 */
public class GeradorDeNotaFiscal {

    private final EnviadorDeEmail email;
    private final NotaFiscalDao dao;

    public GeradorDeNotaFiscal(EnviadorDeEmail email, NotaFiscalDao dao) {
        this.email = email;
        this.dao = dao;
    }

    public NotaFiscal gera(Fatura fatura) {

        double valor = fatura.getValorMensal();

        NotaFiscal nf = new NotaFiscal(valor, impostoSimplesSobreO(valor));

        email.enviaEmail(nf);
        dao.persiste(nf);

        return nf;
    }

    private double impostoSimplesSobreO(double valor) {
        return valor * 0.06;
    }
}
