package br.com.solid.acoplamento_e_estabilidade.apos_refatoracao_um;

import java.util.List;

import br.com.solid.acoplamento_e_estabilidade.antes.Fatura;
import br.com.solid.acoplamento_e_estabilidade.antes.NotaFiscal;

public class GeradorDeNotaFiscal {
	
	private List<AcaoAposGerarNota> acoes;

	//padrao Observer - passo a depender de uma lista de acoesAposGerarNota e assim q acao acontece, notifico cada uma das acoes p q cada
	//uma fa�a o seu trabalho.
	public GeradorDeNotaFiscal(List<AcaoAposGerarNota> acoes) {		
		this.acoes = acoes;
		
	}
	
	public NotaFiscal gera(Fatura fatura) {

        double valor = fatura.getValorMensal();

        NotaFiscal nf = new NotaFiscal(valor, impostoSimplesSobreO(valor));
        
        for (AcaoAposGerarNota acaoAposGerarNota : acoes) {
        	acaoAposGerarNota.executa(nf);
		}
        
        return nf;
    }

    private double impostoSimplesSobreO(double valor) {
        return valor * 0.06;
    }

}
