package br.com.solid.acoplamento_e_estabilidade.apos_refatoracao_um;

import br.com.solid.acoplamento_e_estabilidade.antes.NotaFiscal;

public interface AcaoAposGerarNota {
	
	void executa(NotaFiscal nf);

}
