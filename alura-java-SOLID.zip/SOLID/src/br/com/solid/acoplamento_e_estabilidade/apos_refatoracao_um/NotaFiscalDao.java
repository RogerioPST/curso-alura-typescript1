package br.com.solid.acoplamento_e_estabilidade.apos_refatoracao_um;

import br.com.solid.acoplamento_e_estabilidade.antes.NotaFiscal;

public class NotaFiscalDao implements AcaoAposGerarNota{

	@Override
	public void executa(NotaFiscal nf) {
		System.out.println("exec dao - salva no banco");
		
	}

}
