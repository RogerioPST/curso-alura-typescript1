package br.com.solid.acoplamento_e_estabilidade.apos_refatoracao_um;

import br.com.solid.acoplamento_e_estabilidade.antes.NotaFiscal;

public class EnviadorDeEmail implements AcaoAposGerarNota{

	@Override
	public void executa(NotaFiscal nf) {
		System.out.println("envia email");
		
	}

}
