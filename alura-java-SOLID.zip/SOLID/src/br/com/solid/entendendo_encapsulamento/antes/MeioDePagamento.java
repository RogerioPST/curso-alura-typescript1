package br.com.solid.entendendo_encapsulamento.antes;

public enum MeioDePagamento {

    BOLETO,
    CARTAO
}