package br.com.solid.entendendo_encapsulamento.antes;

public class MaisUmaClasseSemEncapsulamento {
	
	public void algumMetodo() {
		/*
		Fatura fatura = pegaFaturaDeALgumLugar();
		fatura.getCliente().marcaComoInadimplente();
	
		 * 
		 * o correto seria fatura.marcaClienteComoInadimplente();
		 * 
		 * LEI DE DEMETER - evitar fazer invocacoes em cadeia
		 */
	}

}
