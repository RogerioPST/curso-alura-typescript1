package br.com.solid.entendendo_encapsulamento.antes;

import java.util.List;

/*
 * qual o problema do codigo?
 * n tem problema de acoplamento!
 * n tem problema de coesao; faz uma unica coisa
 * 
 * o problema aqui eh encapsulamento (ESCONDER A IMPLEMENTACAO). essa classe deveria processar boletos. e se eu fizer o 
 * processador de cartao de credito?
 * aqui tenho uma regra de negocio q est� no lugar errado:
 *  " total += fatura.getValor();"
 *  "if(total >= fatura.getValor()) {
            fatura.setPago(true);        }    "
            
    essa Regra n deveria estar aqui. deveria estar na Fatura. o problema eh q se amanha tiver cartao de credito, vai tem q repetir 
    codigo e vou ter q sair buscando no codigo onde esta aquela regra. tudo isso pq a regra n esta escondida.
    a fatura deve ser marcar como paga. ela q sabe qdo ela esta paga. ateh pq tem a lista de pagamentos. essa regra poderia estar la 
    dentro.
 */


public class ProcessadorDeBoletos {

    public void processa(List<Boleto> boletos, Fatura fatura) {
        double total = 0;
        for(Boleto boleto : boletos) {
            Pagamento pagamento = new Pagamento(boleto.getValor(),   
        MeioDePagamento.BOLETO);
            fatura.getPagamentos().add(pagamento);

            total += fatura.getValor();
        }

        if(total >= fatura.getValor()) {
            fatura.setPago(true);
        }
    }
}