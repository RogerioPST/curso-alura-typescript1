package br.com.solid.entendendo_encapsulamento.antes;

public class NotaFiscal {

	public int getvalosemimposto() {
		// TODO Auto-generated method stub
		return 0;
	}

	public double getvalor() {
		// TODO Auto-generated method stub
		return 0;
	}

}
