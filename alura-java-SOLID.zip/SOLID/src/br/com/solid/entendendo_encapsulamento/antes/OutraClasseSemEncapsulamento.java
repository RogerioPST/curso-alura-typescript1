package br.com.solid.entendendo_encapsulamento.antes;



/*
 * o problema desse codigo eh parecido.
 * esta mal encapsulado.
 * essa classe sabe demais como funciona uma NF. e quem deve saber? eh a propria classe NotaFiscal.
 * chama-se isso de intimidade inapropriada, pq esse codigo conhece demais a NF.
 * 
 * um dos principios eh o TELL, DON't ASK!!! qdo eu tenho um codigo q pergunta uma coisa p o obj p aih tomar uma decisao, eu tenho q dizer
 * p o objeto fazer algo, estou mandando o objeto fazer alguma coisa, como abaixo "nf.calculaValorImposto();"
 * 
 * 
 * resolveria assim: double valor = nf.calculaValorImposto(); //o q o metodo faz? calcula o valor do imposto
 *como ele faz isso? NAO sei! isso indica q esta encapsulado.
 * "
 * public calculaValorImposto(){
 * double valor;
		
		if (nf.getvalosemimposto() > 10000) {
			valor = 0.06 * nf.getvalor();
		} else {
			valor = 0.12 * nf.getvalor();
		}
return valor
}
 */
public class OutraClasseSemEncapsulamento {
	
	public static void main(String[] args) {
		
		NotaFiscal nf = new NotaFiscal();
		
		double valor;
		
		if (nf.getvalosemimposto() > 10000) {
			valor = 0.06 * nf.getvalor();
		} else {
			valor = 0.12 * nf.getvalor();
		}
	}

}
