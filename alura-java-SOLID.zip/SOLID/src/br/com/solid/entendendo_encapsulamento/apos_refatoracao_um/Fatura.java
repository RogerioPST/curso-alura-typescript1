package br.com.solid.entendendo_encapsulamento.apos_refatoracao_um;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import br.com.solid.entendendo_encapsulamento.antes.Pagamento;

public class Fatura {

    private String cliente;
    private double valor;
    private List<Pagamento> pagamentos;
    private boolean pago;

    public Fatura(String cliente, double valor) {
        this.cliente = cliente;
        this.valor = valor;
        this.pagamentos = new ArrayList<Pagamento>();
        this.pago = false;
    }

    public String getCliente() {
        return cliente;
    }

    public double getValor() {
        return valor;
    }

    public List<Pagamento> getPagamentos() {
    	
        return Collections.unmodifiableList(pagamentos);
    }

    public boolean isPago() {
        return pago;
    }

	public void adicionaPagamento(Pagamento pagamento) {
		// TODO Auto-generated method stub
		this.pagamentos.add(pagamento);
		
		if (valorTotalDosPagamentos() > this.valor) {
			this.pago = true;
		}
		
	}

	private double valorTotalDosPagamentos() {
		// TODO Auto-generated method stub
		double total = 0;
		for (Pagamento p : pagamentos) {
			total += p.getValor();
			
		}
		return total;
	}
    
    

}