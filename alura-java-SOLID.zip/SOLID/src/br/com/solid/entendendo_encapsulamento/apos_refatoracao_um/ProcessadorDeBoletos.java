package br.com.solid.entendendo_encapsulamento.apos_refatoracao_um;

import java.util.List;

import br.com.solid.entendendo_encapsulamento.antes.Boleto;
import br.com.solid.entendendo_encapsulamento.antes.MeioDePagamento;
import br.com.solid.entendendo_encapsulamento.antes.Pagamento;

public class ProcessadorDeBoletos {

    public void processa(List<Boleto> boletos, Fatura fatura) {
        
        for(Boleto boleto : boletos) {
            Pagamento pagamento = new Pagamento(boleto.getValor(),   
        MeioDePagamento.BOLETO);
            
            
            fatura.adicionaPagamento(pagamento);            
    

        
        }

        
    }
}