package br.com.solid.coesao_e_SRP.antes;



/*
 * SINGLE RESPONSIBILITY PRINCIPLE
 * 
 * C�DIGO N�O � COESO!!
 * A PRIMEIRA DICA � A SEGUINTE: EU PARO E PENSO: SER� QUE ESSA CLASSE VAI PARAR DE CRESCER? SE A CLASSE � COESA, OU SEJA, ELA TEM UMA 
 * UNICA RESPONSABILIDADE, ELA CUIDA DE APENAS UMA UNICA PARTE DO MEU SISTEMA, REPRESENTA UMA UNICA ENTIDADE, ELA TEM QUE PARAR DE CRESCER
 * UM DIA, POIS AS RESPONSABILIDADES DE UMA ENTIDADE PARAM DE APARECER UM DIA.
 * NESSE CASO, N�O � COESA, PQ SEMPRE Q CRIAR UM CARGO NOVO PARA O SISTEMA, VOU TEM QUE ALTERAR ESSA CLASSE. IMAGINA NO MUNDO REAL QUE TEM 30,40
 * CARGOS E VARIAS REGRAS DIFERENTES, O Q VAI ACONTECER C ESSA CLASSE? VAI FICAR GIGANTE COM CODIGO COMPLICADO!!
 * 
 * CODIGO DIFICIL DE MANTER
 * POSSIVEL DE TER VARIOS BUGS
 * REUSO MENOR, POIS FAZ MTA COISA, POIS O OUTRO SISTEMA RARAMENTE VAI PRECISAR TD Q ELA FAZ.
 * BATERIA IMENSA DE TESTES PARA CADA REGRA
 * 
 * A IDEA DE REFATORAR �?
 * PEGAR CADA REGRA DE CALCULO DEZOUVINTEPORCENTO, TRINTAOUQUARENTAPROCENTO, SEI LA E COLOCAR CADA UMA DESSAS REGRAS EM UM UNICO LUGAR;
 * VOU TER DOIS METODOS PRIVADOS E IMAGINA QUE CADA UM DESSES METODOS, EU VAH LEVAR PARA UMA CLASSE EM PARTICULAR.
 * O Q VOU GANHAR? CADA CLASSE SERAH COESA, POIS CADA CLASSE TERA UMA UNICA RESPONSABILIDADE: ENTENDER A SUA REGRA DE PORCENTAGEM.
 * 
 * 
 * PASSOS DA REFATORA��O INICIAL:
 * 1�: vou extrair o metodo privado abaixo (dezOuVintePorcento) e jogar para a classe DezOuVintePorCento
 * 2�: vou extrair o metodo privado abaixo (quinzeOuVinteCincoPorcento) e jogar para a classe quinzeOuVinteCincoPorcento
 * 3�: criar a interface RegraDeCalculo com o metodo "public double calcula(Funcionario funcionario);"
 * 4�: DezOuVintePorCento vai implementar essa interface, mudar o nome do metodo para calcula e public
 * 5�: quinzeOuVinteCincoPorcento vai implementar essa interface, mudar o nome do metodo para calcula e public
 * 6� ao inv�s de chamar "return dezOuVintePorcento(funcionario);", vou chamar "return new DezOuVintePorCento().calcula(funcionario);"
 * 7� ao inv�s de chamar "return quinzeOuVinteCincoPorcento(funcionario);", vou chamar "return new QuinzeOuVinteCincoPorcento().calcula(funcionario);"
 * 
 * COM ISSO, J� MELHORA, MAS A CLASSE CALCULADORADESALARIO APOS A PRIMEIRA REFATORACAO AINDA N VAI PARAR DE CRESCER. PARA RESOLVER ESSE 
 * PROBLEMA,  
 * PASSOS PARA A PROXIMA E ULTIMA REFATORACAO:
 * 1�: como todo cargo que for criado, tem um tipo de regra de calculo de salario, vou passar para ele o tipo de regradecalculo para ele:
 * public enum Cargo {	DESENVOLVEDOR (new DezOuVintePorCento()),	TESTER(new QuinzeOuVinteCincoPorcento()),	DBA(new QuinzeOuVinteCincoPorcento())}
 * 2�: as pessoas esquecem q o ENUM � quase uma classe e posso criar um construtor para ele que vai receber a regra de calculo e guardar no atributo.
 * Cargo(RegraDeCalculo regra){		this.regra = regra;		}
 * 3�: crio o getter desse atributo regra.
 * 4�: o metodo da classe CalculadoraDeSalario fica igual para todos "public double calcula(Funcionario funcionario) {
		return funcionario.getCargo().getRegra().calcula(funcionario);
	}"
 * 
 * 
 * 
 * 
 * 
 * 
 */

public class CalculadoraDeSalario {

	public double calcula(Funcionario funcionario) {
		if (Cargo.DESENVOLVEDOR.equals(funcionario.getCargo())) {
			return dezOuVintePorcento(funcionario);
		}

		if (Cargo.DBA.equals(funcionario.getCargo()) || Cargo.TESTER.equals(funcionario.getCargo())) {
			return quinzeOuVinteCincoPorcento(funcionario);
		}

		throw new RuntimeException("funcionario invalido");
	}

	private double dezOuVintePorcento(Funcionario funcionario) {
		if (funcionario.getSalarioBase() > 3000.0) {
			return funcionario.getSalarioBase() * 0.8;
		} else {
			return funcionario.getSalarioBase() * 0.9;
		}
	}

	private double quinzeOuVinteCincoPorcento(Funcionario funcionario) {
		if (funcionario.getSalarioBase() > 2000.0) {
			return funcionario.getSalarioBase() * 0.75;
		} else {
			return funcionario.getSalarioBase() * 0.85;
		}
	}

}
