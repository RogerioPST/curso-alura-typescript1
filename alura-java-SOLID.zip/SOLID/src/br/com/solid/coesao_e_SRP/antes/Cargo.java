package br.com.solid.coesao_e_SRP.antes;

public enum Cargo {
    DESENVOLVEDOR,
    DBA,
    TESTER
}
