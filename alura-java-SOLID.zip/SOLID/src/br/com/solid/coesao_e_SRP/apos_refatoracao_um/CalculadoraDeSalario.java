package br.com.solid.coesao_e_SRP.apos_refatoracao_um;

import br.com.solid.coesao_e_SRP.antes.Cargo;
import br.com.solid.coesao_e_SRP.antes.Funcionario;

public class CalculadoraDeSalario {

	public double calcula(Funcionario funcionario) {
		if (Cargo.DESENVOLVEDOR.equals(funcionario.getCargo())) {
			return new DezOuVintePorCento().calcula(funcionario);
		}

		if (Cargo.DBA.equals(funcionario.getCargo()) || Cargo.TESTER.equals(funcionario.getCargo())) {
			return new QuinzeOuVinteCincoPorcento().calcula(funcionario);
		}

		throw new RuntimeException("funcionario invalido");
	}	

}
