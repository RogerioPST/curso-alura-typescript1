package br.com.solid.coesao_e_SRP.apos_refatoracao_um;

import br.com.solid.coesao_e_SRP.antes.Funcionario;

public interface RegraDeCalculo {
	
	public double calcula(Funcionario funcionario);

}
