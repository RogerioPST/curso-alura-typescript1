package br.com.solid.coesao_e_SRP.apos_refatoracao_dois;

public enum Cargo {
	DESENVOLVEDOR(new DezOuVintePorCento()),
	TESTER(new QuinzeOuVinteCincoPorcento()), 
	DBA(new QuinzeOuVinteCincoPorcento());
	
	private RegraDeCalculo regra;
	
	Cargo(RegraDeCalculo regra){
		this.regra = regra;		
	}
	
	public RegraDeCalculo getRegra() {
		return regra;
	}	
}
