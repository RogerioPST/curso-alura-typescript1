package br.com.solid.coesao_e_SRP.apos_refatoracao_dois;



public interface RegraDeCalculo {
	
	public double calcula(Funcionario funcionario);

}
