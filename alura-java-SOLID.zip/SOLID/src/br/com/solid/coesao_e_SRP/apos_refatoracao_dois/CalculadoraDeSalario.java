package br.com.solid.coesao_e_SRP.apos_refatoracao_dois;



public class CalculadoraDeSalario {
	
	public double calcula(Funcionario funcionario) {
		return funcionario.getCargo().getRegra().calcula(funcionario);
	}

}
