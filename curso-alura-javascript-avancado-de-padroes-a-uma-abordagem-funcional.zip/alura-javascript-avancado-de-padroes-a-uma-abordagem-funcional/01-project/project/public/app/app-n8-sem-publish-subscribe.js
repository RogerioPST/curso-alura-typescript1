
import {log, timeoutPromise, retry} from "./utils/promise-helpers.js";
//como soh quero carregar o codigo de array-helpers.js, faço assim, assim como qdo uso rxjs
import "./utils/array-helpers.js"

import {notasService as service} from "./nota/service.js";

import {takeUntil, debounceTime, partialize, pipe} from './utils/operators.js';


testaPartialApllication();
testaShowMessage();
testaDebounce();
testeParaCriarComposeParaDebounce();
testeComPromiseRace();





//por mais q use pipe, ele exec primeiro takeUntil e depois debounce
//por isso, vou inverter
//export const pipe = (...fns) => value => 
    //esse value vai ser o valor inicial, o parametro que coloquei em sumItens(notas) vai ser o previousValue na primeira chamada

    // ele vai chamar a primeira funcao q eh getItensFrom Notas sobre notas
    //aih o resultado (por isso coloquei esse value abaixo) disso vai ser o previousValue na prox iteracao
    //dai vai chamar o filterItens passando o resultado da funcao anterior
    //acabando, ele vai para sumItensValue com o resultado de filterItens
    //p no final retornar o valor final, a soma total
    //fns.reduce((previousValue, fn) => fn(previousValue), value);
//o operation qdo a gente receber operations, estou passando pipe q vai me retornar uma funcao q recebe um unico parametro (value)
//e qdo chamar operations, vai exec todas as op dentro do array e dar o resultado final.
//o curioso eh q qdo chamarmos o operations, ele vai pegar esse cara q vou chamar de OPERACAO A "() => 
//    service
  //  .sumItens('2143')
    //a funcao log foi criado soh p facilitar o console.log
    //.then(log)
    //.catch(log)
    //);" 
    //e passar para a primeira funcao q é o debounceTime
    //ai o debounceTime vai receber esse callback e vai me devolver uma nova funcao q estah esperando ser chamada p efetivamente ser executada
    //esse trecho "fn(previousValue)" n executa, esta devolvendo uma funcao configurada p chamar essa OPERACAO A q passei
    //essa fc configurada vai ser passada como parametro p takeuntil e takeuntil como eh a ultima ,vai retornar uma funcao, no caso o action, q qdo for chamada
    //vai chamar o takeuntil e se o takeuntil executou, vai chamar o callback q foi passado q eh o do debounce.
    //se eu quiser corrigir esse problema, tenho q inverter a ordem
    //olha o q vai ocorrer invertendo:
    //chamei o pipe passando as duas funcoes, vai retornar uma nova funcao q recece um unico valor, q nocaso eh operations
    //qdo chamar operations, vai na primeira funcao q eh takeuntil e pega takeuntil e o retorno de takeuntil q eh a funcao configurada q ao ser chamada vai executar a funcao passada p takeuntil
    //vai ser passada p debounce e essa do debounce, q vai serr o callback do debounce, vai devolver a funcao configurada q qdo eu chamar, vai executar o debounce
    //entao, eh nessa ordem, como debounce foi o ultimo a retornar, vai chamar a funcao do debounce, q vai chamar do takeuntil 
    //a ordem diferente por causa dos callbacks
    //posso usar o pipe, mas qdo estou trabalhando c retornos q sao cb das outras funcoes, tenho q inverter
const operations = pipe(
    
    partialize(takeUntil, 3)        ,
    partialize(debounceTime,500),
);



//a action vai ser o resultado de operations, pq no final vou receber uma funcao configurada
//na verdade, está recebendo uma funcao q precisa de algo q ela vai encapsular p ser chamada depois
//operations está recebendo a minha logica e estou guardando em action. ela n executou.
//qdo chamar action, vai chamar as operations
const action = operations(() => 
//dando timeout na promise é emparelhar a promise q receber como parametro coom uma promise q vai utilizar 
//esse valor do timeout passado como parametro (200, no caso)
    //para o retry, param1 - qtd de tentantivas
    //param2, tempo de espera entre as tentativas
    //param3 - eh uma funcao q ao ser chamada, retorna uma promise
    //n pode passar direto a promise, pq uma promise depois de resolvida ou rejeitada, ela n pode ser usada novamente
    retry(3, 3000, () => timeoutPromise(200, service.sumItens('2143')))
    //delay de execucao de 5 segundos p trazer o resultado
    //.then(delay(5000))
    //a funcao log foi criado soh p facilitar o console.log
    .then(log)
    .catch(log)
    );

    /*
//soh posso chamar 3 vezes a funcao
const operation = takeUntil(3, () => 
    service
    .sumItens('2143')
    //a funcao log foi criado soh p facilitar o console.log
    .then(log)
    .catch(log)
    );

    const operation_debounce = debounceTime(500, operation);
*/




document
    .querySelector('#myButton')

    .onclick = action;    
    //ou
    //.onclick = operation_debounce;    
    //ou
    //.onclick = () => operation();
    //

/*
funciona, mas o instrutor preferiu deixar como acima
document
    .querySelector('#myButton')
    .onclick = () => {
        fetch('http://localhost:3000/notas')
        .then(handleStatus)     
        .then(notas => notas.$flatMap(nota => nota.itens))
        //a funcao log foi criado soh p facilitar o console.log
        .then(log)
        .then(itens => itens.filter(item => item.codigo == '2143'))   
        .then(log)
        .then(itens => itens.reduce((total, item) => total + item.valor, 0))
        .then(console.log)
        .catch(console.log);

    }
*/

/*
usando sem importar de um helper
document
    .querySelector('#myButton')
    .onclick = () => {
        fetch('http://localhost:3000/notas')
        .then(res => { 
            if (res.ok){
                return res.json();
            } 
            return Promise.reject(res.statusText);
        })        
        .then(notas => console.log(notas))
        .catch(console.log);

    }
    */

   function testeComPromiseRace(){


    const p1 = new Promise((resolve, reject) =>
    setTimeout(() => resolve('promise 1 terminou'),3000)
    );
    
    const p2 = new Promise((resolve, reject) =>
    setTimeout(() => resolve('promise 2 terminou'),1000)
    );
    
    //as duas promises serao executadas em paralelo, mas no then, so vou pegar o resultado da primeira q for resolvido
    //por isso, eh uma corrida
    Promise.race([p1,p2])
    .then(log)
    .catch(log);
    
    }
    
   function testeParaCriarComposeParaDebounce(){


    const partializedTakeUntil = partialize(takeUntil, 2);
    
    const doTake = partializedTakeUntil(() => console.log('teste c compose p debounce'));
    
    doTake();
    doTake();
    doTake();
    }
    
    
function testaDebounce(){


    const showMessage3 = () => console.log('Opa!');
    const operation2 = debounceTime(500, showMessage3);
    operation2();
    operation2();
    operation2();
    }

   function testaShowMessage(){

    const showMessage = () => console.log('oi');
    const operation1 = takeUntil(3, showMessage);


    let counter = 10;
    while(counter--){
        operation1();
    }
}


   function testaPartialApllication() {


    //inicio de partial application
    const ehDivisivel = (divisor, numero) => !(numero % divisor);
    
    //toda funcao tem uma funcao bind, q permite criar uma nova funcao, q permite mudar o this, mas como n quero, mando null
    //
    const ehDivisivelPorDois = ehDivisivel.bind(null, 2);
    
    const fn_devolve_false = ehDivisivel.bind(null, 2, 5);
    
    const fn_devolve_true = ehDivisivel.bind(null, 2, 6);
    
    log('vai devolver false');
    console.log(fn_devolve_false());
    log('vai devolver true');
    console.log(fn_devolve_true());
    
    //fim de partial application
    
    log(ehDivisivelPorDois(10));
    log(ehDivisivelPorDois(5));
    log(ehDivisivelPorDois(12));
    
    
    /* funciona, mas dah p separar a responsabilidade como acima
    log(ehDivisivel(2,10));
    log(ehDivisivel(2,5));
    log(ehDivisivel(2,12));
    */
    }