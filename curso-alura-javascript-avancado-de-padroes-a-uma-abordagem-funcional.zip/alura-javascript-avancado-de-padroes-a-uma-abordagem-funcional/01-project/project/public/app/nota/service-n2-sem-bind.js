//como estou usando o sistema de importação de modulos do navegador, soh preciso importar o app, q qdo for necessario,
//o navegador vai importar o arquivo promise-helpers automaticamente
import {handleStatus} from "../utils/promise-helpers.js";

const API = "http://localhost:3000/notas";

const getItensFromNotas = notas => notas.$flatMap(nota => nota.itens);
const filterItensByCode = (code, itens) => itens.filter(item => item.codigo == code);
const sumItensValue = itens => itens.reduce((total, item) => total + item.valor, 0);

const sumItens = code => notas => notas;





export const notasService ={

    listAll(){
        return fetch(API).then(handleStatus);
    },

    sumItens(code){
        return this.listAll().then(sumItens(code))   ;
    }

};