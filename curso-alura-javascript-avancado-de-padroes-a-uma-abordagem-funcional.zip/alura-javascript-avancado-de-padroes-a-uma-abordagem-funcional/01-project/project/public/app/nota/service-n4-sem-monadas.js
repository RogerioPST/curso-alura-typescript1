//como estou usando o sistema de importação de modulos do navegador, soh preciso importar o app, q qdo for necessario,
//o navegador vai importar o arquivo promise-helpers automaticamente
import {handleStatus} from "../utils/promise-helpers.js";

import {partialize, pipe} from '../utils/operators.js';

const API = "http://localhost:3000/notas";

const getItensFromNotas = notas => notas.$flatMap(nota => nota.itens);
const filterItensByCode = (code, itens) => itens.filter(item => item.codigo == code);

const sumItensValue = itens => itens.reduce((total, item) => total + item.valor, 0);

const sumItens = code => notas => notas;




export const notasService ={

    listAll(){
        return fetch(API)
            .then(handleStatus)
            //sem monadas
            .then(notas => {
                if(notas) return notas;
                return [];
            })
            .catch( err =>{
                console.log(err);
                return Promise.reject('n foi possivel obter as notas fiscais');
            });
    },

    sumItens(code){
        //fazendo bind sem partialize
        //partial application
        //const filterItens = filterItensByCode.bind(null, code);
        //fim
        const filterItens = partialize(filterItensByCode, code);

        const sumItens = pipe(getItensFromNotas, filterItens,sumItensValue);

        return this.listAll()
            //point free functions
            //em nenhum momento, passo parametro
            .then(sumItens);
    }

};