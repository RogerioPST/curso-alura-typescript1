//como estou usando o sistema de importação de modulos do navegador, soh preciso importar o app, q qdo for necessario,
//o navegador vai importar o arquivo promise-helpers automaticamente
import {handleStatus} from "../utils/promise-helpers.js";

import {partialize} from '../utils/operators.js';

const API = "http://localhost:3000/notas";

const getItensFromNotas = notas => notas.$flatMap(nota => nota.itens);
const filterItensByCode = (code, itens) => itens.filter(item => item.codigo == code);

const sumItensValue = itens => itens.reduce((total, item) => total + item.valor, 0);

const sumItens = code => notas => notas;




export const notasService ={

    listAll(){
        return fetch(API)
            .then(handleStatus)
            .catch( err =>{
                console.log(err);
                return Promise.reject('n foi possivel obter as notas fiscais');
            });
    },

    sumItens(code){
        //fazendo bind sem partialize
        //partial application
        //const filterItens = filterItensByCode.bind(null, code);
        //fim
        const filterItens = partialize(filterItensByCode, code);
        return this.listAll()
            .then(notas => sumItensValue(
                            filterItens(
                                getItensFromNotas(notas)
                            )
                           )
            );
    }

};