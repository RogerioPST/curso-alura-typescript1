//como estou usando o sistema de importação de modulos do navegador, soh preciso importar o app, q qdo for necessario,
//o navegador vai importar o arquivo promise-helpers automaticamente
import {handleStatus} from "../utils/promise-helpers.js";

const API = "http://localhost:3000/notas";


//essa funcao devolve uma funcao recebendo como parametro o codigo
const sumItens = code => notas => notas
.$flatMap(nota => nota.itens)
.filter(item => item.codigo == code)
.reduce((total, item) => total + item.valor, 0);

export const notasService ={

    listAll(){
        return fetch(API).then(handleStatus);
    },

    sumItens(code){
        return this.listAll().then(sumItens(code))   ;
    }

};