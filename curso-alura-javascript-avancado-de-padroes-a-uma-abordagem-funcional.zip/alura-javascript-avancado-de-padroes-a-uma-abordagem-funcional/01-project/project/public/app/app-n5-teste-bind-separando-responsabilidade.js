
import {log} from "./utils/promise-helpers.js";
//como soh quero carregar o codigo de array-helpers.js, faço assim, assim como qdo uso rxjs
import "./utils/array-helpers.js"

import {notasService as service} from "./nota/service.js";


//inicio de partial application
const ehDivisivel = (divisor, numero) => !(numero % divisor);

//toda funcao tem uma funcao bind, q permite criar uma nova funcao, q permite mudar o this, mas como n quero, mando null
//
const ehDivisivelPorDois = ehDivisivel.bind(null, 2);

const fn_devolve_false = ehDivisivel.bind(null, 2, 5);

const fn_devolve_true = ehDivisivel.bind(null, 2, 6);

log('vai devolver false');
console.log(fn_devolve_false());
log('vai devolver true');
console.log(fn_devolve_true());

//fim de partial application

log(ehDivisivelPorDois(10));
log(ehDivisivelPorDois(5));
log(ehDivisivelPorDois(12));


/* funciona, mas dah p separar a responsabilidade como acima
log(ehDivisivel(2,10));
log(ehDivisivel(2,5));
log(ehDivisivel(2,12));
*/


document
    .querySelector('#myButton')
    .onclick = () => {
        service
        .sumItens('2143')
        //a funcao log foi criado soh p facilitar o console.log
        .then(log)        
        .then(log)        
        .then(console.log)
        .catch(console.log);

    }

/*
funciona, mas o instrutor preferiu deixar como acima
document
    .querySelector('#myButton')
    .onclick = () => {
        fetch('http://localhost:3000/notas')
        .then(handleStatus)     
        .then(notas => notas.$flatMap(nota => nota.itens))
        //a funcao log foi criado soh p facilitar o console.log
        .then(log)
        .then(itens => itens.filter(item => item.codigo == '2143'))   
        .then(log)
        .then(itens => itens.reduce((total, item) => total + item.valor, 0))
        .then(console.log)
        .catch(console.log);

    }
*/

/*
usando sem importar de um helper
document
    .querySelector('#myButton')
    .onclick = () => {
        fetch('http://localhost:3000/notas')
        .then(res => { 
            if (res.ok){
                return res.json();
            } 
            return Promise.reject(res.statusText);
        })        
        .then(notas => console.log(notas))
        .catch(console.log);

    }
    */