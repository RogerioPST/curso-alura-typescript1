
import {log} from "./utils/promise-helpers.js";
//como soh quero carregar o codigo de array-helpers.js, faço assim, assim como qdo uso rxjs
import "./utils/array-helpers.js"

import {notasService as service} from "./nota/service.js";





document
    .querySelector('#myButton')
    .onclick = () => {
        service
        .sumItens('2143')
        //a funcao log foi criado soh p facilitar o console.log
        .then(log)        
        .then(log)        
        .then(console.log)
        .catch(console.log);

    }

/*
funciona, mas o instrutor preferiu deixar como acima
document
    .querySelector('#myButton')
    .onclick = () => {
        fetch('http://localhost:3000/notas')
        .then(handleStatus)     
        .then(notas => notas.$flatMap(nota => nota.itens))
        //a funcao log foi criado soh p facilitar o console.log
        .then(log)
        .then(itens => itens.filter(item => item.codigo == '2143'))   
        .then(log)
        .then(itens => itens.reduce((total, item) => total + item.valor, 0))
        .then(console.log)
        .catch(console.log);

    }
*/

/*
usando sem importar de um helper
document
    .querySelector('#myButton')
    .onclick = () => {
        fetch('http://localhost:3000/notas')
        .then(res => { 
            if (res.ok){
                return res.json();
            } 
            return Promise.reject(res.statusText);
        })        
        .then(notas => console.log(notas))
        .catch(console.log);

    }
    */