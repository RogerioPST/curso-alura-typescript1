//vai encapsular o valor q pode ser nulo ou undefined
//eh um wrapper, embrulha o cara q está lah dentro
//p prevenir o acesso ao valor nulo ou undefined
export class Maybe {
    constructor(value){
        this._value = value;
    }

    static of (value){
        return new Maybe(value);
    }

    isNothing(){
        return this._value === null || this._value === undefined;
    }
    //um map
    //vai pegar o dado q tem dentro dele q eu quero trabalhar e eu posso aplicar uma logica de transofrmação
    //
    map(fn){
        //n corre o risco de acessar alguem nulo dentro do map
        if(this.isNothing()) return Maybe.of(null);
        const value = fn(this._value);
        return Maybe.of(value);
    }
    getOrElse(value){
        if (this.isNothing()) return value;
        return this._value;
    }
}