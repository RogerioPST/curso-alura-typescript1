
const events = new Map();
//nome do evento vai ser a chave
//e o valor vai ser um array p todos os listeners daquele evento

export const EventEmitter = {
    on(event, listener){
        //se n ter o nome do evento na chave, vou criar
        if(!events.has(event)) events.set(event, []);
        events.get(event).push(listener);

    },

    emit(event, data){

        const listeners = events.get(event);
        //para cada listener, passo o dado (no caso, o total) para eles p notifica-los
        //mas o q acontece se eu emitir p um evento q n tem ninguem escutando, n vai existir a chave event
        if(listeners)
            listeners.forEach(listener => listener(data));

    }
};