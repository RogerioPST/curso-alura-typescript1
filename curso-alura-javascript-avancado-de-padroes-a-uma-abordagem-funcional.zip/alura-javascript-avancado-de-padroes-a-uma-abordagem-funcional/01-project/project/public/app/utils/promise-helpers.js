//como está num módulo e vou querer usar dentro de app, usar export
export const handleStatus = res => res.ok ? res.json() : Promise.reject(res.statusText);

export const log = param => {
    console.log(param);
    return param;

}
//vou chamar o timeout, vou passar a qtd de milisegundos e a promise
//e vai retornar o resultado de quem terminar primeiro
export const timeoutPromise = (mileseconds, promise) => {
    const timeout = new Promise((resolve, reject) =>
        setTimeout(() => 
            reject(`limite da promise excedido (limite: ${mileseconds} ms)`), 
            mileseconds));
    return Promise.race([timeout, promise]);
};

//chamei a fc passando 5000, retorna uma nova funcao q recebe um parametro qq (data)
//e essa funcao q vai estar no then e essa funcao q vai receber as notas
//depois de tantos milisegundos, vai resolver a promise passando data
//e soh no momento dessa resolucao q vai partir p o prox then, repassando os dados q ele recebeu
export const delay = miliseconds => data =>
new Promise((resolve, reject) => 
        setTimeout(() => resolve(data), miliseconds));

//para o retry, param1 - qtd de tentantivas
    //param2, tempo de espera entre as tentativas
    //param3 - eh uma funcao q ao ser chamada, retorna uma promise
    //n pode passar direto a promise, pq uma promise depois de resolvida ou rejeitada, ela n pode ser usada novamente
export const retry = (retries, miliseconds, fn) =>
    fn().catch(err => {                
        console.log(retries);
        //dentro do catch de uma promise, posso retornar outra promise
        //esse delay vai me retornar uma funcao configurada p realizar o delay
        return delay(miliseconds)().then(() => 
            retries > 1 
            ? retry(--retries, miliseconds, fn)
            : Promise.reject(err))

    })