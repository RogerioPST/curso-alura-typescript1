//funcao q devolve o bind c rest operator e spread operators
//partial application
export const partialize = (fn, ...args) => fn.bind(null, ...args);

//vai receber n funcoes
export const compose = (...fns) => value => 
    //esse value vai ser o valor inicial, o parametro que coloquei em sumItens(notas) vai ser o previousValue na primeira chamada

    // ele vai chamar a primeira funcao q eh getItensFrom Notas sobre notas
    //aih o resultado (por isso coloquei esse value abaixo) disso vai ser o previousValue na prox iteracao
    //dai vai chamar o filterItens passando o resultado da funcao anterior
    //acabando, ele vai para sumItensValue com o resultado de filterItens
    //p no final retornar o valor final, a soma total
    fns.reduceRight((previousValue, fn) => fn(previousValue), value);

//vai receber n funcoes
export const pipe = (...fns) => value => 
    //esse value vai ser o valor inicial, o parametro que coloquei em sumItens(notas) vai ser o previousValue na primeira chamada

    // ele vai chamar a primeira funcao q eh getItensFrom Notas sobre notas
    //aih o resultado (por isso coloquei esse value abaixo) disso vai ser o previousValue na prox iteracao
    //dai vai chamar o filterItens passando o resultado da funcao anterior
    //acabando, ele vai para sumItensValue com o resultado de filterItens
    //p no final retornar o valor final, a soma total
    fns.reduce((previousValue, fn) => fn(previousValue), value);

export const takeUntil = (times, fn) => 
    () => {
        if (times-- >0) fn();
    }


    //funcao criada para impedir mais cliques antes da janela de os milisegundos passados como parametro
export const debounceTime = (miliseocnds, fn) =>{

 let timer = 0;
 return () => {
     clearTimeout(timer);
     timer = setTimeout(fn, miliseocnds);
    }
}