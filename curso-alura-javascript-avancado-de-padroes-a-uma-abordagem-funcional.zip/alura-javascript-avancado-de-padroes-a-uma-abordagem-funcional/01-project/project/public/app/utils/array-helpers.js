/*
Functor
No jargão da programação funcional um Functor é simplesmente algo mapeável, ou seja, que suporta a operação map. Vimos que a função map do Functor Array não resolve nosso problema pois retorna a cada iteração um dado multidimensional. No entanto, existe um map especial chamado flatMap, o qual garante que os dados tenham uma dimensão apenas.

A palavra flat remete à plano, única dimensão. A má notícia é que o ECMASCRIPT ainda não adicionou o suporte à função flatMap, apesar de ter sido proposta. Nesse sentido, que tal criarmos nossa própria implementação de flatMap e adicioná-la no functor Array?
*/
if(!Array.prototype.$flatMap){
    Array.prototype.$flatMap = function(cb){
        //o callback - cb vai ser o nota => nota.itens
        return this.map(cb).reduce((destArray, array) =>
            destArray.concat(array), []);
    }
}