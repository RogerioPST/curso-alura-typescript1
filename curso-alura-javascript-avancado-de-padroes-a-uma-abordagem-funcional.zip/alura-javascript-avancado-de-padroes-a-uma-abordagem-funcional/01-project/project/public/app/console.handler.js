import {EventEmitter} from "./utils/event-emitter.js";

EventEmitter.on('itensTotalizados', console.log);