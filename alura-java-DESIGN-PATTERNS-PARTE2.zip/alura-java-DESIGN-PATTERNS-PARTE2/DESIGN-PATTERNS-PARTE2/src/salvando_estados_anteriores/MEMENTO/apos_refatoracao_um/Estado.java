package salvando_estados_anteriores.MEMENTO.apos_refatoracao_um;



public class Estado {
	
	private Contrato contrato;

	public Estado(Contrato contrato) {
		this.contrato = contrato;
		// TODO Auto-generated constructor stub
	}
	
	public Contrato getContrato() {
		return contrato;
	}

}
