package salvando_estados_anteriores.MEMENTO.apos_refatoracao_um;

import java.util.Calendar;

import salvando_estados_anteriores.MEMENTO.antes.TipoContrato;

public class TesteDeContrato {
	public static void main(String[] args) {
		Historico historico = new Historico();
		Contrato c1 = new Contrato(Calendar.getInstance(), "Rogerio", TipoContrato.NOVO);
		historico.adiciona(c1.salvaEstado());
		
		System.out.println(c1.getTipo());
		c1.avanca();
		System.out.println(c1.getTipo());
		historico.adiciona(c1.salvaEstado());
		c1.avanca();
		System.out.println(c1.getTipo());
		historico.adiciona(c1.salvaEstado());
		System.out.println(c1.getTipo());
		
		Estado estadoAnterior = historico.pega(1);
		System.out.println(estadoAnterior);
		System.out.println(estadoAnterior.getContrato().getTipo());
		
	}

}
