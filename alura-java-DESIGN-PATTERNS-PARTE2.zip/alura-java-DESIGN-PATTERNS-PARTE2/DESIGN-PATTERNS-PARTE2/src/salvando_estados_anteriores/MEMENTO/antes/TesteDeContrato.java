package salvando_estados_anteriores.MEMENTO.antes;

import java.util.Calendar;

public class TesteDeContrato {
	public static void main(String[] args) {
		Contrato c1 = new Contrato(Calendar.getInstance(), "Rogerio", TipoContrato.NOVO);
		
		System.out.println(c1.getTipo());
		c1.avanca();
		System.out.println(c1.getTipo());
	}

}
