package salvando_estados_anteriores.MEMENTO.antes;

public enum TipoContrato {
	NOVO, EM_ANDAMENTO, ACERTADO, CONCLUIDO

}
