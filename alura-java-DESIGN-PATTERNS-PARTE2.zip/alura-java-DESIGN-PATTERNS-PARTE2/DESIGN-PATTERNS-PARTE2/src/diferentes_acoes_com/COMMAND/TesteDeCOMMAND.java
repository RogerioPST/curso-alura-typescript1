package diferentes_acoes_com.COMMAND;

public class TesteDeCOMMAND {
	public static void main(String[] args) {
		Pedido p1 = new Pedido("Mauricio", 150);
		Pedido p2 = new Pedido("Mauricio 1", 250);
		
		FilaDeTrabalho fila = new FilaDeTrabalho();
		fila.adiciona(new PagaPedido(p1));
		fila.adiciona(new PagaPedido(p2));
		fila.adiciona(new ConcluiPedido(p1));
		
		
		fila.processa();
		
	}

}
