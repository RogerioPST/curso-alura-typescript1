package diferentes_acoes_com.COMMAND;

public class ConcluiPedido implements Comando{
	
	private Pedido pedido;

	public ConcluiPedido(Pedido pedido) {
		this.pedido = pedido;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void executa() {
		// TODO Auto-generated method stub
		System.out.println("concluindo pedido do " +pedido.getCliente());
		pedido.finaliza();
		
	}

}
