package diferentes_acoes_com.COMMAND;

public enum Status {
	NOVO, PROCESSANDO, PAGO, ITEM_SEPARADO, ENTREGUE

}
