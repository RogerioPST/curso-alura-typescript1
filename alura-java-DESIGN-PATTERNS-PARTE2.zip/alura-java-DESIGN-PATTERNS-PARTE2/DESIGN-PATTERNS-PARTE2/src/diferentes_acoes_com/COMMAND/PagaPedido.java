package diferentes_acoes_com.COMMAND;

public class PagaPedido implements Comando{
		
		private Pedido pedido;

		public PagaPedido(Pedido pedido) {
			this.pedido = pedido;
			// TODO Auto-generated constructor stub
		}

		@Override
		public void executa() {
			// TODO Auto-generated method stub
			System.out.println("pagando pedido do " +pedido.getCliente());
			pedido.paga();
			
		}

	}


