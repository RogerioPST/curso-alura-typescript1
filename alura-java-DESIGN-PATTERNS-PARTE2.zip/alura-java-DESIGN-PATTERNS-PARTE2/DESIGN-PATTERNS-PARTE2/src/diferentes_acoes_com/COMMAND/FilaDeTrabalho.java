package diferentes_acoes_com.COMMAND;

import java.util.ArrayList;
import java.util.List;

public class FilaDeTrabalho {
	
	private List<Comando> comandos; //lista de coisas a fazer: pagar, finalizar, receber pedido etc
	
	public FilaDeTrabalho() {
		// TODO Auto-generated constructor stub
		comandos = new ArrayList<Comando>();
	}
	
	public void adiciona(Comando comando) {
		comandos.add(comando);
	}
	
	public void processa() {
		for (Comando comando : comandos) {
			comando.executa();
			
		}
	}
	
	

}
