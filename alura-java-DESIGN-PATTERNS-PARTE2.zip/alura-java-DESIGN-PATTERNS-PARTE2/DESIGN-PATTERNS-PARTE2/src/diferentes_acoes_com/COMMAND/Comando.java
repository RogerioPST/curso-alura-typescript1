package diferentes_acoes_com.COMMAND;

public interface Comando {
	void executa();

}
