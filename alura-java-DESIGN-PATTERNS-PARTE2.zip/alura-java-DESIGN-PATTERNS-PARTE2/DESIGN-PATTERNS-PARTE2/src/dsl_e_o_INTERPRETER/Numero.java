package dsl_e_o_INTERPRETER;

public class Numero implements Expressao{
	
	private double numero;

	public Numero(double numero) {
		this.numero = numero;
		// TODO Auto-generated constructor stub
	}

	@Override
	public double avalia() {
		// TODO Auto-generated method stub
		return numero;
	}

}
