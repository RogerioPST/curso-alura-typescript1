package dsl_e_o_INTERPRETER;

public interface Expressao {
	
	double avalia();

}
