package dsl_e_o_INTERPRETER;

public class Divisao implements Expressao {
		
		private Expressao esquerda;
		private Expressao direita;

		public Divisao(Expressao esquerda, Expressao direita) {
			this.esquerda = esquerda;
			this.direita = direita;
			// TODO Auto-generated constructor stub
		}
		
		@Override
		public double avalia() {
			// TODO Auto-generated method stub
			double valorDaEsquerda = esquerda.avalia();
			double valorDaDireita = direita.avalia();
			return valorDaEsquerda / valorDaDireita;
		}

	}


