package dsl_e_o_INTERPRETER;

public class RaizQuadrada implements Expressao {
		
		
		private Expressao novaExpressao ;

		public RaizQuadrada(Expressao expressao) {
			this.novaExpressao  = expressao;
			
			// TODO Auto-generated constructor stub
		}
		
		@Override
		public double avalia() {
			// TODO Auto-generated method stub
			
			double novoNumero = novaExpressao.avalia(); 
			return Math.sqrt(novoNumero);
		}

	}



