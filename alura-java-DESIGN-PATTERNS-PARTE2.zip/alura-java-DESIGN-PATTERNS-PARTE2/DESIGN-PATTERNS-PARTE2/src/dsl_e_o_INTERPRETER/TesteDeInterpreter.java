package dsl_e_o_INTERPRETER;

public class TesteDeInterpreter {
	public static void main(String[] args) {
		/*Muitas vezes temos problemas que s�o bem representados por uma �rvore. Suponha que devamos fazer uma calculadora cient�fica, que � composta por diversas opera��es, desde as mais simples at� as mais complexas.
		 * quero conseguir avaliar essas expressoes abaixo
		 * "2 + 3 / 4 - 1"  
		 * (2+3)/(4+7 +(2/1))*10
		 * 
		 * a ideia do interpreter eh ter uma arvore de expressao e essa arvore se autoavaliar e no final dar um resultado
		 * 
		 * Veja que nossa �rvore consegue interpretar, e calcular o resultado final. Quando temos express�es que devem ser avaliadas, e a transformamos em uma estrutura de dados, e depois fazemos com que a pr�pria �rvore se avalie, damos o nome de Interpreter.

O padr�o � bastante �til quando temos que implementar interpretadores para DSLs, ou coisas similares. � um padr�o bem complicado, mas bastante interessante.
		 */
		//Expressao conta = new Soma( new Numero(10),new Numero(20));
		
		
		
		Expressao esquerda = new Subtracao(new Numero(10), new Numero(5));
		Expressao direita= new Soma(new Numero(2), new Numero(10));
		Expressao soma = new Soma( esquerda, direita); //(10-5)+(2+10) 
		
		double resultado = soma.avalia();
		
		System.out.println(resultado);
		
		Expressao raiz = new RaizQuadrada(new Numero(4));
		System.out.println(raiz.avalia());
	}

}
