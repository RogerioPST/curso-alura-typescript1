package br.com.problema_de_criacao_de_objetos.FACTORY.antes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	public Connection getConnection() {
		String banco = System.getenv("tipoBanco");
		
		
		Connection c;
		try {
			c = DriverManager.getConnection("jdbc:"+banco+"://localhost/banco", "root", "123");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
		return c;
	}

}
