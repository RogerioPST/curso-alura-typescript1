package br.com.muitos_objetos.FLYWEIGHT.apos_refatoracao_um;

import java.util.HashMap;
import java.util.Map;

import br.com.muitos_objetos.FLYWEIGHT.antes.Do;
import br.com.muitos_objetos.FLYWEIGHT.antes.DoSustenido;
import br.com.muitos_objetos.FLYWEIGHT.antes.Fa;
import br.com.muitos_objetos.FLYWEIGHT.antes.La;
import br.com.muitos_objetos.FLYWEIGHT.antes.Mi;
import br.com.muitos_objetos.FLYWEIGHT.antes.Nota;
import br.com.muitos_objetos.FLYWEIGHT.antes.Re;
import br.com.muitos_objetos.FLYWEIGHT.antes.ReSustenido;
import br.com.muitos_objetos.FLYWEIGHT.antes.Si;
import br.com.muitos_objetos.FLYWEIGHT.antes.Sol;

public class NotasMusicais {

	//static p que sejam sempre as mesmas notas.
	private static Map<String, Nota> notas = new HashMap<String, Nota>();
	
	//construtor static eh executado uma vez so qdo a JVM carrega essa classe.
	static {
		notas.put("do", new Do());
		notas.put("re", new Re());
		notas.put("mi", new Mi());
		notas.put("fa", new Fa());
		notas.put("sol", new Sol());
		notas.put("la", new La());
		notas.put("si", new Si());
		notas.put("dosustenido", new DoSustenido());
		notas.put("resustenido", new ReSustenido());
	}
	
	public Nota pega(String nome) {
		return notas.get(nome);
	}

}
