package br.com.muitos_objetos.FLYWEIGHT.apos_refatoracao_um;

import java.util.List;

import org.jfugue.player.Player;

import br.com.muitos_objetos.FLYWEIGHT.antes.Nota;

public class Piano {
	
	public void toca(List<Nota> musica) {
		Player player = new Player();
		
		StringBuilder musicaEmNotas = new StringBuilder();
		
		for (Nota nota : musica) {
			musicaEmNotas.append(nota.simbolo() + " ");
			
		}
		
		System.out.println(musicaEmNotas);
		
		player.play(musicaEmNotas.toString());
		
		
	}

}
