package br.com.muitos_objetos.FLYWEIGHT.antes;

public interface Nota {
	String simbolo();

}
