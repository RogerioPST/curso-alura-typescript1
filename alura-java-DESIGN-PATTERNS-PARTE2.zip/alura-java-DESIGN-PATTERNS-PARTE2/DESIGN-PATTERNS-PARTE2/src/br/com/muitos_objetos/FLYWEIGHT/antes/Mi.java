package br.com.muitos_objetos.FLYWEIGHT.antes;

public class Mi implements Nota{

	@Override
	public String simbolo() {
		// TODO Auto-generated method stub
		return "E";
	}

}
