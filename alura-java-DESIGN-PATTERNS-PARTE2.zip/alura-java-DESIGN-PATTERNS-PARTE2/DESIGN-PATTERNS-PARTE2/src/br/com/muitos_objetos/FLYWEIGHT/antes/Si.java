package br.com.muitos_objetos.FLYWEIGHT.antes;

public class Si implements Nota {

	@Override
	public String simbolo() {
		// TODO Auto-generated method stub
		return "B";
	}

}
