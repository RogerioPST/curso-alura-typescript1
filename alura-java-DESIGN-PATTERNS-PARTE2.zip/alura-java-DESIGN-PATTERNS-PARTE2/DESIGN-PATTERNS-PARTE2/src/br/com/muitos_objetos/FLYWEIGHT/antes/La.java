package br.com.muitos_objetos.FLYWEIGHT.antes;

public class La implements Nota {

	@Override
	public String simbolo() {
		// TODO Auto-generated method stub
		return "A";
	}

}
