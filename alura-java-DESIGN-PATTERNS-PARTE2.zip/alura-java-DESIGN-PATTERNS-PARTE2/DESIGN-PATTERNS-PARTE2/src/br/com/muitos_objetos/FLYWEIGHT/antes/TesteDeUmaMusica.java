package br.com.muitos_objetos.FLYWEIGHT.antes;

import java.util.Arrays;
import java.util.List;

public class TesteDeUmaMusica {
	public static void main(String[] args) {
		/*
		 * qual o problema desse codigo abaixo? de criar o objeto Fa varias vezes. Imagina um milhao de notas em que vou ter o objeto
		 * da nota musical varias vezes? n precisa. Preciso ter uma nota Do, Re, Mi, etc, pq eh sempre igual.
		 * 
		 * a solu��o eh n deixar o usuario fazer new Do, new Re etc.
		 * o ususario vai pedir p uma classe. e devolver o mesmo Do, Re, Mi etc.
		 */
		List<Nota> musica = Arrays.asList(new Do(), new Re(), new Mi(), new Fa(), new Fa(), new Fa());
	}

}
