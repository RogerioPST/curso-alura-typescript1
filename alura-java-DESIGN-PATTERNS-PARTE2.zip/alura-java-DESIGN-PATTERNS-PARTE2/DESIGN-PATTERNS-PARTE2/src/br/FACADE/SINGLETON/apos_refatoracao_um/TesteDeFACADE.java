package br.FACADE.SINGLETON.apos_refatoracao_um;

import br.FACADE.SINGLETON.antes.Cliente;

public class TesteDeFACADE {
	public static void main(String[] args) {
		EmpresaFACADE facade = new EmpresaFacadeSingleton().getInstancia();
		
		facade.buscaCliente("123");
		
		facade.criaFatura(new Cliente(),5000);
		
		
	}

}
