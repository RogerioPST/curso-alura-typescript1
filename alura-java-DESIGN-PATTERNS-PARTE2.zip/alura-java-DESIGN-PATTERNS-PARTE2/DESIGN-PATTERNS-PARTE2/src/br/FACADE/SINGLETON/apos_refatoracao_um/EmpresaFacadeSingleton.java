package br.FACADE.SINGLETON.apos_refatoracao_um;

public class EmpresaFacadeSingleton {
	
	private static EmpresaFACADE instancia;
	
	public static EmpresaFACADE getInstancia() {
		if(instancia == null) {
			instancia = new EmpresaFACADE();
		}
		return instancia;
	}

}
