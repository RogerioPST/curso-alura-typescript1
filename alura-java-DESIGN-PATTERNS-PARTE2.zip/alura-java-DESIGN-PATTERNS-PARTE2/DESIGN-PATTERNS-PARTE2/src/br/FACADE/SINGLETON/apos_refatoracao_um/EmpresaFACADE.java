package br.FACADE.SINGLETON.apos_refatoracao_um;

import br.FACADE.SINGLETON.antes.Cliente;
import br.FACADE.SINGLETON.antes.ClienteDAO;
import br.FACADE.SINGLETON.antes.Cobranca;
import br.FACADE.SINGLETON.antes.ContatoCliente;
import br.FACADE.SINGLETON.antes.Fatura;
import br.FACADE.SINGLETON.antes.Tipo;

public class EmpresaFACADE {
	protected EmpresaFACADE() {
		// TODO Auto-generated constructor stub
	}

	public Cliente buscaCliente(String cpf) {
		Cliente cliente = new ClienteDAO().buscaPorCPF(cpf);
		return cliente;

	}

	public Fatura criaFatura(Cliente cliente, double valor) {
		Fatura fatura = new Fatura(cliente, 5000.0);
		return fatura;

	}

	public Cobranca geraCobranca(Fatura fatura) {
		Cobranca cobranca = new Cobranca(Tipo.BOLETO, fatura);
		cobranca.emite();
		return cobranca;
	}

	public ContatoCliente fazContato(Cliente cliente, Cobranca cobranca) {
		ContatoCliente contato = new ContatoCliente(cliente, cobranca);

		contato.dispara();
		return contato;
	}

}
