package br.FACADE.SINGLETON.antes;

public class Cobranca {

	public Cobranca(Tipo boleto, Fatura fatura) {
		// TODO Auto-generated constructor stub
	}

	public void emite() {
		// TODO Auto-generated method stub
		
	}

}
