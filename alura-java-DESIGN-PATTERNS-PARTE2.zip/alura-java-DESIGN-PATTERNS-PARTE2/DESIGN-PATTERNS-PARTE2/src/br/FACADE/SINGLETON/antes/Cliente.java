package br.FACADE.SINGLETON.antes;

public class Cliente {

}
