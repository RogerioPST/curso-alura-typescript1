package br.FACADE.SINGLETON.antes;

public class ClienteDAO {

	public Cliente buscaPorCPF(String cpf) {
		// TODO Auto-generated method stub
		return null;
	}

}
