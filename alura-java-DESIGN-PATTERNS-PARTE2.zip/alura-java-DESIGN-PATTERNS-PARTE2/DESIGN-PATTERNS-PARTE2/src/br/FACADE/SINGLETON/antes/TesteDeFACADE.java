package br.FACADE.SINGLETON.antes;

public class TesteDeFACADE {
	public static void main(String[] args) {
		String cpf = "123";
		
		Cliente cliente = new ClienteDAO().buscaPorCPF(cpf);
		
		Fatura fatura = new Fatura(cliente, 5000.0);
		
		Cobranca cobranca = new Cobranca(Tipo.BOLETO, fatura);
		cobranca.emite();
		
		ContatoCliente contato = new ContatoCliente(cliente, cobranca);
		
		contato.dispara();
		
		/*
		 * imagina q tem um outro sistema q preicsa consumir todos esses recursos.
		 * as vezes, fazer o sist externo conhecer cada uma das interfaces eh complicado.
		 * 
		 * a solucao eh ter uma fachada para o sistema externo consumir.
		 */
		
		
	}

}
