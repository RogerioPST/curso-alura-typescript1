package br.FACADE.SINGLETON.antes;

public class Fatura {

	public Fatura(Cliente cliente, double d) {
		// TODO Auto-generated constructor stub
	}

}
