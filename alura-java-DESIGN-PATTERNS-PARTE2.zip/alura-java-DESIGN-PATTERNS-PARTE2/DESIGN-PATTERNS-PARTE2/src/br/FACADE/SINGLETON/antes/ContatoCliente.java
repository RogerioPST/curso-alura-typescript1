package br.FACADE.SINGLETON.antes;

public class ContatoCliente {

	public ContatoCliente(Cliente cliente, Cobranca cobranca) {
		// TODO Auto-generated constructor stub
	}

	public void dispara() {
		// TODO Auto-generated method stub
		
	}

}
