package br.FACADE.SINGLETON.antes;

public enum Tipo {
	BOLETO

}
