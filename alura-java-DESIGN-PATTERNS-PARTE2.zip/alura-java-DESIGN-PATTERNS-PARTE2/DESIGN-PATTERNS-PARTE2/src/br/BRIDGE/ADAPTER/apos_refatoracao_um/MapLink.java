package br.BRIDGE.ADAPTER.apos_refatoracao_um;

public class MapLink  implements Mapa {

		@Override
		public String devolveMapa(String rua) {
			
				
				return "mapa do mapLink";
				
		}

	
}
