package br.BRIDGE.ADAPTER.apos_refatoracao_um;

public interface Mapa {
	String devolveMapa(String rua);

}
