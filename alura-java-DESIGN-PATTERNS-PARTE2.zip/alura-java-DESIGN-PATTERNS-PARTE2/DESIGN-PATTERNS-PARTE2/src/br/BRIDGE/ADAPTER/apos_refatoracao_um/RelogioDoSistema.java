package br.BRIDGE.ADAPTER.apos_refatoracao_um;

import java.util.Calendar;

public class RelogioDoSistema implements Relogio{

	@Override
	public Calendar hoje() {
		// TODO Auto-generated method stub
		return Calendar.getInstance();
	}

}
