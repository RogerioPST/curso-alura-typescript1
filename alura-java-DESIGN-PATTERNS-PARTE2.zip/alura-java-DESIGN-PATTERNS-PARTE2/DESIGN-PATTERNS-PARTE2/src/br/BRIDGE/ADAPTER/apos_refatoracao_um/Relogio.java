package br.BRIDGE.ADAPTER.apos_refatoracao_um;

import java.util.Calendar;

public interface Relogio { 
	Calendar hoje();


}
