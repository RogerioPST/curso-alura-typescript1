package br.BRIDGE.ADAPTER.apos_refatoracao_um;

import java.util.Calendar;

public class TesteDeADAPTER {
	public static void main(String[] args) {
		/*
		 * adapta interfaces antigas a interfaces novas
		 */
		Relogio relogio = new RelogioDoSistema();
		Calendar dataAtual = relogio.hoje();
		
	}

}
