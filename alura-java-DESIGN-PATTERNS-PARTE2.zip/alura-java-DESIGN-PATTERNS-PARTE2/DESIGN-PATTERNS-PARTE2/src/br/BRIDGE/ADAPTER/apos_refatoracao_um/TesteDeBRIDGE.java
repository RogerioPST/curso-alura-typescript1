package br.BRIDGE.ADAPTER.apos_refatoracao_um;

public class TesteDeBRIDGE {
	public static void main(String[] args) {
		Mapa mapa = new GoogleMaps();
		mapa.devolveMapa("Rua Vergueiro");
	}
}
