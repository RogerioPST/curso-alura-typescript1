package br.BRIDGE.ADAPTER.antes;

import java.io.InputStream;
import java.net.URL;

public class TesteDeBRIDGE{
	
	public static void main(String[] args) throws Exception {
		
		String googleMaps = "http://maps.google.com.br/mapsq=rua&rua=vergueiro";
		
		URL url = new URL(googleMaps);
		InputStream openStream = url.openStream();
		
		
		
		
	}

}
