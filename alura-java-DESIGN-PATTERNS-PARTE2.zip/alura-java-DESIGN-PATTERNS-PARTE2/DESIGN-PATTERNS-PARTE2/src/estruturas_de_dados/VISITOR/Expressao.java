package estruturas_de_dados.VISITOR;

public interface Expressao {
	
	double avalia();
	void aceita(Visitor impressora); // precisa saber invocar qual metodo da impressora imprime ela msm
	
	

}
