package estruturas_de_dados.VISITOR;

public class Subtracao implements Expressao {
	
	private Expressao esquerda;
	private Expressao direita;

	public Subtracao(Expressao esquerda, Expressao direita) {
		this.esquerda = esquerda;
		this.direita = direita;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public double avalia() {
		// TODO Auto-generated method stub
		double valorDaEsquerda = esquerda.avalia();
		double valorDaDireita = direita.avalia();
		return valorDaEsquerda - valorDaDireita;
	}
	
	public Expressao getEsquerda() {
		return esquerda;
	}
	
	public Expressao getDireita() {
		return direita;
	}
	
	
	public void aceita(Visitor impressora) {
		impressora.visitaSubtracao(this);
		
	}
	

}
