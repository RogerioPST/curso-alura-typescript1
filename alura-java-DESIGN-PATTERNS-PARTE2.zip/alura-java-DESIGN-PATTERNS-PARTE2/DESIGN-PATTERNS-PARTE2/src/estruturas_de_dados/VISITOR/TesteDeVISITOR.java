package estruturas_de_dados.VISITOR;



public class TesteDeVISITOR {
	public static void main(String[] args) {					
		
		Expressao esquerda = new Subtracao(new Numero(10), new Numero(5));
		Expressao direita= new Soma(new Numero(2), new Numero(10));
		Expressao soma = new Soma( esquerda, direita); //(10-5)+(2+10)
		
		Expressao subtracao = new Subtracao( esquerda, direita); //(10-5)+(2+10) 
		
		double resultado = soma.avalia();
		
		System.out.println(resultado);
		
		
		
		/*
		 * quero fornecer diferentes maneiras da calculadora imprimir
		 * 10 + 2
		 * 20 - 4
		 * 
		 * + 10 2
		 * - 20 4
		 * 
		 */
		
		ImpressoraVisitor impressora = new ImpressoraVisitor();
		soma.aceita(impressora);
		System.out.println();
		
		PreFixaVisitor preFixaImpressora = new PreFixaVisitor();
		soma.aceita(preFixaImpressora);
		System.out.println();
		
		
		subtracao.aceita(impressora);
		System.out.println();
		subtracao.aceita(preFixaImpressora);
	}

}

