package br.com.alura.java.io.teste;

import java.io.Serializable;

public class ContaCorrente extends Conta implements Tributavel {

	

	public ContaCorrente(int agencia, int numero) {
		super(agencia, numero);
	}
	
	@Override
	//quem tem q fazer o try catch eh quem usa essa classe
	public void saca(double valor) throws SaldoInsuficienteException {
		double valorASacar = valor + 0.2;
		super.saca(valorASacar);
	}
	

	

	@Override
	public double getValorImposto() {
		// TODO Auto-generated method stub
		return super.saldo * 0.01;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Conta Corrente - " + super.toString();
	}
}
