package br.com.alura.java.io.teste;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

public class TesteLeituraComScannerEEncoding {
	public static void main(String[] args) throws IOException {
		Scanner  scanner = new Scanner(new File("contas.csv"), "UTF-8");
		
		
		while (scanner.hasNextLine()) {
			
			String linha = scanner.nextLine();
			
			System.out.println(linha);
			
			Scanner linhaScanner = new Scanner(linha);
			
			linhaScanner.useDelimiter(",");
			//fala p usar as regras americanas
			linhaScanner.useLocale(Locale.US);
			
			String valor1 = linhaScanner.next();
			int valor2 = linhaScanner.nextInt();
			int valor3 = linhaScanner.nextInt();
			String valor4 = linhaScanner.next();
			double valor5 = linhaScanner.nextDouble();			
			
			
			
			System.out.format(new Locale("pt", "BR"),"%s - %04d-%08d , %20s : %08.2f %n", valor1, valor2, valor3, valor4, valor5);						
			
			linhaScanner.close();
			//String[] valores = linha.split(",");
			
			//System.out.println(Arrays.toString(valores));
			
			
			
		}
		
		scanner.close();
	}

}
