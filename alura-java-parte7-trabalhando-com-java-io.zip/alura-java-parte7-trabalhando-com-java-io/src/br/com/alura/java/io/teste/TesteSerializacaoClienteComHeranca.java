package br.com.alura.java.io.teste;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class TesteSerializacaoClienteComHeranca {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
//		
		Cliente cliente = new Cliente();
		cliente.setNome("Nico");
		cliente.setProfissao("dev");
		cliente.setCpf("2413584964");		
		
		ContaCorrente cc = new ContaCorrente(222, 333);
		
		cc.deposita(222.3);
		cc.setTitular(cliente);
		
		
		
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("contacorrente.bin"));
		
		oos.writeObject(cc);
		
		oos.close();
		
//		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("cliente.bin"));
//		
//		Cliente nomeConvert = (Cliente) ois.readObject();
//		ois.close();
//		System.out.println(nomeConvert.getNome());
		
		
	}

}
