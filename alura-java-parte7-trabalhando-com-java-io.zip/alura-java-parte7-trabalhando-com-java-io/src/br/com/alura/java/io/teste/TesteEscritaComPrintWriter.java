package br.com.alura.java.io.teste;

import java.io.IOException;
import java.io.PrintWriter;

public class TesteEscritaComPrintWriter {
	public static void main(String[] args) throws IOException {
		//fluxo de entrada com arquivo
		
//		OutputStream fos = new FileOutputStream("lorem2.txt");
//		
//		Writer writer = new OutputStreamWriter(fos);
//		
//		BufferedWriter bw = new BufferedWriter(writer);
//		
		
		PrintWriter ps = new PrintWriter("lorem2.txt");
		//FileWriter fw = new FileWriter("lorem2.txt");
			
		ps.println("estou escrevendo uma linha");
		ps.println("");
		ps.println("estou escrevendo uma linha dois sa");
		
		
		ps.close();
	}

}
