package br.com.alura.java.io.teste;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class TesteEscrita {
	public static void main(String[] args) throws IOException {
		//fluxo de entrada com arquivo
		
		OutputStream fos = new FileOutputStream("lorem2.txt");
		
		Writer writer = new OutputStreamWriter(fos);
		
		BufferedWriter bw = new BufferedWriter(writer);
		
		//padr�o Decorator - um objeto embrulha o outro (a outra referencia) e adicona comportamento	
		bw.write("estou escrevendo uma linha");
		bw.newLine();
		bw.write("estou escrevendo outra linha");
		bw.close();
	}

}
