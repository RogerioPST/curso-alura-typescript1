package br.com.alura.java.io.teste;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class TesteLeitura {
	public static void main(String[] args) throws IOException {
		//fluxo de entrada com arquivo
		
		FileInputStream fis = new FileInputStream("lorem.txt");
		//InputStreamReader p transformar os bytes em caracteres
		InputStreamReader isr = new InputStreamReader(fis);
		//BufferedReader p juntar os caracteres q estao dentro de uma linha e ler linha por linha
		BufferedReader br = new BufferedReader(isr);
		
		//padr�o Decorator - um objeto embrulha o outro e adicona comportamento
		//a gente pede p o Bufferreader uma linha, o bufferedReader pede p o Streamreader os caracteres 
		//e o InputStreamReader pede os bits e bytes para o FileInputStream e o fileInputStrem L� os dados do txt
		String linha = br.readLine();
		
		while (linha != null) {			
			System.out.println(linha);
			linha = br.readLine();
		}
		
		br.close();
	}

}
