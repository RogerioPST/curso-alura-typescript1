package br.com.alura.java.io.teste;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;

public class TesteEscritaComPrintStream {
	public static void main(String[] args) throws IOException {
		//fluxo de entrada com arquivo
		
//		OutputStream fos = new FileOutputStream("lorem2.txt");
//		
//		Writer writer = new OutputStreamWriter(fos);
//		
//		BufferedWriter bw = new BufferedWriter(writer);
//		
		
		PrintStream ps = new PrintStream("lorem2.txt");
		//PrintStream ps = new PrintStream(new File("lorem2.txt"));
		
		//FileWriter fw = new FileWriter("lorem2.txt");
			
		ps.println("estou escrevendo uma linha");
		ps.println("");
		ps.println("estou escrevendo uma linha dois");
		
		
		ps.close();
	}

}
