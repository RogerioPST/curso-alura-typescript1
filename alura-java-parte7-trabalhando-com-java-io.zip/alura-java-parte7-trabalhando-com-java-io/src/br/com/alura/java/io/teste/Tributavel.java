package br.com.alura.java.io.teste;

interface Tributavel {
	
	double getValorImposto();

}
