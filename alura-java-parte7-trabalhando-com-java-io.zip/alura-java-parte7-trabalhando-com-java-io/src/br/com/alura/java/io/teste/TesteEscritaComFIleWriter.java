package br.com.alura.java.io.teste;

import java.io.FileWriter;
import java.io.IOException;

public class TesteEscritaComFIleWriter {
	public static void main(String[] args) throws IOException {
		//fluxo de entrada com arquivo
		
//		OutputStream fos = new FileOutputStream("lorem2.txt");
//		
//		Writer writer = new OutputStreamWriter(fos);
//		
//		BufferedWriter bw = new BufferedWriter(writer);
//		
		
		FileWriter fw = new FileWriter("lorem2.txt");
			
		fw.write("estou escrevendo uma linha");
		
		fw.write(System.lineSeparator()); //devolve \r\n //pula linha
		fw.write("estou escrevendo outra linha");
		
		fw.close();
	}

}
