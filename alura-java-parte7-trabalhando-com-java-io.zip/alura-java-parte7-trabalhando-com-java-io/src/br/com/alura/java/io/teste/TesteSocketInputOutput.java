package br.com.alura.java.io.teste;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;

public class TesteSocketInputOutput {
	public static void main(String[] args) throws IOException {
		//socker n funciona, pois falta o outro lado.
		Socket socket = new Socket();						

		// fluxo de entrada com arquivo

		InputStream fis = socket.getInputStream(); //System.in; //new FileInputStream("lorem.txt");
		// InputStreamReader p transformar os bytes em caracteres
		InputStreamReader isr = new InputStreamReader(fis);
		// BufferedReader p juntar os caracteres q estao dentro de uma linha e ler linha
		// por linha
		BufferedReader br = new BufferedReader(isr);
		

		OutputStream fos = socket.getOutputStream(); //System.out; // new FileOutputStream("lorem2.txt");

		Writer writer = new OutputStreamWriter(fos);

		BufferedWriter bw = new BufferedWriter(writer);


		// padr�o Decorator - um objeto embrulha o outro e adicona comportamento
		// a gente pede p o Bufferreader uma linha, o bufferedReader pede p o
		// Streamreader os caracteres
		// e o InputStreamReader pede os bits e bytes para o FileInputStream e o
		// fileInputStrem L� os dados do txt
		String linha = br.readLine();

		while (linha != null && !linha.isEmpty()) {
			bw.write(linha);
			bw.newLine();	
			bw.flush();
			linha = br.readLine();
		}

		br.close();
		bw.close();

	}

}
