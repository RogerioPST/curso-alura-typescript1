package br.com.alura.java.io.teste;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class TesteEscritaComFIleWriterEBufferredWriter {
	public static void main(String[] args) throws IOException {
		//fluxo de entrada com arquivo
		
//		OutputStream fos = new FileOutputStream("lorem2.txt");
//		
//		Writer writer = new OutputStreamWriter(fos);
//		
//		BufferedWriter bw = new BufferedWriter(writer);
//		
		
		FileWriter fw = new FileWriter("lorem2.txt");
		//FileWriter fw = new FileWriter(new File("lorem2.txt"));
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write("estou escrevendo uma linha");
		
		bw.newLine();
		bw.write("estou escrevendo outra outra linha");
		
		bw.close();
	}

}
