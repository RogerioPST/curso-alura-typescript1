//criando a função que contém a tabela de dados e  desenha o nosso gráfico
function desenharPizza() {
    //tabela com colunas, linhas e dados
    var tabela = new google.visualization.DataTable();
    tabela.addColumn('string', 'categorias');
    tabela.addColumn('number', 'valores');
    tabela.addRows([

        ['Educação', 2000],
        ['Transporte', 500],
        ['Lazer', 230],
        ['Saúde', 50],
        ['Cartão de crédito', 900],
        ['Alimentação', 260]
    ]);

    var opcoes = {
        'title': 'Tipos de Gastos',
        'height': 400,
        'width': 800,
        //para que trocássemos um gráfico de pizza para um gráfico de donut.
        'pieHole': 0.1,
        is3D: true,
        legend: 'labeled', //left, top, bottom
        pieSliceText: 'value',
        //Quando usamos o array de cores, se colocarmos apenas uma cor, ela já colore todas as fatias da pizza.
        //'colors': ['red','grey', 'yellow', 'blue', 'pink', 'purple']
        'slices': {
            0: {},
            1: { color: 'gray' },
            2: { color: '#a6a6a6' },
            3: { color: 'gray' },
            4: { offset: 0.2 },
            5: { color: 'gray' }
        }


    };
    // instanciando um objeto do tipo gráfico de pizza ou PieChart (gráfico de torta) passando a div do html
    var grafico = new google.visualization.PieChart(document.getElementById('graficoPizza'));
    //passando a tabela para a função desenhar, draw que desenha o gráfico
    grafico.draw(tabela, opcoes);

    tabela = new google.visualization.DataTable();
    tabela.addColumn('string', 'mês');
    tabela.addColumn('number', 'gastos');
    tabela.addRows([
        ['jan', 800],
        ['fev', 400],
        ['mar', 1100],
        ['abr', 400],
        ['mai', 500],
        ['jun', 750],
        ['jul', 1500],
        ['ago', 650],
        ['set', 850],
        ['out', 400],
        ['nov', 1000],
        ['dez', 720]
    ]);

    var opcoes = {
        'title': 'Gastos por mês',
        'width': 650,
        'height': 300,
        'vAxis': {
            format: 'currency',
            gridlines: {
                count: 4,
                color: 'transparent'
            } //Desse modo, não removemos os números do eixo vertical, mas escondemos as linhas, pois elas se tornam transparentes.
        },
        'curveType': 'function',
        legend: 'none'
    }

    var grafico = new google.visualization.LineChart(document.getElementById('graficoLinha'));
    grafico.draw(tabela, opcoes);
    var arrayDeTabela = [
        ['Mês', 'Entrada', 'Saída'],
        ['jan', 2500, 1000],
        ['fev', 1000, 500],
        ['mar', 3000, 1300],
        ['abr', 1500, 1700],
        ['mai', 5000, 2250],
        ['jun', 3567, 3000],
        ['jul', 3452, 1468],
        ['ago', 1833, 5250],
        ['set', 1800, 1000],
        ['out', 1800, 1000],
        ['nov', 3569, 1500],
        ['dez', 3000, 1740]
    ];
    //Uma das vantagens de usarmos o arrayToDataTable é que não precisamos definir o tipo, colocamos apenas um array inicial com o nome de cada coluna.
    var tabela = google.visualization.arrayToDataTable(arrayDeTabela);

    var opcoes = {

        title: 'Entradas e saídas da conta',
        width: 800,
        height: 500,
        vAxis: {
            gridlines: { color: 'transparent' },
            format: 'currency',
            title: 'Valores'
        },
        hAxis: { title: 'Mês' }

    }

    var grafico = new google.visualization.ColumnChart(document.getElementById('graficoColuna'));
    grafico.draw(tabela, opcoes);

    var tabela = new google.visualization.DataTable();
    tabela.addColumn('string', 'categorias');
    tabela.addColumn('number', 'valores');
    //dessa vez iremos nos livrar dos números no eixo vertical, exibindo-os nas próprias colunas. Entretanto, essa customização não é feita nas opções, mas sim na própria tabela.
    //Para isso, precisaremos criar uma nova coluna (tabela.addColumn) passando como parâmetro um objeto categorizado com o tipo de valor que será exibido (nesse caso, number) e o papel (role) desse valor, que é o de uma anotação (annotation).
    //Essa nova coluna também precisa ser expressa no nosso array, o que é feito simplesmente duplicando os valores numéricos da segunda coluna:
    //Para exibirmos os nossos dados com R$, precisamos adicionar uma nova coluna que tenha o papel de ser uma anotação. Desse modo, anotamos os R$ no gráfico.
    tabela.addColumn({ type: 'string', role: 'annotation' });
    //mudando as cores das colunas, acresenta uma nova coluna com a cor
    tabela.addColumn({ type: 'string', role: 'style' });
    tabela.addRows([

        ['Educação', 2000, 'R$2.000,00', 'blue'],
        ['Transporte', 500, 'R$500,00', 'grey'],
        ['Lazer', 230, 'R$230,00', 'grey'],
        ['Saúde', 50, 'R$50,00', 'grey'],
        ['Cartão de crédito', 900, 'R$900,00', '#8904B1'],
        ['Alimentação', 260, 'R$260,00', 'grey']
    ]);
    tabela.sort([{ column: 1, desc: true }]);

        //converte p o formato json q o google chart quer
    var conversao = tabela.toJSON();
    console.log(conversao);

    var opcoes = {
        title: 'Tipos de Gastos',
        height: 400,
        width: 800,
        //Também seria interessante ocultarmos a visualização do eixo vertical, já que a informação contida nele está sendo passada nas anotações, e a legenda "valores".
        //Para isso, usaremos gridlines: {count:0}, textPosition: 'none', 
        //o que fará com que tanto as linhas quanto os números no eixo vertical desapareçam. Como aprendemos anteriormente, as legendas podem ser ocultadas com legend: 'none'.
        vAxis: { gridlines: { count: 0, color: 'transparent' }, textPosition: 'none' },
        hAxis: { gridlines: { color: 'transparent' }, format: 'currency', textPosition: 'none' },
        legend: 'none',
        annotations: { alwaysOutside: true }
    }

    var grafico = new google.visualization.ColumnChart(document.getElementById('graficoColunaSurpresa'));
    grafico.draw(tabela, opcoes);

    var grafico = new google.visualization.BarChart(document.getElementById('graficoBarraSurpresa'));
    grafico.draw(tabela, opcoes);

    //grafico de barras com arquivo json
    //jquery
    var dadosJson = $.ajax({
        //url: 'dados.json',
        url: 'https://gist.githubusercontent.com/neforodrigo/aabc275a6a944fc5337f6774803ed94b/raw/8a8a1b61ef174ec0656cf3ea4bf5a8b1d2cb5f22/dados.json',
        //Como dito anteriormente, uma das partes do AJAX é o objeto XMLHttpRequest, em que são definidos os tipos de arquivos de que falamos até então. Outros formatos além dos "tradicionais" são entendidos por algo conhecido como MIME (de Multipurpose Internet Mail Extensions em inglês, ou Extensões Multiproposta de Email de Internet). O MIME foi criado para emails, mas é usado em nossas chamadas e protocolos da web.
        //Inclusive, é no MIME que temos o contentType que acabamos de tentar explicitar. Mas, se isso não funcionou, o que iremos fazer é dar uma novo valor para esse MIME, que será o de um JSON.
        mimeType: 'application-json',
        dataType: 'json',
        async: false
    }).responseText;

    var tabela = new google.visualization.DataTable(dadosJson);

    tabela.sort([{ column: 1, desc: true }]);

    var opcoes = {
        title: 'Usuários e Poupanças via JSON no GIST',
        height: 800,    
        width: 800,
        hAxis: { gridlines: { color: 'transparent' }, format: 'currency', textPosition: 'none' },
        legend: 'none',
        annotations: { alwaysOutside: true }


}


    var grafico = new google.visualization.BarChart(
        document.getElementById('graficoBarrasJson'));

    grafico.draw(tabela, opcoes);



    //grafico de barras com arquivo json
    //jquery
    var dadosJson = $.ajax({
        //url: 'dados.json',
        url: 'https://gist.githubusercontent.com/neforodrigo/dbd6baa717d2059ddf55b6af46e3ac05/raw/359828a9da6a3df0291c63596f000557eb5ea822/dados2.json',
        //Como dito anteriormente, uma das partes do AJAX é o objeto XMLHttpRequest, em que são definidos os tipos de arquivos de que falamos até então. Outros formatos além dos "tradicionais" são entendidos por algo conhecido como MIME (de Multipurpose Internet Mail Extensions em inglês, ou Extensões Multiproposta de Email de Internet). O MIME foi criado para emails, mas é usado em nossas chamadas e protocolos da web.
        //Inclusive, é no MIME que temos o contentType que acabamos de tentar explicitar. Mas, se isso não funcionou, o que iremos fazer é dar uma novo valor para esse MIME, que será o de um JSON.
        mimeType: 'application-json',
        dataType: 'json',
        async: false
    }).responseText;

    var tabela = new google.visualization.DataTable(dadosJson);

    tabela.sort([{ column: 1, desc: true }]);

  var opcoes = {
        title: 'Tipos de Gastos vindos do JSON no GIST',
        height: 400,
        width: 800,
        //Também seria interessante ocultarmos a visualização do eixo vertical, já que a informação contida nele está sendo passada nas anotações, e a legenda "valores".
        //Para isso, usaremos gridlines: {count:0}, textPosition: 'none', 
        //o que fará com que tanto as linhas quanto os números no eixo vertical desapareçam. Como aprendemos anteriormente, as legendas podem ser ocultadas com legend: 'none'.
        vAxis: { gridlines: { count: 0, color: 'transparent' }, textPosition: 'none' },
        hAxis: { gridlines: { color: 'transparent' }, format: 'currency', textPosition: 'none' },
        legend: 'none',
        annotations: { alwaysOutside: true }
    }


    var grafico = new google.visualization.BarChart(
        document.getElementById('graficoBarrasJson2'));

    grafico.draw(tabela, opcoes);


}