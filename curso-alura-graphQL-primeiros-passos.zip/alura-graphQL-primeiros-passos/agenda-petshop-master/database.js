module.exports = {
  atendimentos: [],
  clientes: [],
  pets: [],
  servicos: []
}