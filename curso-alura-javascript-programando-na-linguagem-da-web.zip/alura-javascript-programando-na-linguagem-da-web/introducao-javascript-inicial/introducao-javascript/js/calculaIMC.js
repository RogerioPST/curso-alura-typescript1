var titulo = document.querySelector('.titulo');
console.log(titulo);
console.log(titulo.textContent);

titulo.textContent = "Qualq coisa colocada nova"

//pega um array de pacientes
var pacientes = document.querySelectorAll(".paciente");

for(var i=0; i< pacientes.length; i++){
    var paciente = pacientes[i];
    var tdPeso = paciente.querySelector('.info-peso');
    var peso = tdPeso.textContent;
    
    var tdAltura = paciente.querySelector('.info-altura');
    var altura = tdAltura.textContent;
    
    var tdImc = paciente.querySelector('.info-imc');
    
    console.log(paciente);
    console.log(tdPeso);
    console.log(peso);
    
    console.log(paciente);
    console.log(tdAltura);
    console.log(altura);
    
    var pesoEhValido = validaPeso(peso);
    var alturaEhValida = validaAltura(altura);
    
    if (!pesoEhValido){
        console.log('peso invalido');
        pesoEhValido = false;
        tdImc.textContent = "Peso invalido";
        //propriedade abaixo nos dá acesso à lista das classes de um HTML selecionado pela função querySelector
        paciente.classList.add('paciente-invalido');
    }
    
    if (!alturaEhValida){
        console.log('peso invalido');
        alturaEhValida = false;
        tdImc.textContent = "Altura invalida";
        //adicionando uma classe do css ao elemento tr, no caso
        paciente.classList.add('paciente-invalido');
    }
    
    if (pesoEhValido && alturaEhValida){
    
        var imc = calculaIMC(peso, altura);
        
        console.log(imc);
        
        tdImc.textContent = imc
    }

}

function validaAltura(altura){
    if(altura >= 0 && altura < 3.0){
        return true;    
    } else{
        return false;
    }
}


function validaPeso(peso){
    if(peso >= 0 && peso < 1000){
        return true;    
    } else{
        return false;
    }
}

function calculaIMC(peso, altura){
    var imc = peso / (altura * altura);
    // fixando p 2 casas decimais
    return imc.toFixed(2);
}



