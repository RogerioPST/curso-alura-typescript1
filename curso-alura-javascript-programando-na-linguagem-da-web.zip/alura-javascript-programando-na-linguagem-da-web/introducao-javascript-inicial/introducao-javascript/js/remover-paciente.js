/*
var pacientes = document.querySelectorAll('.paciente');

console.log(pacientes);

// n funciona, pois quando adicionar um novo paciente, vai ficar sem a opção de remover
// para isso, usa do event bubbling (Uma das formas para que o evento click funcione tanto para os elementos já existentes quanto para os novos elementos é utilizar delegação de eventos.)
 =  seleciona o pai do objeto e verifica pelo event.target quem foi clicado 
// e o q deve ser removido.
pacientes.forEach(function(paciente){
    paciente.addEventListener('dblclick', function(){
        console.log('duplo clique');
        // o this nesse contexto estah sempre atrelado ao dono do evento, nesse caso, eh o paciente.
        //Todo evento disparado em JavaScript possui um contexto que é acessível através da função executada quando o evento for disparado.Na função, acessamos o contexto através do objeto implícito this. Ele é uma referência para o elemento do DOM que esta recebendo o evento, logo, sua natureza é dinâmica, ou seja, se clicarmos no primeiro elemento da lista o this será o primeiro elemento, se clicarmos no último ele será o último. É a natureza dinâmica do this que nos permite utilizar a mesma função em diferentes contextos.
        this.remove();
    });
});
*/
var tabela = document.querySelector('#tabela-pacientes');

tabela.addEventListener('dblclick', function(event){
    var alvoEvento = event.target; //objeto clicado
    var paiDoAlvo = alvoEvento.parentNode; // TR = paciente =remover
    console.log('foi removido');
    paiDoAlvo.classList.add('fadeOut');

    setTimeout(function(){

        paiDoAlvo.remove();
    }, 500);
});
