document.addEventListener('copy', function(){
    alert('copiou');
});

var botaoAdicionar = document.querySelector('#adicionar-paciente');

botaoAdicionar.addEventListener("click", function(event){
    //o botao dentro de um form tem por padrao recarregar a pagina/enviar o form
    // para fazer com que seja exibido o console.log, usar a função event.preventDefault();
    event.preventDefault();
    console.log('fui clicado');

    var form = document.querySelector('#form-adiciona');

    // extrai info do paciente do form
    var paciente = obtemPacienteDoFormulario(form);

    console.log(paciente);                

    var erros = validaPaciente(paciente);

    if (erros.length > 0){
        exibeMensagensDeErro(erros);       
        console.log('paciente invalido');
        return;
    }
    
    
    //adicionando o paciente na tabela
    
    adicionaPacienteNaTabela(paciente);

    form.reset();

    //apagando as mensagens anteriores
    document.querySelector('#mensagens-erro').innerHTML = "";


} );

function adicionaPacienteNaTabela(paciente){
    // cria a tr e a td do paciente
    var pacienteTR = montaTr(paciente);
    var tabela = document.querySelector('#tabela-pacientes');
    tabela.appendChild(pacienteTR);

}

function exibeMensagensDeErro(erros){
    var ul = document.querySelector('#mensagens-erro');
    //apagando as mensagens anteriores
    ul.innerHTML ="";

    erros.forEach(function(erro){
        var li = document.createElement('li');
        li.textContent = erro;
        ul.appendChild(li);

    });

}

function validaPaciente(paciente){
    var erros =[];
    if(paciente.nome.length ==0){
        erros.push("O nome não pode ser em branco");
    }
    
    if(!validaPeso(paciente.peso)){    
        erros.push("O peso eh invalido");
    }

    if(!validaAltura(paciente.altura)){        
        erros.push("A altura eh invalida");
    }

    if (paciente.gordura.length ==0){
        erros.push("A gordura n pode ser em branco");
    }

    if (paciente.peso.length ==0){
        erros.push("O peso n pode ser em branco");
    }

    if (paciente.altura.length ==0){
        erros.push("A altura n pode ser em branco");
    }
    
    return erros;
}

function obtemPacienteDoFormulario(form){

    var paciente = {
        nome: form.nome.value,
        peso: form.peso.value,
        altura: form.altura.value,
        gordura: form.gordura.value,
        imc: calculaIMC(form.peso.value, form.altura.value)

    };  
    return paciente;
}

function montaTr(paciente){
    var pacienteTR = document.createElement('tr');
    pacienteTR.classList.add("paciente");    

    pacienteTR.appendChild(montaTD(paciente.nome, "info-nome"));
    pacienteTR.appendChild(montaTD(paciente.peso, "info-peso"));
    pacienteTR.appendChild(montaTD(paciente.altura, "info-altura"));
    pacienteTR.appendChild(montaTD(paciente.gordura, "info-gordura"));
    pacienteTR.appendChild(montaTD(paciente.imc, "info-imc"));


    return pacienteTR;

}

function montaTD(dado, classe){
    var td = document.createElement('td');
    td.textContent = dado;
    td.classList.add(classe);
    return td;
}

