package br.com.alura.servidor;

public class TarefaPararServidor implements Runnable {

    private ServidorDeTesteAlternativaDoUsoDeVolatile servidor;

    //recebendo o servidor como parametro
    public TarefaPararServidor(ServidorDeTesteAlternativaDoUsoDeVolatile servidor) {
        this.servidor = servidor;
    }

    public void run() {
        //chamando o m�todo estaRodando()
        System.out.println("Servidor comecando, estaRodando=" + this.servidor.estaRodando());
        while (!this.servidor.estaRodando()) {
        }

        System.out.println("Servidor rodando, estaRodando=" + this.servidor.estaRodando());

        while (this.servidor.estaRodando()) {
        }

        System.out.println("Servidor terminando, estaRodando=" + this.servidor.estaRodando());
    }
}