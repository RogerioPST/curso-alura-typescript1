package br.com.alura.servidor;

import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

public class DistribuirTarefas implements Runnable {

	private Socket socket;
	private ServidorTarefas servidor;
	private ExecutorService threadPool;
	private BlockingQueue<String> filaComandos;

	public DistribuirTarefas(Socket socket, ServidorTarefas servidor, ExecutorService threadPool, BlockingQueue<String> filaComandos) {
		this.socket = socket;
		// TODO Auto-generated constructor stub
		this.servidor = servidor;
		this.threadPool = threadPool;
		this.filaComandos = filaComandos;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		try {
			System.out.println("distribuindo tarefas " + socket);

			Scanner entradaCliente = new Scanner(socket.getInputStream());

			PrintStream respostaParaCliente = new PrintStream(socket.getOutputStream());

			while (entradaCliente.hasNextLine()) {
				String comando = entradaCliente.nextLine();
				System.out.println("comando recebido:  " + comando);

				switch (comando) {
					case "c1": {
						respostaParaCliente.println("confirma��o comando c1");
						ComandoC1 c1 = new ComandoC1(respostaParaCliente);
						threadPool.execute(c1);
						break;
	
					}
					case "c2": {
						respostaParaCliente.println("confirma��o comando c2");
						ComandoC2 c2 = new ComandoC2(respostaParaCliente);
						ComandoC2AcessaBanco c2b = new ComandoC2AcessaBanco(respostaParaCliente);
						Future<String> futureWS = threadPool.submit(c2);
						Future<String> futureBanco = threadPool.submit(c2b);						
					
						
						this.threadPool.submit(new JuntaResultadosFutureWSFutureBanco(futureWS, futureBanco, respostaParaCliente));
						
						
						break;
	
					}
					case "c3": {
						this.filaComandos.put(comando);//lembrando, bloqueia se tiver cheia
						respostaParaCliente.println("comando c3 adicionado na fila");						
						break;
	
					}
					case "fim": {
						respostaParaCliente.println("desligando o servidor");
						servidor.parar();
						break;
	
					}
					default: {
						respostaParaCliente.println("comando n�o encontrado");
						
	
					}
				}

			}
			respostaParaCliente.close();
			entradaCliente.close();
			// Thread.sleep(20000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}

	}

}
