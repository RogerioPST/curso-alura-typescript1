package br.com.alura.fila;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class TesteBlockingQueue {
	public static void main(String[] args) throws InterruptedException {
		
		BlockingQueue<String> fila = new ArrayBlockingQueue<>(3);
		
//		fila.offer("c1");
//		fila.offer("c2");
//		fila.offer("c3");
		
		fila.put("c1");
		fila.put("c2");
		fila.put("c3");
		fila.put("c4");
		
		//devolve e retira o ultimo elem da fila
		
		System.out.println(fila.poll());
		System.out.println(fila.poll());
		System.out.println(fila.poll());
		
		//o take bloqueia a thread at� alguem disponibilizar um novo elemento
		System.out.println(fila.take());
		
		fila.offer("c3");
		//devolve o elemento, mas n retira da fila
		System.out.println(fila.peek());
		
		System.out.println(fila.size());
		
	}

}
