#ifndef _UI_H_
#define _UI_H_

#include "mapa.h"

void imprimemapa(MAPA* m);
void imprimeparte(char desenho[4][7], int parte); 

#endif