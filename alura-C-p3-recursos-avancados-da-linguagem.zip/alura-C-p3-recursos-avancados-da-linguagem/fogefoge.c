#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "fogefoge.h"
#include "mapa.h"
#include "ui.h"

//struct - conjunto de variaveis que devem andar juntas
//olhar no arquivo "fogefoge.h"
//o "typedef" permite usar um apelido "MAPA" ao inves de "struct mapa";
MAPA m;
//struct mapa y;
//struct mapa z;
POSICAO heroi;

int tempilula = 0;

int praondefantasmavai(int xatual, int yatual, 
    int* xdestino, int* ydestino) {

    //quatro caminhos possiveis/ p cima, baixo, esq, direita
    int opcoes[4][2] = { 
        { xatual   , yatual+1 }, 
        { xatual+1 , yatual   },  
        { xatual   , yatual-1 }, 
        { xatual-1 , yatual   }
    };

    srand(time(0));
    for (int i = 0; i<10; i++){
        int posicao = rand() % 4; //de 0 a 3
    
    if(podeandar(&m, FANTASMA, opcoes[posicao][0], opcoes[posicao][1])) {
            *xdestino = opcoes[posicao][0];
            *ydestino = opcoes[posicao][1];
            return 1;
        }
    }

    return 0;
}

//por enquanto , o fantasma anda sempre p direita
void fantasmas(){
    MAPA copia;

    copiamapa(&copia, &m);

    for (int i = 0; i<m.linhas; i++){
        for (int j = 0; j<m.colunas; j++){
            if(copia.matriz[i][j] == FANTASMA){

                int xdestino;
                int ydestino;

                int encontrou = praondefantasmavai(i,j, &xdestino, &ydestino);

                if(encontrou){
                    andanomapa(&m, i,j, xdestino, ydestino);
                }

               // if(ehvalida(&m, i, j+1) && ehvazia(&m, i, j+1)){
                    //por enquanto , o fantasma anda sempre p direita
                    //andanomapa(&m, i,j,i,j+1);
               // }
            }
        }
    }

    liberamapa(&copia);
}

void testedealocacao(){
    //4 pq int precisa de 4 bytes
    int* v = malloc(4); //memoria alocacao
    *v = 10;
    printf("inteiro alocado %d\n", *v);
    free(v); // se eu aloco memoria, tenho q esvaziar

    int** y = malloc(sizeof(int*) * 5); //memoria alocacao
    for (int i = 0; i<5; i++){
        y[i] = malloc(sizeof(int) * 10);
    }
    y[0][0] = 10;
    y[1][2] = 12;
    printf("inteiro alocado %d %d\n", y[0][0], y[1][2]);
    for (int i = 0; i<5; i++){
        free(y[i]); // se eu aloco memoria, tenho q esvaziar
    }
    free(y);
}



int acabou(){
    POSICAO pos;
    int fogefogenomapa = encontramapa(&m, &pos, HEROI);
    return !fogefogenomapa;
}

int ehdirecao(char direcao){
    return direcao == ESQUERDA || 
        direcao == CIMA ||
        direcao == BAIXO ||
        direcao == DIREITA;
}


void move(char direcao){    
    //n faz nada se n digitar as teclas da funcao ehdirecao
    if(!ehdirecao(direcao)) return; //com esse return, eu saio da funcao move.
    
    int proximox = heroi.x;
    int proximoy = heroi.y;    
   

    switch(direcao){
        case ESQUERDA:
            proximoy--;
            break;
        case CIMA:
            proximox--;
            break;
        case BAIXO:
            proximox++;
            break;
        case DIREITA:
            proximoy++;
            break;
    }

    //verifica se n eh parede ou limite do cenario
    //e
    //verifica se eh um ponto (.) o proximo x e y onde o pac man quer ir
    //se n for, n pode ir
    if(!podeandar(&m,HEROI, proximox, proximoy))
        return; 

    if (ehpersonagem(&m, PILULA, proximox, proximoy)){
        tempilula =1;
    }         
    
    //m.matriz[proximox][proximoy] = HEROI;

    //nesse momento, tenho dois pac man no mapa
    //preciso retirar um
    //ou a movimentacao do fantasma
    //ficou generica
    andanomapa(&m, heroi.x, heroi.y, proximox, proximoy);
    heroi.x = proximox;
    heroi.y = proximoy;
    


    

}
void explodepilula2(int x, int y, int somax, int somay, int qtd) {

    if(qtd == 0) return;

    int novox = x+somax;
    int novoy = y+somay;

    if(!ehvalida(&m, novox, novoy)) return;
    if(ehparede(&m, novox, novoy)) return;

    m.matriz[novox][novoy] = VAZIO;
    explodepilula2(novox, novoy, somax, somay, qtd-1);
}

void explodepilula() {

    if(!tempilula) return;

    explodepilula2(heroi.x, heroi.y, 0, 1, 3);
    explodepilula2(heroi.x, heroi.y, 0, -1, 3);
    explodepilula2(heroi.x, heroi.y, 1, 0, 3);
    explodepilula2(heroi.x, heroi.y, -1, 0, 3);

    tempilula = 0;
}

int main(){    
    lemapa(&m);
    encontramapa(&m, &heroi, HEROI);

    do{
        printf("Pílula: %s\n", (tempilula ? "SIM" : "NÃO"));
        imprimemapa(&m);

        char comando;
        scanf(" %c", &comando); //o espaço eh p contar o enter como o cara q termina
        move(comando);

        if (comando == BOMBA) explodepilula();

        fantasmas();

    } while(!acabou());
    
    

    liberamapa(&m);
}

