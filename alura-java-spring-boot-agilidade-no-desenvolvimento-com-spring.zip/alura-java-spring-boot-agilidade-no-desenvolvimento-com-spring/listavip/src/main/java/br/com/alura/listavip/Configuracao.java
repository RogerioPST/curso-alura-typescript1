package br.com.alura.listavip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Configuracao {
	
	
	public static void main(String[] args) {
		SpringApplication.run(Configuracao.class, args);
	}
	
//	@Bean //o spring vai gerenciar esse datasource
//	public DataSource dataSource(){
//	    DriverManagerDataSource dataSource = new DriverManagerDataSource();
//	    dataSource.setUrl("jdbc:mysql://localhost/listavip?useTimezone=true&serverTimezone=UTC");
//		dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver");
//	    dataSource.setUsername("root");
//	    dataSource.setPassword("Rogerio_123456");
//	    return dataSource;
//	}
	
	

}
