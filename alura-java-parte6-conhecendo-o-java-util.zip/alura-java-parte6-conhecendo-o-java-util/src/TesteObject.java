
public class TesteObject {

	public static void main(String[] args) {
		int[] idades = new int[5];

		System.out.println("x");
		System.out.println(3);
		System.out.println(false);
		
		//ContaCorrente cc = new ContaCorrente(1145, 15478);
		//Object cliente = new Cliente();
		
		//System.out.println(cc.toString());
		//System.out.println(cp);

		println();
	}

	static void println() {

	}

	static void println(int a) {

	}

	static void println(boolean valor) {

	}
	
}
