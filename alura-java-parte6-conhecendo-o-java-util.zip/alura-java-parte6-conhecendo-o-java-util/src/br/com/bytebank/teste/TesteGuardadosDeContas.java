package br.com.bytebank.teste;

import br.com.bytebank.modelo.Conta;
import br.com.bytebank.modelo.ContaCorrente;
import br.com.bytebank.modelo.GuardadorDeContas;

public class TesteGuardadosDeContas {

	public static void main(String[] args) {
		GuardadorDeContas guardador = new GuardadorDeContas();

		Conta cc = new ContaCorrente(147, 258);

		guardador.adiciona(cc);

		Conta cc1 = new ContaCorrente(1473, 2588);

		guardador.adiciona(cc1);

		int tamanho = guardador.getQuantidadeDeElementos();

		System.out.println(tamanho);
		
		Conta ref = guardador.getReferencia(0);
		
		System.out.println(ref.getAgencia());
		
		

	}

}
