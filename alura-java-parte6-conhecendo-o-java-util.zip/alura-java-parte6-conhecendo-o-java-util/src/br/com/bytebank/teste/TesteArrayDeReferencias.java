package br.com.bytebank.teste;

import br.com.bytebank.modelo.Conta;
import br.com.bytebank.modelo.ContaCorrente;
import br.com.bytebank.modelo.ContaPoupanca;

public class TesteArrayDeReferencias {

	public static void main(String[] args) {
		String[] strings = new String[5];

		Object[] objetos = new Object[5];
		
		Conta[] contas = new Conta[5];
		
		ContaCorrente c1 = new ContaCorrente(147, 258);
		ContaCorrente c2 = new ContaCorrente(141, 158);
		
		ContaPoupanca cp = new ContaPoupanca(158, 169);
		
		contas[0] = c1;
		contas[1] = c2;
		contas[2] = cp;
		
		System.out.println(contas[1].getNumero());
		
		Conta ref = contas[1];
		
		System.out.println(ref.getAgencia());
		
	}

}
