package br.com.bytebank.teste;

public class TesteArrayString {

	public static void main(String[] args) {
		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i]);
		}
		
	}

}
