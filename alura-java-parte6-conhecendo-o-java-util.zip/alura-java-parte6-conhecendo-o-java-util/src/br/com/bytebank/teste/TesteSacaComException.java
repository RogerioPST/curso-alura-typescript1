package br.com.bytebank.teste;

import br.com.bytebank.modelo.Conta;
import br.com.bytebank.modelo.ContaCorrente;
import br.com.bytebank.modelo.SaldoInsuficienteException;

public class TesteSacaComException {
public static void main(String[] args) {
	Conta conta = new ContaCorrente(123, 475);
	
	conta.deposita(200);
	try {
		
		conta.saca(210);
	} catch(SaldoInsuficienteException e) {
		System.out.println(e.getMessage());
		e.printStackTrace();
	}
	
	System.out.println(conta.getSaldo());
	
}
}
