package br.com.bytebank.teste.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

import br.com.bytebank.modelo.Cliente;
import br.com.bytebank.modelo.Conta;
import br.com.bytebank.modelo.ContaCorrente;

public class TesteLambdas {
	public static void main(String[] args) {
		Conta cc1 = new ContaCorrente(147, 11258);
		Cliente c1 = new Cliente();
		c1.setNome("joao");
		cc1.setTitular(c1);
		cc1.deposita(333.0);

		Conta cc2 = new ContaCorrente(1473, 2585);
		Cliente c2 = new Cliente();
		c2.setNome("roger");
		cc2.setTitular(c2);
		cc2.deposita(444.0);

		Conta cc3 = new ContaCorrente(1473, 25854);
		Cliente c3 = new Cliente();
		c3.setNome("vanessa");
		cc3.setTitular(c3);
		cc3.deposita(111);

		Conta cc4 = new ContaCorrente(1473, 2585548);
		Cliente c4 = new Cliente();
		c4.setNome("pedro");
		cc4.setTitular(c4);
		cc4.deposita(222);

		List<Conta> lista = new ArrayList<>();

		lista.add(cc1);
		lista.add(cc2);
		lista.add(cc3);
		lista.add(cc4);
		
		//Function object
		//NumeroDaContaComparator22 comparator = new NumeroDaContaComparator22();
		
		
		// com os lambdas, por baixo dos panos, o Java gera uma classe anonima
		lista.sort((o1, o2) -> Integer.compare(o1.getNumero(),o2.getNumero()));
						
		
		//outra classe anonima com lambda
		Comparator<Conta> comp = (Conta o1, Conta o2) -> {
				// TODO Auto-generated method stub
				String nomec1 = o1.getTitular().getNome();
				String nomec2 = o2.getTitular().getNome();

				// criterio de compara��o est� implementado na classe string
				return nomec1.compareTo(nomec2);
			

		};
		
		lista.sort(comp);



		for (Conta conta : lista) {
			
			System.out.println(conta);
		}
		
		//classe anonima
		lista.forEach(new Consumer<Conta>() {

			@Override
			public void accept(Conta conta) {
				// TODO Auto-generated method stub
				System.out.println(conta);
				
			}
		});
		
		//lambda um pouco mais enxuto 
		lista.forEach((Conta conta) -> {
				// TODO Auto-generated method stub
				System.out.println(conta);
				
			
		});
		
		//lambda ainda mais enxuto qdo tem uma unica linha
		lista.forEach((Conta conta) -> System.out.println(conta));
			

	}

}
