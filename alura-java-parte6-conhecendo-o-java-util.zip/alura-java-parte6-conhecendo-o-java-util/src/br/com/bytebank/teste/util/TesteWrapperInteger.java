package br.com.bytebank.teste.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TesteWrapperInteger {
	public static void main(String[] args) {
		
		List argumentos = Arrays.asList(args);

		// array de primitivos
		int[] idades = new int[5];
		String[] nomes = new String[5];

		// array de referencias
		int idade = 29;
		// lista em geral, eh de referencia
		// a linha comentada abaixo n funciona
		// List<int> teste = new ArrayList<>();
		List<Integer> teste = new ArrayList<>();

		List numeros = new ArrayList();

		// n deveria funcionar, pois eh um primitivo, n eh uma referencia
		// funciona, pois, por baixo dos panos, o java faz
		// Integer idadeRef = new Integer(29);

		numeros.add(idade); // a transforma��o de primitivo p referencia se chama autoboxing e o contrario se chama unboxing
		
		Integer idadeRef = Integer.valueOf(29); //metodo p criar a referencia /autoboxing
		int valor = idadeRef.intValue(); //metodo para criar o primitivo /unboxing
		
		Integer num = Integer.valueOf(args[0]); //parsing
		int n = Integer.parseInt(args[0]);//parsing
		
		System.out.println(idadeRef.doubleValue());
		System.out.println(Integer.BYTES); //num bytes
		System.out.println(Integer.SIZE); //num bits
	}

}
