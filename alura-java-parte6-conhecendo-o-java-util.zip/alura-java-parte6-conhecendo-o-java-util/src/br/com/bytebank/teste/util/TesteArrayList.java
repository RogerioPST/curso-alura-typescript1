package br.com.bytebank.teste.util;

import java.util.ArrayList;

import br.com.bytebank.modelo.Conta;
import br.com.bytebank.modelo.ContaCorrente;

public class TesteArrayList {
	public static void main(String[] args) {
			ArrayList<Conta> lista = new ArrayList<>();
			
			Conta cc = new ContaCorrente(147, 258);

			lista.add(cc);

			Conta cc1 = new ContaCorrente(1473, 2588);

			lista.add(cc1);
			
			System.out.println(lista.size());
			
			Conta conta = (Conta) lista.get(0);
			System.out.println(conta.getNumero());
			
			lista.remove(0);
			
			System.out.println(lista.size());
			
			Conta cc3 = new ContaCorrente(147, 258);

			lista.add(cc3);

			Conta cc4 = new ContaCorrente(1473, 2588);

			lista.add(cc4);
			
			for (int i = 0; i < lista.size(); i++) {
				System.out.println(lista.get(i));
				
			}
			
			System.out.println("---------------");
			
			for (Conta cont : lista)
				System.out.println(cont);
			
	}
}
