package br.com.bytebank.teste.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import br.com.bytebank.modelo.Cliente;
import br.com.bytebank.modelo.Conta;
import br.com.bytebank.modelo.ContaCorrente;

public class TesteOrdena��o {
	public static void main(String[] args) {
		Conta cc1 = new ContaCorrente(147, 11258);
		Cliente c1 = new Cliente();
		c1.setNome("joao");
		cc1.setTitular(c1);
		cc1.deposita(333.0);

		Conta cc2 = new ContaCorrente(1473, 2585);
		Cliente c2 = new Cliente();
		c2.setNome("roger");
		cc2.setTitular(c2);
		cc2.deposita(444.0);

		Conta cc3 = new ContaCorrente(1473, 25854);
		Cliente c3 = new Cliente();
		c3.setNome("vanessa");
		cc3.setTitular(c3);
		cc3.deposita(111);

		Conta cc4 = new ContaCorrente(1473, 2585548);
		Cliente c4 = new Cliente();
		c4.setNome("pedro");
		cc4.setTitular(c4);
		cc4.deposita(222);

		List<Conta> lista = new ArrayList<>();

		lista.add(cc1);
		lista.add(cc2);
		lista.add(cc3);
		lista.add(cc4);
		

		for (Conta conta : lista) {
			System.out.println(conta);

		}
		lista.sort(new NumeroDaContaComparator());

		System.out.println("-----");
		for (Conta conta : lista) {
			System.out.println(conta);

		}

		

		lista.sort(new TitularDaContaComparator());

		System.out.println("-----");
		for (Conta conta : lista) {
			System.out.println(conta);

		}

	}

}

class NumeroDaContaComparator implements Comparator<Conta> {

	@Override
	public int compare(Conta o1, Conta o2) {
		// TODO Auto-generated method stub
		return Integer.compare(o1.getNumero(),o2.getNumero());
		//return o1.getNumero() - o2.getNumero();
	}

}

class TitularDaContaComparator implements Comparator<Conta> {

	@Override
	public int compare(Conta o1, Conta o2) {
		// TODO Auto-generated method stub
		String nomec1 = o1.getTitular().getNome();
		String nomec2 = o2.getTitular().getNome();

		// criterio de compara��o est� implementado na classe string
		return nomec1.compareTo(nomec2);
	}

}
