package br.com.bytebank.teste.util;

import java.util.ArrayList;

import br.com.bytebank.modelo.Conta;
import br.com.bytebank.modelo.ContaCorrente;

public class TesteArrayListEquals {
	public static void main(String[] args) {
		// Generics
		ArrayList<Conta> lista = new ArrayList<>();

		Conta cc = new ContaCorrente(147, 258);

		lista.add(cc);

		Conta cc1 = new ContaCorrente(1473, 2588);

		lista.add(cc1);
		
		Conta cc3 = new ContaCorrente(1473, 2588);

		
		//o contains usa o equals para verificar
		boolean existe = lista.contains(cc3);
		
		System.out.println("existe? " + existe);
		
		for (Conta cont : lista)
			System.out.println(cont);

	}
}
