package br.com.bytebank.teste.util;

import java.util.ArrayList;
import java.util.List;

public class TesteOutrosWrappers {
	public static void main(String[] args) {
		Integer idadeRef = Integer.valueOf(29); //autoboxing
		System.out.println(idadeRef.intValue()); //unboxing
		
		Double dRef = 3.2 ; //o Java faz o autoboxing
		
		Double ddref = Double.valueOf(3.2); //autoboxing
		System.out.println(ddref.doubleValue()); //unboxing
		
		Boolean bref = Boolean.valueOf(false); //autoboxing
		System.out.println(bref.booleanValue()); //unboxing
		
		Number numero = Double.valueOf(32.2);
		
		List<Number> lista = new ArrayList<>();
		
		lista.add(10);
		lista.add(21.2);
		lista.add(12.2f);
	}
}
