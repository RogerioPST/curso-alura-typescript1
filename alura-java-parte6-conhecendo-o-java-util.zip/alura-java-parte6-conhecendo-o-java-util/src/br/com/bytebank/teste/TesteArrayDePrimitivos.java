package br.com.bytebank.teste;

public class TesteArrayDePrimitivos {

	public static void main(String[] args) {
		int[] idades = new int[5];
	}

}
