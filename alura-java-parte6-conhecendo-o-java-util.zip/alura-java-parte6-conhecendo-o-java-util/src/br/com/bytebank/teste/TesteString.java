package br.com.bytebank.teste;

public class TesteString {
	public static void main(String[] args) {
		int a = 3;
		
		String vazio = "";
		String outroVazio = vazio.trim();
		
		System.out.println(vazio.isEmpty());
		System.out.println(outroVazio.isEmpty());
		//String � imutavel
		String nome = "Alura"; //objeto literal
		
		System.out.println(nome.length());
		
		String sub = nome.substring(1);
		System.out.println(sub);
		
		int pos = nome.indexOf("ur");
		System.out.println(pos);
		
		char c = nome.charAt(0);
		System.out.println(c);
		
		char ce = 'A';
		
		
		String outra = nome.replace("A", "a");
		
		System.out.println(nome);
		System.out.println(outra);
		
	}
}
