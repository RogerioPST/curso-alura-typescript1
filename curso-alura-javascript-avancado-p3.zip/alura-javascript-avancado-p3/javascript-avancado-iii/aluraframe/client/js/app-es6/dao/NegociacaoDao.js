import {Negociacao} from '../models/Negociacao';

export class NegociacaoDao{
    constructor(connection){
        this._connection = connection;
        this._store = 'negociacoes';
    }

    adiciona(negociacao){
        return new Promise((resolve, reject) =>{            

            let transaction = this._connection.transaction([this._store], 'readwrite');
            let store = transaction.objectStore(this._store);

            
            //Chamar simplesmente store.add pode ou não adicionar efetivamente um objeto dentro de uma store, mas sempre ficaremos na dúvida se a operação foi realizada com sucesso. É por isso que o método add retorna uma requisição de abertura e no callback passado para seu evento onsuccess, quando ele for chamado, temos certeza de que o objeto foi adicionado. Caso um erro aconteça, o callback passado para onerror será chamado.
            let request = store.add(negociacao);

            request.onsuccess = e =>{
                //console.log('negociacao incluida com sucesso');
                resolve();
            }

            request.onerror = e =>{
                console.log(e.target.error);
                reject('n foi possivel add a negociacao');
            }

        });
    }

    listaTodos(){
        return new Promise((resolve, reject) => {

            let cursor = this._connection
                .transaction([this._store], 'readwrite')
                .objectStore(this._store)
                .openCursor();

            let negociacoes =[];

            cursor.onsuccess = e =>{
                //retorna o ponteiro
                let atual = e.target.result;

                if(atual){
                    let dado = atual.value;

                    negociacoes.push(new Negociacao(dado._data, dado._quantidade, dado._valor));

                    atual.continue();
                }   else{

                    console.log('listada com sucesso');
                    resolve(negociacoes);
                }

            };

            cursor.onerror = e =>{                
                console.log(e.target.error);
                reject('negociacao NAO listada');
            };

        });
    }

    apagaTodos(){
        return new Promise((resolve, reject) =>{
            let request = this._connection
                .transaction([this._store], 'readwrite')
                .objectStore(this._store)
                .clear();

            request.onsuccess = e => resolve('neg removidas com sucesso');

            request.onerror = e => {
                console.log(e.target.error);
                reject('neg n foram removidas c sucesso');
            };

        });
    }
}