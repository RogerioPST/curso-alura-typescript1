
var ConnectionFactory = (function (){


const stores = ['negociacoes'];

const version = 4;

const dbName = 'aluraframe';

var close = null;

//codigo para manter a mesma conexao e n criar uma nova sempre
var connection = null;
//fim

// 1º passo - como connection n estava privada, cria a funcao tmp e dah o return na classe p ela ficar disponivel la embaixo no codigo
//2º passo, desse jeito, dah p chamar tmp e eu n quero q fique disponivel. Para isso, cria-se a funcao anonima
return class ConnectionFactory{

    constructor(){
        throw new Error('n eh possivel criar instancias de connection factory')
    }
    static getConnection(){
        return new Promise((resolve, reject) => {
            //segundo parametro = 4 - manter a mesma versao do arquivo aprendendo-a-usar-banco-indexedb.html
            //se quisesse atualizar, incrementaria essa versao
            let openRequest = window.indexedDB.open(dbName, version);

            openRequest.onupgradeneeded = e =>{
                ConnectionFactory._createStores(e.target.result);                
            };
            
            openRequest.onsuccess = e =>{
                //codigo para manter a mesma conexao e n criar uma nova sempre
                if (!connection){
                    connection = e.target.result;
                    //MONKEY PATCH - sobrescrever o metodo close de connection
                        //a variavel close guardou o metodo connection.close() antes de ser sobreescrito
                        //em connection.close, o this de close eh connection
                        //por isso, precisa fazer o bind para connection, se n vai dar erro
                        close = connection.close.bind(connection);
                        //fim
                    connection.close = function(){
                        throw new Error('vc n pode fechar diretamente a conexao');
                    };
                    //fim
                }
                resolve(connection);
                //fim
                
            };
            
            openRequest.onerror = e =>{
                console.log(e.target.error);

                reject(e.target.error.name);
                
            };
        });
    }

    static closeConnection(){
        if (connection){
            //a variavel close guardou o metodo connection.close() antes de ser sobreescrito, desde q seja feito o bind
            // ou faça Reflect.apply(close, connection, []); // assim n precisa do bind la em cima
            close();
            connection = null;
            console.log('fechando a conexao');
        }
    }
    
    static _createStores(connection){
        stores.forEach(store => {
            if (connection.objectStoreNames.contains(store)){
                connection.deleteObjectStore(store);
            } 
    
            connection.createObjectStore(store, {autoIncrement: true});
        });
        
    }
}
}
)(); //3º passo - criando uma funcao anonima autoinvocavel
//para isso, basta envolver a funcao anonima com parentes e invoca-la colocando (); depois do parenteses envolvido;
//isso eh chamado de MODULE PATTERN - transofrmou todo script em modulo e escolhemos o q queremos exportar para o mundo externo, escondendo o restante,
//as variaveis stores, version, dbName

//1º passo -
//com isso, ConnectionFactory fica disponivel como se fosse a classe para usar metodo estatico
//var ConnectionFactory = tmp();