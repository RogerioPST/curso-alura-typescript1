export class View{
    constructor(elemento){
        this._elemento = elemento;

    }
    template(model){
        throw new Error('O metodo template deve ser implementado.');

    }
    update(model){
        // innerhtml converte essa string em elementos do DOM
        this._elemento.innerHTML = this.template(model);
    }
}