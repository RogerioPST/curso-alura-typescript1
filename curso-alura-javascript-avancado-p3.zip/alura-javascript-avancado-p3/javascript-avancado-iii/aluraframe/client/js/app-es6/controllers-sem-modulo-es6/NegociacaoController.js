//O C é o controller, aquele que disponibiliza um modelo para a view.
        //O controller é aquele que recebe as ações do usuário e que sabe interagir com o modelo. Como o modelo é independente da view, esta precisa ser renderizada para que reflita as alterações no modelo. Em suma, o controller é a ponte de ligação entre a view e o modelo.
class NegociacaoController{

    constructor(){
        //Se em JavaScript temos as Higher-Order Functions, podemos declarar a variável $ - como usado no jQuery - e dentro, jogaremos o document.querySelector
        //let $ = document.querySelector;
        //Não funcionou colocarmos o querySelector na variável $ para criarmos um alias. Por que não funcionou? O querySelector é uma função que pertence ao objeto document - chamaremos tal função de método. Internamente, o querySelector tem uma chamada para o this, que é o contexto pelo qual o método é chamado. Logo, o this é o document. No entanto, quando colocamos o querySelector dentro do $, ele passa a ser executado fora do contexto de document e isto não funciona. O que devemos fazer, então? Queremos tratar o querySelector como uma função separada. Nós queremos que ao colocarmos o querySelector para o $, ele mantenha a associação com o document. Para isto, usaremos o bind() :
        console.log(document.querySelector); // eh uma funcao e n pertence a um objeto e soh isso ele perde a associacao com o document
        var $ = document.querySelector.bind(document);


        // se eu adicionar 300 negociacoes, ele soh vai ter buscado no DOM uma unica vez cada um desses elementos
        // melhor performance
        // diferente se eu usasse let inputData = $('#data'), por exemplo - pior performance        
        this._inputData = $('#data');
        this._inputQuantidade = $('#quantidade');
        this._inputValor = $('#valor');

        this._ordemAtual = ''; // quando a página for carregada, não tem critério. Só passa a ter quando ele começa a clicar nas colunas

        this._negociacoesView = new NegociacoesView($('#negociacoesView'));        
        this._mensagemView = new MensagemView($('#mensagemView'));

        //se eu estou criando o proxy, no fim das contas, estou querendo realizar um data binding
        //associacao de dados entre o modelo e a view, ou seja, toda vez q meu modelo mudar, eu quero
        // disparar a atualização da view. alem disso, n estah 100%, pq mesmo criando a proxy, preciso chamar o update

        //o codigo abaixo quer dizer: quero criar uma associacao entre o param 1 e o param2 qdo algum dos param 3 forem chamados
        this._listaNegociacoes = new Bind(new ListaNegociacoes(),this._negociacoesView,
            'adiciona', 'esvazia', 'ordena', 'inverteOrdem');

            /*
        this._listaNegociacoes = ProxyFactory.create(
            new ListaNegociacoes(), 
            ['adiciona', 'esvazia'],   
            (model) => this._negociacoesView.update(model) 
            );
            */


        // esse codigo abaixo funciona sem usar arrow function!
        // com arrow function, como muda o esopo lexico de this, n precisamos desse codigo abaixo.
        //this._listaNegociacoes = new ListaNegociacoes(this, function(model){
            // qdo essa função eh executada no contexto de listaNegociacoes, a funcao tem contexto dinamico
            //o this dentro de uma funcao para ser avaliado depende do contexto no qual ela foi executada
            // e essa funcao qdo eh chamada, ela eh executada no contexto de listaNegociacoes
            //entao, qdo passo this em this._armadilha(this) -> this = listaNegociacoes 
            //mas qdo armadilha, ela eh executada, ela eh executada no contexto de listaNegociacoes
            //entao, o this de (this._negociacoesView.update(model))  é a listaNegociacoes! ferrou!
        //    console.log(this);
            //o q precisamos eh fazer com q o this seja o de NegociacaoController
       //     this._negociacoesView.update(model);    
      //  });
      //com arrow function
      //this._listaNegociacoes = new ListaNegociacoes(model =>{
       // console.log(this);
       // this._negociacoesView.update(model);
      //});


        

        //se eu estou criando o proxy, no fim das contas, estou querendo realizar um data binding
        //associacao de dados entre o modelo e a view, ou seja, toda vez q meu modelo mudar, eu quero
        // disparar a atualização da view. alem disso, n estah 100%, pq mesmo criando a proxy, preciso chamar o update
        //para atualizar a view na primeira vez antes da modificação.

        /*criando uma proxy para a mensagem tb, pois precisa atualizar a view    
        this._mensagem = ProxyFactory.create(
            new Mensagem(),
            ['texto'],
            model => this._mensagemView.update(model)
            );
            */

        this._mensagem = new Bind(new Mensagem(), this._mensagemView, 'texto');    

        this._service = new NegociacaoService();
  
        this._init();
        
    }
    
    _init(){

        this._service
            .lista()            
            //acima, tem-se o return implicito
            //Promise pode ter código assíncrono e sincrono e o then pode retornar qualquer coisa, não apenas promise. O retorno é acessivel pelo then. 
            //posso usar then() com qualquer método/função que retorne um valor, é isso?
            //Pode, mas o método deve devolver um promise, se não o then não existirá. Já o retorno do then pode ser uma promise ou não.            
            .then(negociacoes =>
                negociacoes.forEach(negociacao =>
                    this._listaNegociacoes.adiciona(negociacao)))
            .catch(erro => {
                console.log(erro);
                this._mensagem.texto = error;
            })
    
    /* uma forma mais verbosa de usar as promises na sequencia
        ConnectionFactory.getConnection()
            .then(connection => {
                new NegociacaoDao(connection)
                    .listaTodos()
                    .then(negociacoes =>{
                        negociacoes.forEach(negociacao =>{
                            this._listaNegociacoes.adiciona(negociacao);
                        })
                    })
            });
    */
        //a cada 3 segundos serão importadas as negociações
        setInterval(() =>{
            this.importaNegociacoesSemPromise();
        }, 3000);        
                            
    }
    adiciona(event){
        // previne o event de executar o comportamento padrao, q no caso do formulario eh submeter o form e permite q n seja recarregaa a pagina
        event.preventDefault();
        
        //O C é o controller, aquele que disponibiliza um modelo para a view.
        //O controller é aquele que recebe as ações do usuário e que sabe interagir com o modelo. Como o modelo é independente da view, esta precisa ser renderizada para que reflita as alterações no modelo. Em suma, o controller é a ponte de ligação entre a view e o modelo.
        
        //let helper = new DateHelper();

        let negociacao = this._criaNegociacao();


        this._service
            .cadastra(negociacao)
            .then(msg =>{
                console.log(negociacao);
        
                console.log(DateHelper.dataParaTexto(negociacao.data));
                this._listaNegociacoes.adiciona(negociacao);
                this._mensagem.texto = 'Negociação adicionada com sucesso'; 
                this._limpaFormulario();   
            })
            .catch(erro => this._mensagem.texto = erro);                                            

  

        //N TEM PROBLEMA zerar o length, pq eh a copia
        //this._listaNegociacoes.negociacoes.length = 0;

        //console.log(this._listaNegociacoes.negociacoes);                        
    }
    
    importaNegociacoesSemPromise() {
        this._service.importa(this._listaNegociacoes)
        .then(negociacoes => {
            negociacoes.forEach(negociacao => this._listaNegociacoes.adiciona(negociacao));
            this._mensagem.texto = 'Negociações do período importadas com sucesso';
          })
          .catch(error => this._mensagem.texto = error);  
    } 
    importaNegociacoes(){
        let service = new NegociacaoService();

        //Promise.all devolve um  resultado em q de acordo com a ordem dos parametros (array) q vou colocando na funcao all
        // vai sendo executada essa req assincrona na sequencia
        //mas vai devolver uma lista de lista de negociacoes e nao apenas uma lista de negociacoes
        //por isso, precisa fazer o reduce.                
        Promise.all([
            service.obterNegociacoesDaSemana(), 
            service.obterNegociacoesDaSemanaAnterior(), 
            service.obterNegociacoesDaSemanaRetrasada()]
        )
        //usamos os métodos then e catch para capturar o resolve e o reject oriundo da promisse e dentro deles é necessário passar uma function ou Arrow function com o comando desejado.
        .then(negociacoes=> {
            
            console.log(negociacoes);
            negociacoes
                // faz o reduce para achatar para um unico array, q começa em branco
                .reduce((arrayAchatado, array) => arrayAchatado.concat(array), [])
                .forEach(negociacao=> this._listaNegociacoes.adiciona(negociacao));
                this._mensagem.texto = 'Neg Importadas com sucesso';
        })
        .catch(erro => this._mensagem.texto = erro);

        
        
    }
    _criaNegociacao(){
        return new Negociacao(
            DateHelper.textoParaData(this._inputData.value),
            parseInt(this._inputQuantidade.value),
            parseFloat(this._inputValor.value)
        );
    }

    _limpaFormulario(){
        document.querySelector('form').reset();
        this._inputData.focus();
    }

    apaga(){

        this._service
            .apaga()            
            .then(mensagem => {
                this._mensagem.texto = mensagem;        
                this._listaNegociacoes.esvazia();                                
            })
            .catch(erro => this._mensagem.texto = erro);

    }

    ordena(coluna) {
        if(this._ordemAtual == coluna) {
            // chamo inverte, pois, sei q jah estah ordenado ascendentemente
            this._listaNegociacoes.inverteOrdem();
        } else {
            //Veja que interessante. Não podemos fazer a.quantidade ou a.data, porque a propriedade usada no critério de ordenação é escolhida pelo usuário. Sendo assim, usamos a sintaxe objeto[nomePropriedade] para acessar a propriedade do objeto. Essa forma mais verbosa é interessantíssima quando queremos acessar as propriedades de um objeto dinamicamente .
            this._listaNegociacoes.ordena((a, b) => a[coluna] - b[coluna]);    
        }
        this._ordemAtual = coluna;
    }
}