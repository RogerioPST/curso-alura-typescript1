import {HttpService} from './HttpService';
import {ConnectionFactory} from './ConnectionFactory';
import {NegociacaoDao} from '../dao/NegociacaoDao';

import {Negociacao} from '../models/Negociacao';


export class NegociacaoService{    
    constructor(){
        this._http = new HttpService();
    }

    obterNegociacoes() {

        return Promise.all([
            this.obterNegociacoesDaSemana(),
            this.obterNegociacoesDaSemanaAnterior(),
            this.obterNegociacoesDaSemanaRetrasada()
        ]).then(periodos => {

            let negociacoes = periodos
                .reduce((dados, periodo) => dados.concat(periodo), []);

            return negociacoes;

        }).catch(erro => {
            throw new Error(erro);
        });

    } 

    obterNegociacoesDaSemana() {
      
//A ideia é a seguinte, se uma função then possui um retorno, este retorno é acessível para quem encadear uma nova chamada à função then. Sendo assim, onde há resolve trocaremos por um return. Mas cuidado, não esqueça de remover também os () do resolve!
        

            return this._http
                .get('negociacoes/semana')
                .then(negociacoes => {
                    return negociacoes.map(objeto => new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor));
                })
                .catch(erro => {
                    console.log(erro);
                    return 'Não foi possível obter as negociações da semana';
                    //ou lanço erro // throw new Error('Não foi possível obter as negociações da semana');
                })
       
    }

   
    obterNegociacoesDaSemanaAnterior() {

        
    
            return this._http
                .get('negociacoes/anterior')
                .then(negociacoes => {
                    console.log(negociacoes);
                    return negociacoes.map(objeto => new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor));
    
                })
                .catch(erro => {
                    console.log(erro);
                    return 'Não foi possível obter as negociações da semana anterior';
                    //ou lanço erro // throw new Error('Não foi possível obter as negociações da semana');
                })
        
    }
    
    obterNegociacoesDaSemanaRetrasada() {
        //A ideia é a seguinte, se uma função then possui um retorno, este retorno é acessível para quem encadear uma nova chamada à função then. Sendo assim, onde há resolve trocaremos por um return. Mas cuidado, não esqueça de remover também os () do resolve!

        //Mas ainda não acabou! E se um erro acontecer? No lugar de usarmos reject, lançamos uma exceção em seu lugar:
  
    
            return this._http
                .get('negociacoes/retrasada')
                .then(negociacoes => {
                    console.log(negociacoes);
                    return negociacoes.map(objeto => new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor));
    
                })
                .catch(erro => {
                    console.log(erro);
                    
                    return 'Não foi possível obter as negociações da semana retrasada';
                    //ou lanço erro // throw new Error('Não foi possível obter as negociações da semana');
                })
        
    }

    cadastra(negociacao){
        return ConnectionFactory.getConnection()
            .then(connection => new NegociacaoDao(connection))
            .then(dao => dao.adiciona(negociacao))
            .then(() => 'Neg add c sucesso')
            .catch(erro => {
                console.log(erro);
                throw new Error('n foi possivel add neg');
            });
       
    }

    lista(){
        return ConnectionFactory.getConnection()
            .then(co => new NegociacaoDao(co))
            .then(dao => dao.listaTodos())
            .catch(erro => {
                console.log(erro);
                throw new Error('n foi possivel listar as neg');
            });
    }

    apaga(){
        return ConnectionFactory.getConnection()
            .then(co => new NegociacaoDao(co))
            .then(dao => dao.apagaTodos())
            .then(() => 'neg apagadas com sucesso')
            .catch(erro => {
                console.log(erro);
                throw new Error('n foi possivel apagar as neg');
            });
    }

    importa(listaAtual){
        return this.obterNegociacoes()
        // to fazendo filter. filter eh como se fosse um foreach. ele vai varrer cada item de negociacao e vai jogar dentro do array de negociacoes
        // em seguida, pergunta via some para listaNegociacoes, q vai varrer o array listaNegociacoes perguntando se tem alguma negociacao igual 
        //atraves de JSON.stringfy(negociacao ) == JSOn.stringfy(negociacaoExistente)
        //se a verificação do stringfy for verdadeiro, o some vai retornar verdadeiro
        //se isso ocorrer, o filter vai retornar no array de negociacoes
        //como estamos querendo q nao se importe negociacoes iguais, 
        //temos q negar a verificação atraves de "!" no some
        //JSON.stringfy transforma/serializa o objeto em string
        //esse artificio ajuda a comparar valores de objetos p saberem se sao iguais
        .then(negociacoes =>
            negociacoes.filter(negociacao => 
                !listaAtual.negociacoes.some(negociacaoExistente => 
                    negociacao.isEquals(negociacaoExistente)))       
        )
        .catch(erro =>{
            console.log(erro);
            throw new Error('n foi possivel buscar as neg');
        });
        
    }
  }  


