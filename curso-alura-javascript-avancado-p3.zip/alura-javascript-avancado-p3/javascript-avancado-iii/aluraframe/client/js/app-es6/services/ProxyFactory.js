export class ProxyFactory{
    //parametros - objeto - objq eu quero criar a proxy
    //objeto = new ListaNegociacoes(), por exemplo
    //props - as propriedades q quero observar , um array nesse caso props = ['adiciona', 'esvazia']
    //acao - a acao q quero executar para essas propriedades qdo forem acessadas ; no nosso caso, sao metodos.
    //acao = self._negociacoesView.update(target);
    static create(objeto, props, acao){
        return new Proxy(objeto, {
            //como eh um objeto, posso fazer "get: function(target, prop,  receiver){"
            get(target, prop,  receiver){
                //se a propriedade estah na lista abaixo (adiciona, esvazia) e eh uma função, pois poderia ter uma propriedade q n eh uma funcao
                console.log('target[prop]: ' +target[prop]);
                console.log('prop: ' +prop);
                if (props.includes(prop) && ProxyFactory._ehFuncao(target[prop])){
                    //se estou retornando uma function, significa q o metodo la do objeto, vou trocar ele por outro
                    //e esse meu metodo vai ter a minha armadilha, mas eu vou substituir eh no Proxy e n no obj real
                    //ja q o proxy n me permite botar uma armadilha p metodo, se eu cair aqui no metodo q quero interceptar, 
                    //vou substituir esse metodo no proxy por outro
                    //esse outro metodo vai receber os parametros q ele está recebendo em "lista.adiciona(new Negociacao(new Date(), 1, 100 ));"
                    //como estou recebendo 'adiciona' ou 'esvazia', vou te substituir no proxy reotrnando a nova funcao
                    //por isso o contexto do Reflect.apply eh target , pois eh o proprio proxy
                    //vai alterar o codigo no proxy do metodo adiciona e do esvazia
                    //
                    return function(){
                        console.log('interceptando no if: ' + prop);
                        

                        // vai continuar a execução normal chamando o metodo e executando os parametros originais (arguments)
                        let retorno = Reflect.apply(target[prop], target, arguments);
                        //e como essa acao, pode retornar um valor, vou colocar o return 
                        //e para ser generico tb como no caso do getNomeCompleto                        
                        acao(target);
                        //se por um acaso retorno (q eh a execucao do metodo) n retornar nada, retorno serah undefined, o q eh esperado
                        //caso contrario, retornara o retorno do metodo, como no caso do nome completo 
                        return retorno;
                    }
                }
                
                console.log(`a prop ${prop} foi interceptada no else`);
                //Veja que a instrução a seguir é muito importante: return Reflect.get(target, prop, receiver). É ela que efetivamente realiza a operação no objeto real.
                return Reflect.get(target, prop,  receiver);
            },
            set(target, prop, value, receiver){
                let retorno = Reflect.set(target, prop, value, receiver);
                if (props.includes(prop)){    
                    //console.log('target[prop]: ', target[prop]);
                    console.log('target: ', target);                
                    console.log('acao: ', acao);
                    //o trecho abaixo funcionava, mas um olhar atento percebe que se a propriedade é uma que estamos monitorando, aplicamos target[prop]= value para aplicar o valor recebido na propriedade. Mas veja que precisamos fazer a mesma coisa se a propriedade não é monitorada, caso contrário ela nunca receberá seu valor.
                    //por isso, comentamos a linha abaixo
                  //  target[prop] = value;
                  //  console.log('target[prop]: ', target[prop]);
                    acao(target);
                    
                }
                return retorno;
                
            }
        });

    }

    static _ehFuncao(funcao){
        return typeof(funcao) == typeof(Function);
    }
}