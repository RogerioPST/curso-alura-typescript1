//M é o modelo, uma abstração do mundo real, os dados da aplicação e suas regras de negócio.

 
//O padrão MVC permite que alterações de layout na view não acarretem alterações no modelo.
class Negociacao{
    constructor(data, quantidade, valor){

        //PROGRAMACAO DEFENSIVA
        // vou devolver uma nova referencia, um novo objeto
        //getTime(0 - devolve o EPOCH da data =  um numero grande desde 1970+- = um numero q representa essa data)
        // no construtor do date, aceita o EPOCH p fazer uma nova data
        //como eh um novo objeto, se tentar alterar a data fora no index, vc soh estah alterando a copia e n vai estar alterando o interno
        this._data = new Date(data.getTime());
        this._quantidade =quantidade;
        this._valor =valor;
        // como eu n posso alterar uma negociação depois de feita, uso Object.freeze(this), onde
        // this representa a propria instancia do objeto Negociacao
        //para verificar se um objeto estah freeze, fazemos Object.isFrozen();
        // n funciona quando a referencia eh um outro objeto, como em new Date(); -> nesse caso, usar programação defensiva.
        //Object.freeze() eh shallow (raso), ele será aplicado nas propriedades do objeto, mas as propriedade que são objetos não serão todas congeladas. A ação ficará apenas na superfície. Para resolver esta questão, falamos um pouco sobre programação defensiva.
        Object.freeze(this);
    }

    get volume(){
        return this._quantidade * this._valor;
    }

    get data(){
        //PROGRAMACAO DEFENSIVA
        // vou devolver uma nova referencia, um novo objeto
        //getTime(0 - devolve o EPOCH da data =  um numero grande desde 1970+- = um numero q representa essa data)
        // no construtor do date, aceita o EPOCH p fazer uma nova data
        //como eh um novo objeto, se tentar alterar a data fora no index, vc soh estah alterando a copia e n vai estar alterando o interno
        return new Date(this._data.getTime());
    }

    get quantidade(){
        return this._quantidade;
    }

    get valor(){
        return this._valor;
    }

    isEquals(outraNegociacao) {        
        ////JSON.stringfy transforma/serializa o objeto em string
        //esse artificio ajuda a comparar valores de objetos p saberem se sao iguais
        return JSON.stringify(this) == JSON.stringify(outraNegociacao)
    }
    /*
    Agora imagine que o atributo quantidade não pudesse ser considerado na hora de comparar duas negociações. Ou seja, uma negociação deve ser igual a outra quando apenas a data e o valor são iguais:

var hoje = new Date();
var n1 = new Negociacao(hoje, 1, 100);
var n2 = new Negociacao(hoje, 5, 100);

n1.isEquals(n2); //retorna false, mas queremos true
Como encapsulamos o nosso código, já sabemos onde mexer. Mas não podemos mais usar o JSON.stringify(..) para testar a igualdade. Lembrando JSON.stringify(..) se baseia em todos os atributos! Usaremos cada atributo separadamente:

class Negociacao {

    //construtor e outros métodos omitidos

    isEquals(outraNegociacao) {        
        return this._data.getTime() == outraNegociacao.data.getTime()
            && this._valor == outraNegociacao.valor;
    }
}
*/
}