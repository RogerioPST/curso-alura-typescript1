class ListaNegociacoes{
    constructor(){
        this._negociacoes = [];
        

    }

    adiciona(negociacao){
        this._negociacoes.push(negociacao);
        

        
    }

    get negociacoes(){
        //esse eh um truque de programação defensiva = return [].concat(this._negociacoes);
        //pois vai criar uma copia da lista e não vai mexer na original.
        return [].concat(this._negociacoes);
    }

    esvazia(){
        this._negociacoes =[];
       
    }

    // novo método
    get volumeTotal() {
        //MODO DE FAZER USANDO REDUCE DO ECMASCRIPT 6
        return this._negociacoes.reduce((total, n) => total + n.volume, 0.0);
     }

    ordena(criterio) {
        this._negociacoes.sort(criterio);        
    }

    inverteOrdem() {
        this._negociacoes.reverse();
    }
}