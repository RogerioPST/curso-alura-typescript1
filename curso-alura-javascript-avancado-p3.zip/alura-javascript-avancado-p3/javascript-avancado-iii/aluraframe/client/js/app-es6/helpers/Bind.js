import {ProxyFactory} from '../services/ProxyFactory';

export class Bind{
    //...props = indica q props vai virar um array de qtos parametros vierem a partir da 
    //terceira posicao do parametro 3 - Rest operator
    //    com isso, posso passar 'adiciona', 'esvazia' no NegociacoesController
    // ou 'texto' no NegociacoesController
    constructor(model, view, ...props){
        let proxy = ProxyFactory.create(model, props, (model) =>
            view.update(model)
        );
        view.update(model);

        return proxy;
    }
}