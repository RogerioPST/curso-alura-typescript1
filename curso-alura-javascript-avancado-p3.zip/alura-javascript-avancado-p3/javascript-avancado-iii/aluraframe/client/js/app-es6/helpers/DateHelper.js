export class DateHelper{
    
    constructor(){
        throw new Error('Esta classe Datehelper n pode ser instanciada');
    }

    static textoParaData(texto){
        // 1ª OPÇÃO DE CRIAR UMA DATA
        //let dataB = new Date(this._inputData.value.split('-'));
        //console.log('AQUI', dataB);

        //2ª OPÇÃO PARA CRIAR UMA DATA - a mesma coisa com regex
        //Temos a string que esperávamos receber. Mas, além de usar o split(), poderíamos utilizar o replace(). Adicionaremos uma expressão regular pedindo que seja trocado o hífen de todas as ocorrências da string (ou seja, global) por ,: replace(/-/g, ',').
        //        let datan = new Date(this._inputData.value.replace(/-/g, ','));
        //console.log('ALI', datan);
/*
        //TERCEIRA OPÇÃO DE CRIAR A DATA
        //... spread operator do ecmascript 2015
        let dataC = new Date(...
            this._inputData.value
                .split('-')
                .map(function(item, indice){
                    if (indice == 1){
                        // retira um para o mes, pois data considera array começando em 0 o index do mes
                        return item -1;
                    }
                    return item;
                })  
        );

        console.log('datac', dataC);
*/
        //quarta opção com arrow function DE CRIAR A DATA
        //... spread operator do ecmascript 2015
        //console.log('datac', dataD);
        // mudamos a validação para aceitar o novo formato!
        //Quando alteramos nossa expressão regular, trocamos - por /, contudo, como esse é um caractere especial, precisamos usar \/. O nosso processo de desmembrar a string continua o mesmo, mas como temos uma data no formato dd/mm/aaaa, precisamos realizar um split usando / como separador e aplicar um .reverse()! A inversão dos itens do array é importante, porque a função map espera encontrar um array com ano, mês e dia e não dia, mês e ano.
        if(!/\d{2}\/\d{2}\/\d{4}/.test(texto)) 
            throw new Error('Deve estar no formato dd/mm/aaaa');

        // veja que usamos no split '/' no lugar de '-'. Usamos `reverse` também para ficar ano/mes/dia.      
        return new Date(...texto.split('/').reverse().map((item, indice) => item - indice % 2));

        

    }

    static dataParaTexto(data){
        return `${data.getDate()}/${data.getMonth()+1}/${data.getFullYear()}`;
        //ou
        //return data.getDate()            + '/' + (data.getMonth() +1)            + '/' + data.getFullYear();
    }
}