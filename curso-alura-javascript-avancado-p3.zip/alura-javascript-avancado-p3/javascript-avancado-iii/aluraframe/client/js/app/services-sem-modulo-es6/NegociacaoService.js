'use strict';

System.register([], function (_export, _context) {
    "use strict";

    var _createClass, NegociacaoService;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    return {
        setters: [],
        execute: function () {
            _createClass = function () {
                function defineProperties(target, props) {
                    for (var i = 0; i < props.length; i++) {
                        var descriptor = props[i];
                        descriptor.enumerable = descriptor.enumerable || false;
                        descriptor.configurable = true;
                        if ("value" in descriptor) descriptor.writable = true;
                        Object.defineProperty(target, descriptor.key, descriptor);
                    }
                }

                return function (Constructor, protoProps, staticProps) {
                    if (protoProps) defineProperties(Constructor.prototype, protoProps);
                    if (staticProps) defineProperties(Constructor, staticProps);
                    return Constructor;
                };
            }();

            NegociacaoService = function () {
                function NegociacaoService() {
                    _classCallCheck(this, NegociacaoService);

                    this._http = new HttpService();
                }

                _createClass(NegociacaoService, [{
                    key: 'obterNegociacoes',
                    value: function obterNegociacoes() {

                        return Promise.all([this.obterNegociacoesDaSemana(), this.obterNegociacoesDaSemanaAnterior(), this.obterNegociacoesDaSemanaRetrasada()]).then(function (periodos) {

                            var negociacoes = periodos.reduce(function (dados, periodo) {
                                return dados.concat(periodo);
                            }, []);

                            return negociacoes;
                        }).catch(function (erro) {
                            throw new Error(erro);
                        });
                    }
                }, {
                    key: 'obterNegociacoesDaSemana',
                    value: function obterNegociacoesDaSemana() {

                        //A ideia é a seguinte, se uma função then possui um retorno, este retorno é acessível para quem encadear uma nova chamada à função then. Sendo assim, onde há resolve trocaremos por um return. Mas cuidado, não esqueça de remover também os () do resolve!


                        return this._http.get('negociacoes/semana').then(function (negociacoes) {
                            return negociacoes.map(function (objeto) {
                                return new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor);
                            });
                        }).catch(function (erro) {
                            console.log(erro);
                            return 'Não foi possível obter as negociações da semana';
                            //ou lanço erro // throw new Error('Não foi possível obter as negociações da semana');
                        });
                    }
                }, {
                    key: 'obterNegociacoesDaSemanaAnterior',
                    value: function obterNegociacoesDaSemanaAnterior() {

                        return this._http.get('negociacoes/anterior').then(function (negociacoes) {
                            console.log(negociacoes);
                            return negociacoes.map(function (objeto) {
                                return new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor);
                            });
                        }).catch(function (erro) {
                            console.log(erro);
                            return 'Não foi possível obter as negociações da semana anterior';
                            //ou lanço erro // throw new Error('Não foi possível obter as negociações da semana');
                        });
                    }
                }, {
                    key: 'obterNegociacoesDaSemanaRetrasada',
                    value: function obterNegociacoesDaSemanaRetrasada() {
                        //A ideia é a seguinte, se uma função then possui um retorno, este retorno é acessível para quem encadear uma nova chamada à função then. Sendo assim, onde há resolve trocaremos por um return. Mas cuidado, não esqueça de remover também os () do resolve!

                        //Mas ainda não acabou! E se um erro acontecer? No lugar de usarmos reject, lançamos uma exceção em seu lugar:


                        return this._http.get('negociacoes/retrasada').then(function (negociacoes) {
                            console.log(negociacoes);
                            return negociacoes.map(function (objeto) {
                                return new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor);
                            });
                        }).catch(function (erro) {
                            console.log(erro);

                            return 'Não foi possível obter as negociações da semana retrasada';
                            //ou lanço erro // throw new Error('Não foi possível obter as negociações da semana');
                        });
                    }
                }, {
                    key: 'cadastra',
                    value: function cadastra(negociacao) {
                        return ConnectionFactory.getConnection().then(function (connection) {
                            return new NegociacaoDao(connection);
                        }).then(function (dao) {
                            return dao.adiciona(negociacao);
                        }).then(function () {
                            return 'Neg add c sucesso';
                        }).catch(function (erro) {
                            console.log(erro);
                            throw new Error('n foi possivel add neg');
                        });
                    }
                }, {
                    key: 'lista',
                    value: function lista() {
                        return ConnectionFactory.getConnection().then(function (co) {
                            return new NegociacaoDao(co);
                        }).then(function (dao) {
                            return dao.listaTodos();
                        }).catch(function (erro) {
                            console.log(erro);
                            throw new Error('n foi possivel listar as neg');
                        });
                    }
                }, {
                    key: 'apaga',
                    value: function apaga() {
                        return ConnectionFactory.getConnection().then(function (co) {
                            return new NegociacaoDao(co);
                        }).then(function (dao) {
                            return dao.apagaTodos();
                        }).then(function () {
                            return 'neg apagadas com sucesso';
                        }).catch(function (erro) {
                            console.log(erro);
                            throw new Error('n foi possivel apagar as neg');
                        });
                    }
                }, {
                    key: 'importa',
                    value: function importa(listaAtual) {
                        return this.obterNegociacoes()
                        // to fazendo filter. filter eh como se fosse um foreach. ele vai varrer cada item de negociacao e vai jogar dentro do array de negociacoes
                        // em seguida, pergunta via some para listaNegociacoes, q vai varrer o array listaNegociacoes perguntando se tem alguma negociacao igual 
                        //atraves de JSON.stringfy(negociacao ) == JSOn.stringfy(negociacaoExistente)
                        //se a verificação do stringfy for verdadeiro, o some vai retornar verdadeiro
                        //se isso ocorrer, o filter vai retornar no array de negociacoes
                        //como estamos querendo q nao se importe negociacoes iguais, 
                        //temos q negar a verificação atraves de "!" no some
                        //JSON.stringfy transforma/serializa o objeto em string
                        //esse artificio ajuda a comparar valores de objetos p saberem se sao iguais
                        .then(function (negociacoes) {
                            return negociacoes.filter(function (negociacao) {
                                return !listaAtual.negociacoes.some(function (negociacaoExistente) {
                                    return negociacao.isEquals(negociacaoExistente);
                                });
                            });
                        }).catch(function (erro) {
                            console.log(erro);
                            throw new Error('n foi possivel buscar as neg');
                        });
                    }
                }]);

                return NegociacaoService;
            }();
        }
    };
});
//# sourceMappingURL=NegociacaoService.js.map