'use strict';

System.register([], function (_export, _context) {
    "use strict";

    var _createClass, HttpService;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    return {
        setters: [],
        execute: function () {
            _createClass = function () {
                function defineProperties(target, props) {
                    for (var i = 0; i < props.length; i++) {
                        var descriptor = props[i];
                        descriptor.enumerable = descriptor.enumerable || false;
                        descriptor.configurable = true;
                        if ("value" in descriptor) descriptor.writable = true;
                        Object.defineProperty(target, descriptor.key, descriptor);
                    }
                }

                return function (Constructor, protoProps, staticProps) {
                    if (protoProps) defineProperties(Constructor.prototype, protoProps);
                    if (staticProps) defineProperties(Constructor, staticProps);
                    return Constructor;
                };
            }();

            HttpService = function () {
                function HttpService() {
                    _classCallCheck(this, HttpService);
                }

                _createClass(HttpService, [{
                    key: 'get',
                    value: function get(url) {
                        //resolve eh uma funcao q tenho q passar para essa funcao o retorno de sucesso do meu obterNegociacao//
                        //  e para o reject o erro
                        return new Promise(function (resolve, reject) {
                            var xhr = new XMLHttpRequest();
                            xhr.open('GET', url);
                            //Uma requisição passa por estados, por isso o nome da propriedade em português é pronto para mudança de estado. Podemos passar uma função que verifica os estados e executará uma ação   
                            xhr.onreadystatechange = function () {
                                /*
                                status de uma requisição ajax
                                0 - req ainda n iniciada
                                1 - conexao com o servidor estabelecida
                                2 - req recebida
                                3 - processando req
                                4 - req concluida e a resposta estah pronta
                                */

                                if (xhr.readyState == 4) {
                                    if (xhr.status == 200) {
                                        console.log('obtendo as neg');
                                        console.log(xhr.responseText);
                                        console.log(JSON.parse(xhr.responseText));

                                        resolve(JSON.parse(xhr.responseText));
                                    } else {
                                        console.log(xhr.responseText);
                                        reject(xhr.responseText);
                                    }
                                }
                            };

                            xhr.send();
                        });
                    }
                }, {
                    key: 'post',
                    value: function post(url, dado) {

                        return new Promise(function (resolve, reject) {

                            var xhr = new XMLHttpRequest();
                            xhr.open("POST", url, true);
                            xhr.setRequestHeader("Content-type", "application/json");
                            xhr.onreadystatechange = function () {

                                if (xhr.readyState == 4) {

                                    if (xhr.status == 200) {

                                        resolve(JSON.parse(xhr.responseText));
                                    } else {

                                        reject(xhr.responseText);
                                    }
                                }
                            };
                            xhr.send(JSON.stringify(dado)); // usando JSON.stringifly para converter objeto em uma string no formato JSON.
                        });
                    }
                }]);

                return HttpService;
            }();
        }
    };
});
//# sourceMappingURL=HttpService-sem-fetch-api.js.map