'use strict';

System.register([], function (_export, _context) {
    "use strict";

    var _createClass, NegociacaoService;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    return {
        setters: [],
        execute: function () {
            _createClass = function () {
                function defineProperties(target, props) {
                    for (var i = 0; i < props.length; i++) {
                        var descriptor = props[i];
                        descriptor.enumerable = descriptor.enumerable || false;
                        descriptor.configurable = true;
                        if ("value" in descriptor) descriptor.writable = true;
                        Object.defineProperty(target, descriptor.key, descriptor);
                    }
                }

                return function (Constructor, protoProps, staticProps) {
                    if (protoProps) defineProperties(Constructor.prototype, protoProps);
                    if (staticProps) defineProperties(Constructor, staticProps);
                    return Constructor;
                };
            }();

            NegociacaoService = function () {
                function NegociacaoService() {
                    _classCallCheck(this, NegociacaoService);
                }

                _createClass(NegociacaoService, [{
                    key: 'obterNegociacoesDaSemana',
                    value: function obterNegociacoesDaSemana() {
                        //resolve eh uma funcao q tenho q passar para essa funcao o retorno de sucesso do meu obterNegociacao//
                        //  e para o reject o erro
                        return new Promise(function (resolve, reject) {

                            var xhr = new XMLHttpRequest();

                            xhr.open('GET', 'negociacoes/semana');
                            //Uma requisição passa por estados, por isso o nome da propriedade em português é pronto para mudança de estado. Podemos passar uma função que verifica os estados e executará uma ação
                            xhr.onreadystatechange = function () {
                                /*
                                status de uma requisição ajax
                                0 - req ainda n iniciada
                                1 - conexao com o servidor estabelecida
                                2 - req recebida
                                3 - processando req
                                4 - req concluida e a resposta estah pronta
                                */

                                if (xhr.readyState == 4) {
                                    if (xhr.status == 200) {
                                        console.log('obtendo as neg');
                                        console.log(xhr.responseText);
                                        console.log(JSON.parse(xhr.responseText));

                                        resolve(JSON.parse(xhr.responseText).map(function (objeto) {
                                            console.log('objeto: ', objeto.data);

                                            var neg = new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor);
                                            console.log('neg: ', neg);
                                            return neg;
                                        }));
                                    } else {

                                        console.log(xhr.responseText);
                                        reject('nao foi possivel obter as negociacoes do servidor da semana');
                                    }
                                }
                            };

                            xhr.send();
                        });
                    }
                }, {
                    key: 'obterNegociacoesDaSemanaAnterior',
                    value: function obterNegociacoesDaSemanaAnterior() {
                        return new Promise(function (resolve, reject) {
                            var xhr = new XMLHttpRequest();
                            xhr.open('GET', 'negociacoes/anterior');
                            xhr.onreadystatechange = function () {
                                if (xhr.readyState == 4) {
                                    if (xhr.status == 200) {

                                        resolve(JSON.parse(xhr.responseText).map(function (objeto) {
                                            return new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor);
                                        }));
                                    } else {
                                        console.log(xhr.responseText);
                                        reject('Não foi possível obter as negociações da semana anterior');
                                    }
                                }
                            };

                            xhr.send();
                        });
                    }
                }, {
                    key: 'obterNegociacoesDaSemanaRetrasada',
                    value: function obterNegociacoesDaSemanaRetrasada() {
                        return new Promise(function (resolve, reject) {
                            var xhr = new XMLHttpRequest();
                            xhr.open('GET', 'negociacoes/retrasada');
                            xhr.onreadystatechange = function () {
                                if (xhr.readyState == 4) {
                                    if (xhr.status == 200) {

                                        resolve(JSON.parse(xhr.responseText).map(function (objeto) {
                                            return new Negociacao(new Date(objeto.data), objeto.quantidade, objeto.valor);
                                        }));
                                    } else {
                                        console.log(xhr.responseText);
                                        reject('Não foi possível obter as negociações da semana retrasada');
                                    }
                                }
                            };

                            xhr.send();
                        });
                    }
                }]);

                return NegociacaoService;
            }();
        }
    };
});
//# sourceMappingURL=NegociacaoService-com-promise-mas-sem-estar-separado.js.map