"use strict";

System.register([], function (_export, _context) {
    "use strict";

    var _createClass, ListaNegociacoes;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    return {
        setters: [],
        execute: function () {
            _createClass = function () {
                function defineProperties(target, props) {
                    for (var i = 0; i < props.length; i++) {
                        var descriptor = props[i];
                        descriptor.enumerable = descriptor.enumerable || false;
                        descriptor.configurable = true;
                        if ("value" in descriptor) descriptor.writable = true;
                        Object.defineProperty(target, descriptor.key, descriptor);
                    }
                }

                return function (Constructor, protoProps, staticProps) {
                    if (protoProps) defineProperties(Constructor.prototype, protoProps);
                    if (staticProps) defineProperties(Constructor, staticProps);
                    return Constructor;
                };
            }();

            ListaNegociacoes = function () {
                function ListaNegociacoes(armadilha) {
                    _classCallCheck(this, ListaNegociacoes);

                    this._negociacoes = [];
                    //armadilha sao funcoes passadas pelo construtor da classe q serao executadas toda vez q chamarmos adicona e esvazia
                    //para atualizar a view
                    this._armadilha = armadilha;
                    // esse codigo abaixo funciona sem usar arrow function!
                    // com arrow function, como muda o esopo lexico de this, n precisamos desse codigo abaixo.
                    //mas nesse caso, tem q passar o contexto no construtor
                    //this._contexto = contexto;
                }

                _createClass(ListaNegociacoes, [{
                    key: "adiciona",
                    value: function adiciona(negociacao) {
                        this._negociacoes.push(negociacao);

                        this._armadilha(this);
                        // esse codigo abaixo funciona sem usar arrow function!
                        // com arrow function, como muda o esopo lexico de this, n precisamos desse codigo abaixo.
                        //primeiro parametro, - o metodo q quero executar
                        //segundo parametro - o contexto (this) q quero executar
                        //terceiro parametro - parametros, no caso, a propria lista = this
                        //Reflect.apply(this._armadilha, this._contexto, [this] );
                    }
                }, {
                    key: "esavazia",
                    value: function esavazia() {
                        this._negociacoes = [];
                        this._armadilha(this);
                        // esse codigo abaixo funciona sem usar arrow function!
                        // com arrow function, como muda o esopo lexico de this, n precisamos desse codigo abaixo.
                        //Reflect.apply(this._armadilha, this._contexto, [this] );
                    }
                }, {
                    key: "negociacoes",
                    get: function get() {
                        //esse eh um truque de programação defensiva = return [].concat(this._negociacoes);
                        //pois vai criar uma copia da lista e não vai mexer na original.
                        return [].concat(this._negociacoes);
                    }
                }]);

                return ListaNegociacoes;
            }();
        }
    };
});
//# sourceMappingURL=ListaNegociacoes-sem-padrao-proxy.js.map