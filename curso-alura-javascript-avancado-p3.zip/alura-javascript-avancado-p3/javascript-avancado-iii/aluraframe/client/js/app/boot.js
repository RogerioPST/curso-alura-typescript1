'use strict';

System.register(['./controllers/NegociacaoController', './polyfill/fetch'], function (_export, _context) {
  "use strict";

  var currentInstance, negociacaoController;
  return {
    setters: [function (_controllersNegociacaoController) {
      currentInstance = _controllersNegociacaoController.currentInstance;
    }, function (_polyfillFetch) {}],
    execute: function () {
      negociacaoController = currentInstance();


      document.querySelector('.form').onsubmit = negociacaoController.adiciona.bind(negociacaoController);

      //document.querySelector('[type=button]').onclick = negociacaoController.apaga.bind(negociacaoController);

      document.getElementById('apaga').onclick = negociacaoController.apaga.bind(negociacaoController);

      document.getElementById('impComPromise').onclick = negociacaoController.importaNegociacoesSemPromise.bind(negociacaoController);
      document.getElementById('impSemPromise').onclick = negociacaoController.importaNegociacoes.bind(negociacaoController);

      /*
      <button  class="btn btn-primary text-center" type="button" id="#impSemPromise">
      Importar Negociações sem Promise nesse próprio método
      </button>
      <button  class="btn btn-primary text-center" type="button" id="#impComPromise">
      Importar Negociações com Promise nesse próprio método
      </button>
      <button  class="btn btn-primary text-center" type="button" id="#apaga">
      Apagar
      </button>*/
    }
  };
});
//# sourceMappingURL=boot.js.map