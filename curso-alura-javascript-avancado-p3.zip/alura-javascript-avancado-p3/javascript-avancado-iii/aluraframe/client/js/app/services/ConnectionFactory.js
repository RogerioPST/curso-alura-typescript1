'use strict';

System.register([], function (_export, _context) {
    "use strict";

    var _createClass, stores, version, dbName, close, connection, ConnectionFactory;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    return {
        setters: [],
        execute: function () {
            _createClass = function () {
                function defineProperties(target, props) {
                    for (var i = 0; i < props.length; i++) {
                        var descriptor = props[i];
                        descriptor.enumerable = descriptor.enumerable || false;
                        descriptor.configurable = true;
                        if ("value" in descriptor) descriptor.writable = true;
                        Object.defineProperty(target, descriptor.key, descriptor);
                    }
                }

                return function (Constructor, protoProps, staticProps) {
                    if (protoProps) defineProperties(Constructor.prototype, protoProps);
                    if (staticProps) defineProperties(Constructor, staticProps);
                    return Constructor;
                };
            }();

            stores = ['negociacoes'];
            version = 4;
            dbName = 'aluraframe';
            close = null;
            connection = null;

            _export('ConnectionFactory', ConnectionFactory = function () {
                function ConnectionFactory() {
                    _classCallCheck(this, ConnectionFactory);

                    throw new Error('n eh possivel criar instancias de connection factory');
                }

                _createClass(ConnectionFactory, null, [{
                    key: 'getConnection',
                    value: function getConnection() {
                        return new Promise(function (resolve, reject) {
                            //segundo parametro = 4 - manter a mesma versao do arquivo aprendendo-a-usar-banco-indexedb.html
                            //se quisesse atualizar, incrementaria essa versao
                            var openRequest = window.indexedDB.open(dbName, version);

                            openRequest.onupgradeneeded = function (e) {
                                ConnectionFactory._createStores(e.target.result);
                            };

                            openRequest.onsuccess = function (e) {
                                //codigo para manter a mesma conexao e n criar uma nova sempre
                                if (!connection) {
                                    connection = e.target.result;
                                    //MONKEY PATCH - sobrescrever o metodo close de connection
                                    //a variavel close guardou o metodo connection.close() antes de ser sobreescrito
                                    //em connection.close, o this de close eh connection
                                    //por isso, precisa fazer o bind para connection, se n vai dar erro
                                    close = connection.close.bind(connection);
                                    //fim
                                    connection.close = function () {
                                        throw new Error('vc n pode fechar diretamente a conexao');
                                    };
                                    //fim
                                }
                                resolve(connection);
                                //fim
                            };

                            openRequest.onerror = function (e) {
                                console.log(e.target.error);

                                reject(e.target.error.name);
                            };
                        });
                    }
                }, {
                    key: 'closeConnection',
                    value: function closeConnection() {
                        if (connection) {
                            //a variavel close guardou o metodo connection.close() antes de ser sobreescrito, desde q seja feito o bind
                            // ou faça Reflect.apply(close, connection, []); // assim n precisa do bind la em cima
                            close();
                            connection = null;
                            console.log('fechando a conexao');
                        }
                    }
                }, {
                    key: '_createStores',
                    value: function _createStores(connection) {
                        stores.forEach(function (store) {
                            if (connection.objectStoreNames.contains(store)) {
                                connection.deleteObjectStore(store);
                            }

                            connection.createObjectStore(store, { autoIncrement: true });
                        });
                    }
                }]);

                return ConnectionFactory;
            }());

            _export('ConnectionFactory', ConnectionFactory);
        }
    };
});
//# sourceMappingURL=ConnectionFactory.js.map