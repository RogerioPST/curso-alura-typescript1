'use strict';

System.register([], function (_export, _context) {
    "use strict";

    return {
        setters: [],
        execute: function () {
            // aluraframe/client/js/app/polyfill/es6.js

            /*
            Criando um polyfill
            Um polyfill é um script que emula o comportamento de um recurso quando esse não é suportado para garantir que nosso código funcione sem termos que abdicar do que é mais novo.
            
            Crie o arquivo aluraframe/client/js/app/polyfill/es6.js. Nele, vamos adicionar no prototype de Array o método includes que usa por debaixo dos panos o já conhecido indexOf. Mas, Flávio, é assim que o includes oficial é implementado? Não faço ideia, o importante é que o resultado final seja o mesmo, e usar o indexOfpor debaixo dos panos resolve isso perfeitamente. Veja que o método só é adicionando se ele não existir:
            */

            if (!Array.prototype.includes) {

                // Se não existir, adiciona

                console.log('Polyfill para Array.includes aplicado.');

                Array.prototype.includes = function (elemento) {
                    return this.indexOf(elemento) != -1;
                };
            }

            /*
            Quando adicionamos métodos no prototype de uma classe ou função construtora, todas as instâncias dessa função construtora ou classe terão o método.
            
            Agora vamos importar esse script no head da nossa página. Isso é necessário porque ele deve alterar Array antes que ele seja usado pela nossa aplicação. Alterando aluraframe/client/index.html:
            */
        }
    };
});
//# sourceMappingURL=es6.js.map