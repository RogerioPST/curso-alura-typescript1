'use strict';

System.register([], function (_export, _context) {
    "use strict";

    var _typeof, _createClass, NegociacaoController;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    return {
        setters: [],
        execute: function () {
            _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
                return typeof obj;
            } : function (obj) {
                return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
            };

            _createClass = function () {
                function defineProperties(target, props) {
                    for (var i = 0; i < props.length; i++) {
                        var descriptor = props[i];
                        descriptor.enumerable = descriptor.enumerable || false;
                        descriptor.configurable = true;
                        if ("value" in descriptor) descriptor.writable = true;
                        Object.defineProperty(target, descriptor.key, descriptor);
                    }
                }

                return function (Constructor, protoProps, staticProps) {
                    if (protoProps) defineProperties(Constructor.prototype, protoProps);
                    if (staticProps) defineProperties(Constructor, staticProps);
                    return Constructor;
                };
            }();

            NegociacaoController = function () {
                function NegociacaoController() {
                    _classCallCheck(this, NegociacaoController);

                    //Se em JavaScript temos as Higher-Order Functions, podemos declarar a variável $ - como usado no jQuery - e dentro, jogaremos o document.querySelector
                    //let $ = document.querySelector;
                    //Não funcionou colocarmos o querySelector na variável $ para criarmos um alias. Por que não funcionou? O querySelector é uma função que pertence ao objeto document - chamaremos tal função de método. Internamente, o querySelector tem uma chamada para o this, que é o contexto pelo qual o método é chamado. Logo, o this é o document. No entanto, quando colocamos o querySelector dentro do $, ele passa a ser executado fora do contexto de document e isto não funciona. O que devemos fazer, então? Queremos tratar o querySelector como uma função separada. Nós queremos que ao colocarmos o querySelector para o $, ele mantenha a associação com o document. Para isto, usaremos o bind() :
                    console.log(document.querySelector); // eh uma funcao e n pertence a um objeto e soh isso ele perde a associacao com o document
                    var $ = document.querySelector.bind(document);

                    // se eu adicionar 300 negociacoes, ele soh vai ter buscado no DOM uma unica vez cada um desses elementos
                    // melhor performance
                    // diferente se eu usasse let inputData = $('#data'), por exemplo - pior performance        
                    this._inputData = $('#data');
                    this._inputQuantidade = $('#quantidade');
                    this._inputValor = $('#valor');

                    var self = this;

                    this._listaNegociacoes = new Proxy(new ListaNegociacoes(), {
                        get: function get(target, prop, receiver) {
                            //se a propriedade estah na lista abaixo (adiciona, esvazia) e eh uma função, pois poderia ter uma propriedade q n eh uma funcao
                            console.log('target[prop]: ' + target[prop]);
                            console.log('prop: ' + prop);
                            if (['adiciona', 'esvazia'].includes(prop) && _typeof(target[prop]) == (typeof Function === 'undefined' ? 'undefined' : _typeof(Function))) {
                                //se estou retornando uma function, significa q o metodo la do objeto, vou trocar ele por outro
                                //e esse meu metodo vai ter a minha armadilha, mas eu vou substituir eh no Proxy e n no obj real
                                //ja q o proxy n me permite botar uma armadilha p metodo, se eu cair aqui no metodo q quero interceptar, 
                                //vou substituir esse metodo no proxy por outro
                                //esse outro metodo vai receber os parametros q ele está recebendo em "lista.adiciona(new Negociacao(new Date(), 1, 100 ));"
                                //como estou recebendo 'adiciona' ou 'esvazia', vou te substituir no proxy reotrnando a nova funcao
                                //por isso o contexto do Reflect.apply eh target , pois eh o proprio proxy
                                //vai alterar o codigo no proxy do metodo adiciona e do esvazia
                                //
                                return function () {
                                    console.log('interceptando no if: ' + prop);

                                    // vai continuar a execução normal chamando o metodo e executando os parametros originais (arguments)
                                    Reflect.apply(target[prop], target, arguments);
                                    self._negociacoesView.update(target);
                                };
                            }

                            console.log('a prop ' + prop + ' foi interceptada no else');
                            //Veja que a instrução a seguir é muito importante: return Reflect.get(target, prop, receiver). É ela que efetivamente realiza a operação no objeto real.
                            return Reflect.get(target, prop, receiver);
                        }
                    });

                    // esse codigo abaixo funciona sem usar arrow function!
                    // com arrow function, como muda o esopo lexico de this, n precisamos desse codigo abaixo.
                    //this._listaNegociacoes = new ListaNegociacoes(this, function(model){
                    // qdo essa função eh executada no contexto de listaNegociacoes, a funcao tem contexto dinamico
                    //o this dentro de uma funcao para ser avaliado depende do contexto no qual ela foi executada
                    // e essa funcao qdo eh chamada, ela eh executada no contexto de listaNegociacoes
                    //entao, qdo passo this em this._armadilha(this) -> this = listaNegociacoes 
                    //mas qdo armadilha, ela eh executada, ela eh executada no contexto de listaNegociacoes
                    //entao, o this de (this._negociacoesView.update(model))  é a listaNegociacoes! ferrou!
                    //    console.log(this);
                    //o q precisamos eh fazer com q o this seja o de NegociacaoController
                    //     this._negociacoesView.update(model);    
                    //  });
                    //com arrow function
                    //this._listaNegociacoes = new ListaNegociacoes(model =>{
                    // console.log(this);
                    // this._negociacoesView.update(model);
                    //});


                    this._negociacoesView = new NegociacoesView($('#negociacoesView'));
                    this._negociacoesView.update(this._listaNegociacoes);

                    this._mensagem = new Mensagem();
                    this._mensagemView = new MensagemView($('#mensagemView'));
                    this._mensagemView.update(this._mensagem);
                }

                _createClass(NegociacaoController, [{
                    key: 'adiciona',
                    value: function adiciona(event) {
                        // previne o event de executar o comportamento padrao, q no caso do formulario eh submeter o form e permite q n seja recarregaa a pagina
                        event.preventDefault();

                        //O C é o controller, aquele que disponibiliza um modelo para a view.
                        //O controller é aquele que recebe as ações do usuário e que sabe interagir com o modelo. Como o modelo é independente da view, esta precisa ser renderizada para que reflita as alterações no modelo. Em suma, o controller é a ponte de ligação entre a view e o modelo.

                        //let helper = new DateHelper();


                        var negociacao = this._criaNegociacao();

                        console.log(negociacao);

                        console.log(DateHelper.dataParaTexto(negociacao.data));

                        this._listaNegociacoes.adiciona(negociacao);

                        this._listaNegociacoes.negociacoes.length = 0;

                        console.log(this._listaNegociacoes.negociacoes);

                        this._mensagem.texto = 'Negociação adicionada com sucesso';
                        this._mensagemView.update(this._mensagem);
                        this._limpaFormulario();
                    }
                }, {
                    key: '_criaNegociacao',
                    value: function _criaNegociacao() {
                        return new Negociacao(DateHelper.textoParaData(this._inputData.value), this._inputQuantidade.value, this._inputValor.value);
                    }
                }, {
                    key: '_limpaFormulario',
                    value: function _limpaFormulario() {
                        document.querySelector('form').reset();
                        this._inputData.focus();
                    }
                }, {
                    key: 'apaga',
                    value: function apaga() {
                        this._listaNegociacoes.esvazia();

                        this._mensagem.texto = 'Negociações apagadas com sucesso';
                        this._mensagemView.update(this._mensagem);
                    }
                }]);

                return NegociacaoController;
            }();
        }
    };
});
//# sourceMappingURL=NegociacaoController-com-proxy-sem-factory.js.map