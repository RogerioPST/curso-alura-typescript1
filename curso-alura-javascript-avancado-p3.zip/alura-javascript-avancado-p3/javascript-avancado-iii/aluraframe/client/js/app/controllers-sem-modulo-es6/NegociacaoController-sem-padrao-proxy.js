'use strict';

System.register([], function (_export, _context) {
        "use strict";

        var _createClass, NegociacaoController;

        function _classCallCheck(instance, Constructor) {
                if (!(instance instanceof Constructor)) {
                        throw new TypeError("Cannot call a class as a function");
                }
        }

        return {
                setters: [],
                execute: function () {
                        _createClass = function () {
                                function defineProperties(target, props) {
                                        for (var i = 0; i < props.length; i++) {
                                                var descriptor = props[i];
                                                descriptor.enumerable = descriptor.enumerable || false;
                                                descriptor.configurable = true;
                                                if ("value" in descriptor) descriptor.writable = true;
                                                Object.defineProperty(target, descriptor.key, descriptor);
                                        }
                                }

                                return function (Constructor, protoProps, staticProps) {
                                        if (protoProps) defineProperties(Constructor.prototype, protoProps);
                                        if (staticProps) defineProperties(Constructor, staticProps);
                                        return Constructor;
                                };
                        }();

                        NegociacaoController = function () {
                                function NegociacaoController() {
                                        var _this = this;

                                        _classCallCheck(this, NegociacaoController);

                                        //Se em JavaScript temos as Higher-Order Functions, podemos declarar a variável $ - como usado no jQuery - e dentro, jogaremos o document.querySelector
                                        //let $ = document.querySelector;
                                        //Não funcionou colocarmos o querySelector na variável $ para criarmos um alias. Por que não funcionou? O querySelector é uma função que pertence ao objeto document - chamaremos tal função de método. Internamente, o querySelector tem uma chamada para o this, que é o contexto pelo qual o método é chamado. Logo, o this é o document. No entanto, quando colocamos o querySelector dentro do $, ele passa a ser executado fora do contexto de document e isto não funciona. O que devemos fazer, então? Queremos tratar o querySelector como uma função separada. Nós queremos que ao colocarmos o querySelector para o $, ele mantenha a associação com o document. Para isto, usaremos o bind() :
                                        console.log(document.querySelector); // eh uma funcao e n pertence a um objeto e soh isso ele perde a associacao com o document
                                        var $ = document.querySelector.bind(document);

                                        // se eu adicionar 300 negociacoes, ele soh vai ter buscado no DOM uma unica vez cada um desses elementos
                                        // melhor performance
                                        // diferente se eu usasse let inputData = $('#data'), por exemplo - pior performance        
                                        this._inputData = $('#data');
                                        this._inputQuantidade = $('#quantidade');
                                        this._inputValor = $('#valor');

                                        // esse codigo abaixo funciona sem usar arrow function!
                                        // com arrow function, como muda o esopo lexico de this, n precisamos desse codigo abaixo.
                                        //this._listaNegociacoes = new ListaNegociacoes(this, function(model){
                                        // qdo essa função eh executada no contexto de listaNegociacoes, a funcao tem contexto dinamico
                                        //o this dentro de uma funcao para ser avaliado depende do contexto no qual ela foi executada
                                        // e essa funcao qdo eh chamada, ela eh executada no contexto de listaNegociacoes
                                        //entao, qdo passo this em this._armadilha(this) -> this = listaNegociacoes 
                                        //mas qdo armadilha, ela eh executada, ela eh executada no contexto de listaNegociacoes
                                        //entao, o this de (this._negociacoesView.update(model))  é a listaNegociacoes! ferrou!
                                        //    console.log(this);
                                        //o q precisamos eh fazer com q o this seja o de NegociacaoController
                                        //     this._negociacoesView.update(model);    
                                        //  });
                                        //com arrow function
                                        this._listaNegociacoes = new ListaNegociacoes(function (model) {
                                                console.log(_this);
                                                _this._negociacoesView.update(model);
                                        });
                                        this._negociacoesView = new NegociacoesView($('#negociacoesView'));
                                        this._negociacoesView.update(this._listaNegociacoes);

                                        this._mensagem = new Mensagem();
                                        this._mensagemView = new MensagemView($('#mensagemView'));
                                        this._mensagemView.update(this._mensagem);
                                }

                                _createClass(NegociacaoController, [{
                                        key: 'adiciona',
                                        value: function adiciona(event) {
                                                // previne o event de executar o comportamento padrao, q no caso do formulario eh submeter o form e permite q n seja recarregaa a pagina
                                                event.preventDefault();

                                                //O C é o controller, aquele que disponibiliza um modelo para a view.
                                                //O controller é aquele que recebe as ações do usuário e que sabe interagir com o modelo. Como o modelo é independente da view, esta precisa ser renderizada para que reflita as alterações no modelo. Em suma, o controller é a ponte de ligação entre a view e o modelo.

                                                //let helper = new DateHelper();


                                                var negociacao = this._criaNegociacao();

                                                console.log(negociacao);

                                                console.log(DateHelper.dataParaTexto(negociacao.data));

                                                this._listaNegociacoes.adiciona(negociacao);

                                                this._listaNegociacoes.negociacoes.length = 0;

                                                console.log(this._listaNegociacoes.negociacoes);

                                                this._mensagem.texto = 'Negociação adicionada com sucesso';
                                                this._mensagemView.update(this._mensagem);
                                                this._limpaFormulario();
                                        }
                                }, {
                                        key: '_criaNegociacao',
                                        value: function _criaNegociacao() {
                                                return new Negociacao(DateHelper.textoParaData(this._inputData.value), this._inputQuantidade.value, this._inputValor.value);
                                        }
                                }, {
                                        key: '_limpaFormulario',
                                        value: function _limpaFormulario() {
                                                document.querySelector('form').reset();
                                                this._inputData.focus();
                                        }
                                }, {
                                        key: 'apaga',
                                        value: function apaga() {
                                                this._listaNegociacoes.esavazia();

                                                this._mensagem.texto = 'Negociações apagadas com sucesso';
                                                this._mensagemView.update(this._mensagem);
                                        }
                                }]);

                                return NegociacaoController;
                        }();
                }
        };
});
//# sourceMappingURL=NegociacaoController-sem-padrao-proxy.js.map