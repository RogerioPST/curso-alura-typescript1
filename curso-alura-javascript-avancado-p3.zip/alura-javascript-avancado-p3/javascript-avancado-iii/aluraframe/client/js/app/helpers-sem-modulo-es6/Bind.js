"use strict";

System.register([], function (_export, _context) {
    "use strict";

    var Bind;

    function _classCallCheck(instance, Constructor) {
        if (!(instance instanceof Constructor)) {
            throw new TypeError("Cannot call a class as a function");
        }
    }

    return {
        setters: [],
        execute: function () {
            Bind =
            //...props = indica q props vai virar um array de qtos parametros vierem a partir da 
            //terceira posicao do parametro 3 - Rest operator
            //    com isso, posso passar 'adiciona', 'esvazia' no NegociacoesController
            // ou 'texto' no NegociacoesController
            function Bind(model, view) {
                _classCallCheck(this, Bind);

                for (var _len = arguments.length, props = Array(_len > 2 ? _len - 2 : 0), _key = 2; _key < _len; _key++) {
                    props[_key - 2] = arguments[_key];
                }

                var proxy = ProxyFactory.create(model, props, function (model) {
                    return view.update(model);
                });
                view.update(model);

                return proxy;
            };
        }
    };
});
//# sourceMappingURL=Bind.js.map