var n1 = new Negociacao(new Date(), 5, 700);        
        console.log(n1);        
        console.log(n1.data);        
        console.log(n1.quantidade);        
        console.log(n1.valor);        
        console.log(n1.volume);        
        //Apesar de não podermos atribuir novamente um novo objeto à referência que já temos, como negociacao._data = new Date(), nós podemos chamar os métodos do objeto data, que operam sobre seu estado interno, que não é congelado. E agora?
        //Podemos lançar mão da programação defensiva. Quando chamarem a propriedade getter data, retornaremos uma nova instância de Date com a mesma data da nossa negociação. Como é outra instância, qualquer modificação não impactará em nossa classe.
        //O mesmo cuidado precisamos tomar com o construtor da classe. Como data é um objeto e objetos são passados como referência em JavaScript, qualquer alteração feita fora da classe pode alterá-la. A ideia é aplicarmos a programação defensiva.
        //altera a data
        //qdo eu faço programacao defensiva, qdo eu faço n1.data, ele n vai retornar a data original do objeto
        //e n  vai alterar a data
        n1.data.setDate(11);
        console.log(n1.data);


        var idade = 18;
        var temCarteira = true;
        // ANTES DO USO DE LET
        //Uma maneira de evitar que o valor da variável vaze para fora do if é a seguinte:
        //(function() {
          //  if(idade >= 18 && temCarteira) {
            //    var msg = 'Pode dirigir';
              //  console.log(msg);
           // }
        //})();

        //alert(msg); // exibe undefined