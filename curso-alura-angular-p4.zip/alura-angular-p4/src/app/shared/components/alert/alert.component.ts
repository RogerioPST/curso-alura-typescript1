import { Component } from "@angular/core";
import { Input } from "@angular/core";
import { AlertService } from "./alert.service";
import { Alert, AlertType } from "./alert";

@Component({
    selector: 'ap-alert',
    templateUrl: './alert.component.html'
})
export class AlertComponent{
    @Input() timeout  = 3000;
    alerts : Alert[] = [];

    constructor(
        private alertService: AlertService
    ){
        this.alertService
            .getAlert()
            .subscribe(alert => {
                // se alguem emitir um alert c valor nulo, vou limpar o alerts
                if (!alert){
                    this.alerts =[];
                    return;
                }
                this.alerts.push(alert);
                setTimeout(() => this.removeAlert(alert), this.timeout);
            })
            
    }
    // crio um novo array
    //se isso retornar falso, significa q o alert n vai participar da lista q acabei de filtrar
    removeAlert(alertToRemove: Alert){
        this.alerts = this.alerts.filter(alert => alert != alertToRemove)
    }

    getAlertClass(alert: Alert){
        if (alert) return '';

        switch(alert.alertType){
            case AlertType.DANGER:
                return 'alert alert-danger';
            case AlertType.SUCCESS:
                return 'alert alert-success';
            case AlertType.INFO:
                return 'alert alert-info';
            case AlertType.WARNING:
                return 'alert alert-warning';
        }
    }
}