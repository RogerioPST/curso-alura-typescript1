import { Directive, ElementRef, Renderer } from "@angular/core";

import { Input } from "@angular/core";
import { UserService } from "../../../core/user/user.service";
import { OnInit } from "@angular/core";

@Directive({
    selector: '[showIfLogged]'
})
export class ShowIfLoggedDirective implements OnInit{

    currentDisplay : string ;
    
    
    constructor(
        private element: ElementRef<any>,
        private renderer : Renderer,
        private userService: UserService
        
        ){
            
        }
        
    ngOnInit(): void {

        //sempre q tem um objeto q tem q mudar o status dele a partir de um outro objeto q n tem nada a ver
        // com ele, coloca um observable q resolve.
        
        // tenho q fazer dessa forma abaixo, pq o menu faz parte do header e ele n eh renderizado qdo 
        //eu interajo c a aplicação, ele eh sempre exibido
        //para exibi-lo, tenho q recarregar a pagina

        // pegando o estilo atual do display e guardando numa string
        this.currentDisplay = getComputedStyle(this.element.nativeElement).display;
        //
        this.userService.getUser().subscribe(user => {
            // se fiz um login
            if(user){
                this.renderer.setElementStyle(this.element.nativeElement, 'display', this.currentDisplay);
            }
            // se fiz um logout, coloco o estilo como display = none
            else{
                this.currentDisplay = getComputedStyle(this.element.nativeElement).display;    
                this.renderer.setElementStyle(this.element.nativeElement, 'display', 'none');
            }
        });
        
        

             }

}