import { Injectable } from "@angular/core";
import { LoadingService } from "./loading.service";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpSentEvent, HttpHeaderResponse, HttpProgressEvent, HttpUserEvent, HttpResponse } from "@angular/common/http";
import { Observable } from "rxjs";
import { tap } from "rxjs/operators";

@Injectable({providedIn: 'root'})
export class LoadingInterceptor implements HttpInterceptor{

    constructor(private loadingService: LoadingService){
        
    }


    intercept(req: HttpRequest<any>, next: HttpHandler): 
    Observable<HttpSentEvent | 
    HttpHeaderResponse | 
    HttpProgressEvent | 
    HttpResponse<any> | 
    HttpUserEvent<any>> {
        // o next eh o cara q lida com a requisicao
        return next.handle(req)
        // tap me permite fazer um sideeffect; executar um codigo assim que os
        // dados entram e a minha subscrição sobre os dados
        .pipe(tap(event => {
            if (event instanceof HttpResponse){
                this.loadingService.stop();
            }
            else{
                this.loadingService.start();
            }
        }));
    }

}