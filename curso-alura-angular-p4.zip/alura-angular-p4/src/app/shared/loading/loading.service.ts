import { Injectable } from "@angular/core";
import { LoadingType } from "./loading.type";
import { Subject } from "rxjs";
import { startWith } from "rxjs/operators";

@Injectable({providedIn: 'root'})
export class LoadingService{
    // para um subject, eu posso mandar uma info para ele e em outro lugar, 
    //eu posso escutar essa informação enviada para ele
    //atraves do serviço, eu passo um next e o component no header vai ouvir para tomar uma ação
    loadingSubject = new Subject<LoadingType>();

    getLoading(){
        // quem obter o getloading, vai pegar esse subject, mas como observable, pq ele quer escutar.
        return this.loadingSubject.asObservable()
        // quero q o padrao seja STOPPED no observable, por isso uso o pipe.
        .pipe(startWith(LoadingType.STOPPED));
    }

    start(){
        this.loadingSubject.next(LoadingType.LOADING);
    }
    stop(){
        this.loadingSubject.next(LoadingType.STOPPED);
    }
}