import { Component, OnInit, ElementRef, ViewChild } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { AuthService } from "src/app/core/auth/auth.service";
import { Router, ActivatedRoute } from "@angular/router";
import { PlatformDetectorService } from "src/app/core/platform-detector/platform-detector.service";
import { Title } from "@angular/platform-browser";


@Component({
    templateUrl: './sign-in.component.html'
    
})
export class SignInComponent implements OnInit{

    fromUrl: string;
    loginForm : FormGroup;
    @ViewChild('userNameInput') userNameInput: ElementRef<HTMLInputElement>;

    constructor(
        private formBuilder : FormBuilder, 
        private authService: AuthService,
        private router: Router, 
        private platformDetectorService : PlatformDetectorService ,
        private activatedRoute: ActivatedRoute       
        ){
        
    }

    ngOnInit(): void{        
        //para pegar a rota q estava querendo ace
        this.activatedRoute
            .queryParams.subscribe(params =>{
            this.fromUrl = params.fromUrl
        });
        this.loginForm = this.formBuilder.group({
            userName : ['',Validators.required],
            password: ['',Validators.required]
        });       
        //vou testar se eh um browser. se n for, nem executo o codigo depois do &&,
        // mas se for, executo para dar focus()
        this.platformDetectorService.isPlatformBrowser() && this.userNameInput.nativeElement.focus();         
    }

    login(){
        console.log('vai se autenticar');
        const userName = this.loginForm.get('userName').value; 
        const password = this.loginForm.get('password').value;

        this.authService
            .authenticate(userName, password)
            .subscribe(
                () => {
                    console.log('autenticado');
                    // foi configurado no auth.guard.ts
                    if(this.fromUrl){
                        this.router.navigateByUrl(this.fromUrl);
                    }else{
                        this.router.navigate(['user',userName]);
                        //ou assim:
                        //this.router.navigateByUrl('user/' + userName)
                    }

            }, 
                err => { console.log(err);
                    //limpar p formulario
                    this.loginForm.reset();
                    //vou testar se eh um browser. se n for, nem executo o codigo depois do &&,
                    // mas se for, executo para dar focus()
                    this.platformDetectorService.isPlatformBrowser() && this.userNameInput.nativeElement.focus();
                }
            );                
    }

}