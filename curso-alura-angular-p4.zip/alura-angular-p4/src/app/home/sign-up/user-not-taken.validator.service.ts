import { Injectable } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { debounceTime, switchMap, map, first} from 'rxjs/operators';

import { SignUpService } from "./sign-up.service";


// como o validador n suporta injecao de dependencia, vai tem que ser um serviço tb.
// unica instancia para  a aplicacao inteira! = providedin: 'root', mas como n precisa ser assim, 
// pois n eh todo lugar q precisa, vou colocar no sign-up.component.ts o seguinte:
// "providers: [UserNotTakenValidatorService]
@Injectable()
export class UserNotTakenValidatorService{
    constructor(private signUpService: SignUpService){

    }

    //o segredo eh esse metodo que me retorna uma funcao de validacao, que vai ter acesso ao serviço 
    // e por ai vai.
    // validador assincrono. retorna um observable (valueChanges)
    //return control.valueChanges // desse jeito, n teria validacao nenhuma
    // switchMap -> para de escutar o fluxo anterior e troca (switch) para esse novo fluxo
    // n quero ouvir mais nada
    //pipe(map -> parecido com o lowerCase criado por nos)
    // se deixar assim, n vai funcionar, pois o sist assincrono precisa que esse codigo abaixo fique completo
    // isso eh feito com o operador first()
    // tudo de import { debounceTime, switchMap, map, first} from 'rxjs/operators';
    checkUserNameTaken(){
        return (control: AbstractControl) => {
            return control
                .valueChanges
                .pipe(debounceTime(300))
                .pipe(switchMap(userName => {
                    return this.signUpService.checkUserNameTaken(userName);
                }))
                .pipe(map(isTaken => isTaken ? {userNameTaken: true} : null))
                .pipe(first());
        }
    }
}