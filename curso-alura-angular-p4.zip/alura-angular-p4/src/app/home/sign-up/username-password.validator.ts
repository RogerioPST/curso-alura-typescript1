import { ValidatorFn, FormGroup } from "@angular/forms";

export const userNamePassword: ValidatorFn = (formGroup: FormGroup) =>{
    
    const userName = formGroup.get('userName').value;
    const password = formGroup.get('password').value;

    //se tem alguma coisa digitada
    //Testamos se o nome do usuário é diferente da senha, mas apenas se algum dos campos forem diferente de branco. Caso sejam iguais, haverá um erro de validação.
    if (userName.trim() + password.trim()){
        // se n der erro, retorno nulo
        return userName != password ? null : {userNamePassword: true};
    } else{
        return null;   
    }
}