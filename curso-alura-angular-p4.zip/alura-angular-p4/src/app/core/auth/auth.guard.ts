import { Injectable } from "@angular/core";
import { UserService } from "../user/user.service";
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from "@angular/router";
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
})
export class AuthGuard implements CanActivate{
    
    constructor( private userService: UserService, private router: Router){

    }
    // classe que protege rotas
    // O guarda de rotas serve para darmos consistência para nossa aplicação, liberando acesso apenas para as rotas que fazem sentido para nosso usuário.
    canActivate(
        route: ActivatedRouteSnapshot, 
        state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
            console.log('ativou guarda de rota de verif de autenticacao de upload');
            if (!this.userService.isLogged()){
                // se vc nao esta logado, vai p tela de login, mas com o endereço q eu estava tentando acessar como queryParam
                this.router.navigate(
                    [''],
                    {
                        queryParams: {
                            fromUrl: state.url
                        }
                    }
                    );

                return false;
            }
            return true;
    }


}