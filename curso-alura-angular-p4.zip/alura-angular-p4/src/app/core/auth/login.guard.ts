import { Injectable } from "@angular/core";
import { UserService } from "../user/user.service";
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from "@angular/router";
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
})
export class LoginGuard implements CanActivate{
    
    constructor( private userService: UserService, private router: Router){

    }
    // classe que protege rotas
    // O guarda de rotas serve para darmos consistência para nossa aplicação, liberando acesso apenas para as rotas que fazem sentido para nosso usuário.
    canActivate(
        route: ActivatedRouteSnapshot, 
        state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
            console.log('ativou guarda de rota');
            if (this.userService.isLogged()){
                // se vc esta logado e esta tentando acessar a rota para logar, 
                // vou redirecionar para a rota do usuario p exibir as fotos = timeline
                this.router.navigate(['user', this.userService.getUserName() ]);

                return false;
            }
            return true;
    }


}