import { Component } from "@angular/core";

@Component({
    templateUrl: './global-error.component.html'
})
export class GlobalErrorComponent{

}