export interface ServerLog{
    message: string;
    url: string;
    userName: string;
    stack: string;
}