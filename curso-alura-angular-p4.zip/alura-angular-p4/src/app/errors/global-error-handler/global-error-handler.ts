import { ErrorHandler, Injectable, Injector } from "@angular/core";
import * as StackTrace from 'stacktrace-js';
import { LocationStrategy, PathLocationStrategy } from "@angular/common";
import { UserService } from "../../core/user/user.service";
import { ServerLogService } from "./server-log.service";
import { Router } from "@angular/router";
import { environment} from '../../../environments/environment'

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

    constructor(private injector: Injector ){

    }

    // classe criada por mim para sobrescrever o handler error padrao
    // n vou fazer nada, so vou lancar o erro
    handleError(error: any): void {
        // estou trocando a injecao de dependencia do construtor por aqui
        //Vimos que não é interessante injetarmos artefatos no constructor do nosso Global Errorhandler, 
        //pois o angular primeiro criará instâncias dessas dependências para depois injetá-las e, se algum 
        //erro acontecer durante a injeção nosso ErrorHandler não será capaz de tratá-lo. Nesse sentido, o 
        //ideal é injetar os artefatos no método.
        const location = this.injector.get(LocationStrategy);
        // para capturar a rota onde deu o erro
        const url = location instanceof PathLocationStrategy ? location.path() : '';

        // estou trocando a injecao de dependencia do construtor por aqui
        const userService = this.injector.get(UserService);        
        const serverLogService = this.injector.get(ServerLogService);
        const router = this.injector.get(Router);

        const message = error.message ? error.message : error.toString();

        // soh redireciono se for producao
        if (environment.production){
            router.navigate(['/error']);
        }
            

        StackTrace
            .fromError(error)
            .then(stackFrames =>{
                console.log(stackFrames);
                const stackAsString = stackFrames
                    .map(sf => sf.toString())
                    .join('\n');
                    console.log(message);
                    console.log(stackAsString);
                    console.log(url);
                    // aqui eu envio para o servidor de log o log
                    serverLogService.log({
                        message, 
                        url, 
                        userName: userService.getUserName(), 
                        stack: stackAsString}
                    ).subscribe(
                        () =>{                            console.log('error logged on server');}, 
                        err =>{
                            console.log(err);
                            console.log('fail to send error to server');
                        });



                    console.log('\no q serah enviado p o servidor', 
                        {message, url, userName: userService.getUserName(), stack: stackAsString});


            })
        console.log('passei pelo handler criado por mim');

        //throw error;
    }
}