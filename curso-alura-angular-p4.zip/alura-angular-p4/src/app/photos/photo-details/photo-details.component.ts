import { Component, OnInit } from "@angular/core";
import { ActivatedRoute,Router } from "@angular/router";
import { PhotoService } from "../photo/photo.service";
import { Photo } from "../photo/photo";
import { Observable } from "rxjs";
import { PhotoComment } from "../photo/photo-comment";
import { AlertService } from "../../shared/components/alert/alert.service";
import { UserService } from "../../core/user/user.service";

@Component({
    templateUrl: 'photo-details.component.html'
    
})
export class PhotoDetailsComponent implements OnInit{
    photo$: Observable<Photo>;
    photoId : number;

    // ActivatedRoute - posso pegar o parametro passado da rota
    constructor(
        private route: ActivatedRoute,
        private photoService : PhotoService,
        private router : Router,
        private alertService: AlertService,
        private userService: UserService
    ){
        
    }
    ngOnInit(): void {
        // o mesmo nome da rota "photoId' "
        //{ path: 'p/:photoId', component: PhotoDetailsComponent },
        this.photoId = this.route.snapshot.params.photoId;
        console.log(this.photoId);
        this.photo$ = this.photoService.findById(this.photoId);     
        // esse trecho eh usado p qdo eu remove uma foto e tento acessar o endereço dela, msm apos remove-la.
        // antes, n dava erro.
        this.photo$.subscribe(() => {}, err=>{
            console.log(err);
            this.router.navigate(['not-found']);
        })   
    }

    remove(){
        this.photoService
            .removePhoto(this.photoId)
            .subscribe(() => {
                this.alertService.danger('Photo removedd', true);
                // ele vai detonar a rota q estava la no seu history e vai ficar a q vc está indo
                // eh usada qdo removemos uma foto e tentamos voltar no navegador para essa rota da foto
                //navegação troque no history API a rota anterior pela rota que estamos acessando, evitando assim voltar para a rota anterior:
                this.router.navigate(['/user',this.userService.getUserName()], {replaceUrl: true});

            },
            err => {
                console.log(err);
                this.alertService.warning('could not delete', true);
            });
        
    }

    like(photo: Photo){
        this.photoService
            .like(photo.id)
            .subscribe(liked => {
                if(liked){
                    this.photo$ = this.photoService.findById(photo.id);
                }
            });
    }
  

}