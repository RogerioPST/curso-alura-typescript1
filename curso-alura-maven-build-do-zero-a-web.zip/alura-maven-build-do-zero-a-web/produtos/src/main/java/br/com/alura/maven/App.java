package br.com.alura.maven;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		new Produto("Bala Juquinha sabor tangerina", 0.15);
		System.out.println("Hello World!");
	}
}
