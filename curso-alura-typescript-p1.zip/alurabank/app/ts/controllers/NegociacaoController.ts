class NegociacaoController{
    private _inputData: JQuery;
    private _inputQuantidade: JQuery;
    private _inputValor : JQuery;
    //private _negociacoes : Negociacoes = new Negociacoes();
    //posso instanciar o objeto de array de negociacoes ou do jeito acima
    // ou abaixo
    private _negociacoes = new Negociacoes();
    private _negociacoesView = new NegociacoesView('#negociacoesView');
    private _mensagemView = new MensagemView('#mensagemView');
    

    constructor(){
        //let tabela = <HTMLTableElement> document.querySelector('table'); 
        //Correto! Realizamos o casting explícito de Element para HTMLTableElement. Inclusive, devido ao 
        //casting, o TypeScript infere que o tipo de tabela será HTMLTableElement.
        this._inputData = $('#data');
        this._inputQuantidade = $('#quantidade');
        this._inputValor = $('#valor');  
        this._negociacoesView.update(this._negociacoes);      
        
    }

    adiciona(event: Event){
        // usar isso p qdo chamar o evento de submit do formulario, n recarregar a pagina!!!!
        event.preventDefault();
        const negociacao = new Negociacao(
            // regex , q troca tudo que tem '-' por ','.
            new Date(this._inputData.val().replace(/-/g, '/')), 
            parseInt(this._inputQuantidade.val()), 
            parseFloat(this._inputValor.val())
        );

        this._negociacoes.adiciona(negociacao);
        
/*
        this._negociacoes.paraArray().length = 0;

        this._negociacoes.paraArray().forEach(negociacao =>{
            console.log(negociacao.data);
            console.log(negociacao.quantidade);
            console.log(negociacao.valor);
        })
        */
       this._negociacoesView.update(this._negociacoes);
       this._mensagemView.update('Negociacao added com mmt sucesso');
    }
}