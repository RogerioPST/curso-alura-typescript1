const controller = new NegociacaoController();

// o bind (controller) é codigo ecmascript (javascript avancado).
//em outros cursos, inclusive no avancado. a gente sabe q isso n vai funcionar, pois se eu copiar o 
//controller.adiciona e pegar uma referencia do adiciona e passar p o this do adiciona n vai mais apontar 
//p a instancia de negociacao. entao, eu tenho que fazer aqui adiciona.bind(controller) para manter a 
//associacao do this do adiciona com o meu controller
$('.form').submit(controller.adiciona.bind(controller));
    
