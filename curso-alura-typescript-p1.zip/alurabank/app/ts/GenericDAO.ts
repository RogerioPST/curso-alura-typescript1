
/*class GenericDAO {

    adiciona(objeto: Negociacao): number {

      
    }

    apaga(objeto: Negociacao): void {

       
    }

    buscaPorId(id: number): Negociacao {

      
    }

    atualiza(objeto: Negociacao): void {

       
    }

    listaTodos(): Negociacao[] {

         
    }
}

// exemplo de uso
let dao = new GenericDao();
let negociacao = new Negociacao(new Date(), 1, 200);
// recebe o ID da negociação gerada
let id = dao.adiciona(negociacao);
let negociacaoBuscada = dao.buscaPorId(id);

O código escrito por Fernando não é genérico, pois esta amarrado ao tipo Negociacao. Além disso, o ID do elemento no IndexedDB pode ser um número ou uma string, e esse tipo esta fixo na definição da classe.

Marque a opção que torna a classe realmente genérica, permitindo persistir outros tipos, inclusive a definir um outro tipo de ID.

class GenericDAO<T, K> {

    adiciona(objeto: T): K {

        
    }

    apaga(objeto: T): void {

        
    }

    buscaPorId(id: K): T {

       
    }

    atualiza(objeto: T): void {

       
    }

    listaTodos(): T[] {

       
    }
}
 
Correto! Pode indicar mais de um tipo genérico. No caso T, será o tipo da classe e K, o tipo do ID.
*/