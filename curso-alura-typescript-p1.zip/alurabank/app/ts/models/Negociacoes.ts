// essa classe vai encapsular o array q vai guardar todas as negociacoes q eu gravar.

class Negociacoes{
    //private _negociacoes : Array<Negociacao> = [];
    //declaro um array ou do jeito acima ou abaixo
    private _negociacoes: Negociacao[] =[];

    adiciona(negociacao : Negociacao) : void{
        this._negociacoes.push(negociacao);
    }

    paraArray(): Negociacao[]{
        // para impedir a mutabilidade, vou retornar um novo array, q eh uma copia
        return [].concat(this._negociacoes);
    }
}