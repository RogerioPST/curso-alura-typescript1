// Usamos o tipo generico <T>, pois assim, podemos colocar o metodo update e template na classe pai (View)
// se o T fosse uma string, onde está T entraria string; Se fosse o tipo negociacoes, onde está o T entraria 
// negociacoes

//se negociacoesView herdar de view , posso passar uma negociacao.
// se mensagemView herdar de view, posso passar string etc., se eu usar generics

/*
ref a class abstrata
class Boleto {

    geraLinhaDigitavel(): string {


    }

    geraCabecalho(): string {

        throw new Error('Você precisa implementar a cabeçalho');
    }
}

class BoletoBancoA extends Boleto {

    geraCabecalho(): string {


    }

}

class BoletoBancoB extends Boleto {

    geraCabecalho(): string {


    }

}
Não faz sentido haver instâncias de Boleto, pois a classe não define a implementação de geraCabecalho(). Essa responsabilidade é das classes filhas, mas nada obriga o desenvolvedor a implementá-las em tempo de desenvolvimento e só será avisado caso tenha esquecido de implementá-lo em tempo de execução, no runtime da aplicação.

Eduardo poderia ter transformado a classe Boleto uma classe abstrata, tornando geraCabecalho() abstrato. Além de não permitir que instâncias de Boleto sejam criadas em tempo de compilação (desenvolvimento), obrigará todas as filhas a implementarem geraCabecalho(). Enquanto não for implementado, as classes filhas não compilarão.
*/
//O _ é uma variável que vive no escopo global. O compilador TypeScript não sabe disso e a considera como 
//não declarada, por isso o erro de compilação. Faz sentido, porque a ideia do TypeScript é nos blindar 
//de possíveis erros em nosso código e utilizar variáveis que não foram declaradas é uma deles.
//vou calar o compilador p n dar erro no $ do jquery
//declare var &: any; // ultimo recursoo!!!
//com a opção abaixo, n preciso da parte acima.
// usar o npm install @types/jquery@2.0.42 --save-dev
// para poder usar jquery dentro do typescript
/*
Para saber mais: o repositório @types
No npm, existe uma série de TypeScript definitons files para as mais diversas bibliotecas e frameworks do mercado. Por exemplo, se quisermos instalar o tsd do jQuery, acessamos

https://www.npmjs.com/package/@types/jquery

Se quisermos do lodash ou underscore acessamos

https://www.npmjs.com/package/@types/lodash
.

https://www.npmjs.com/package/@types/underscore
Dessa forma, antes de sair buscando pela internet os arquivos tsd que precisamos, podemos tentar a sorte executando o comando:

npm install @types/nomeDaLibOuFramework --save-dev
Nesse sentido, se quisermos instalar os tsd das três bibliotecas que foram citadas, fazemos:

npm install @types/jquery --save-dev
npm install @types/loadash --save-dev
npm install @types/underscore --save-dev
Qualquer tsd files que esteja dentro de node_modules/@types será lidado automaticamente pelo compilador do TypeScript.

É preciso se conformar quando não houver do Typing para sua biblioteca preferida, neste caso, a estratégia do declare var que vimos neste treinamento é uma saída, não muito ideal, mas que permitirá seu código compilar até que você encontre seu tsd.
*/

abstract class View<T>{
    private _elemento : JQuery;

    constructor(seletor: string){

    //this._elemento = document.querySelector(seletor);        
    //msm codigo usando jquery por conta de alguns navegadores antigos e de antigos androids n atualizados
        this._elemento = $(seletor);        
    }

    update(model : T) : void{

    //this._elemento.innerHTML = this.template(model);
    //
    //msm codigo usando jquery por conta de alguns navegadores antigos e de antigos androids n atualizados
    this._elemento.html(this.template(model));

    }

    abstract template ( model : T) : string;    
}