package br.com.casadocodigo.loja.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

//a anotação faz com q o spring saiba q esse eh o controller.
@Controller
public class HomeController {

	//mapeamento de url
	@RequestMapping("/")
	public String index() {
		System.out.println("Entrando na home no casa de código");
		return "home";
	}
}
