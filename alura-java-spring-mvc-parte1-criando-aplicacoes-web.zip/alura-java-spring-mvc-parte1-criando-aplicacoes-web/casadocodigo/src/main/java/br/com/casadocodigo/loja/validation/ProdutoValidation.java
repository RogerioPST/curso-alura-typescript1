package br.com.casadocodigo.loja.validation;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import br.com.casadocodigo.loja.models.Produto;

public class ProdutoValidation implements Validator {
	
	public void valida(Produto produto, Errors errors) {
		
	
	//if (produto.getTitulo() == null || produto.getTitulo().isEmpty()) {
	//	return false;
	//}
	//return true;
	}

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		//O método supports também precisa ser implementado. A implementação desse método indica a qual classe a validação dará suporte. Sabemos que será a classe Produto. Vamos então fazer essa implementação da seguinte forma:
		//O que esse código faz é verificar se o objeto recebido para a validação tem uma assinatura da classe Produto. Com isso o Spring pode verificar se o objeto é uma instância daquela classe ou não.
		return Produto.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		ValidationUtils.rejectIfEmpty(errors, "titulo", "field.required");
		ValidationUtils.rejectIfEmpty(errors, "descricao", "field.required");
		
		Produto produto = (Produto) target;
		if (produto.getPaginas() <= 0) {
			errors.rejectValue("paginas", "field.required");
		}
		
	}

}
