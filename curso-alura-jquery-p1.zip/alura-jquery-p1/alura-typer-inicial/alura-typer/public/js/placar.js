function inserePlacar(){
    //placar eh a section, mas como quero a table, posso usar a funcao find, do jquery, q vai descer os nós-filhos do html e achar a table a partir do section c classe placar
    //var tabela = $('.placar').find('table');
    //console.log(tabela);
    var corpoTabela = $('.placar').find('tbody');
    console.log(corpoTabela);
    var ususario = 'Roger';
    var numPalavras = $('#contador-palavras').text();
    //var botaoRemover = '<a href="#">    <i class="small material-icons">delete</i></a>';

    //var linha = '<tr>' +                  '<td>' + ususario + '</td>' +                 '<td>' + numPalavras + '</td>' +                  '<td>' + botaoRemover + '</td>' +                  '</tr>';

    var linha = novaLinha(ususario, numPalavras);

    //criar um obj dentro do jquery, dentro do javascript.
    //como eh um elem html, consigo buscar o botao e add um EVENTO de click num elem q ainda n foi criado
    //e c isso, ela ja pode ser removida assim q for colocada no placar
    linha.find('.botao-remover').click(removeLinha);

    //funcao do jquery p acrescentar um item no final;
    //corpoTabela.append(linha);
    //funcao do jquery p acrescentar um item no inicio;
    corpoTabela.prepend(linha);

}

function novaLinha(usuario, palavras){
    //criando um elemento html com jquery
    var linha = $('<tr>');
    var colunaUsuario = $('<td>').text(usuario);
    var colunaPalavras = $('<td>').text(palavras);
    var colunaRemover = $('<td>');
    var link = $('<a>').addClass('botao-remover').attr('href', '#');

    var icone = $('<i>').addClass('small').addClass('material-icons').text('delete');

    link.append(icone);


    colunaRemover.append(link);
    linha.append(colunaUsuario);
    linha.append(colunaPalavras);
    linha.append(colunaRemover);

    return linha;
}


function removeLinha(){
    event.preventDefault();
    //por padrao, o href='#', vai para o topo da pagina
    //se eu quiser q de o focus num elemento c id 'teste', eh soh fazer href='#teste' no a.
    console.log(this);
    //para dar poderes a um elemento do html, tenho q envolve-lo com o $ do jquery
    //para remover a propria lixeira
    //$(this).remove();
    $(this).parent().parent().remove();

}
