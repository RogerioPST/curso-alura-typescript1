package br.com.casadocodigojavaee.models;

import java.math.BigDecimal;

public class Pagamento {
	
	private BigDecimal value;

	public Pagamento(BigDecimal value) {
		this.value = value;
		// TODO Auto-generated constructor stub
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}
	
	

}
