package br.com.casadocodigojavaee.beans;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.Part;
import javax.transaction.Transactional;

import br.com.casadocodigojavaee.daos.AutorDAO;
import br.com.casadocodigojavaee.daos.LivroDao;
import br.com.casadocodigojavaee.infra.FileSaver;
import br.com.casadocodigojavaee.models.Autor;
import br.com.casadocodigojavaee.models.Livro;

@Named
@RequestScoped
public class AdminLivrosBean {
	

	private Livro livro = new Livro();

	@Inject
	private LivroDao dao;
	@Inject
	private AutorDAO autorDAO;

	private List<Integer> autoresId = new ArrayList<>();
	
	@Inject
	private FacesContext context;		
	
	private Part capaLivro;
	

	@Transactional
	public String salvar() throws IOException {
//		for (Integer autorId : getAutoresId()) {
//			livro.getAutores().add(new Autor(autorId));
//
//		}
		dao.salvar(livro);
		FileSaver fileSaver = new FileSaver();
		String relativePath = fileSaver.write(capaLivro, "livros");
		livro.setCapaPath(relativePath);
		
		
		System.out.println("Livro cadastrado: " + livro);
		
		context.getExternalContext().getFlash().setKeepMessages(true); // escopo de flash q dura dois requests e grava no session do
																									// usuario
		context.addMessage(null, new FacesMessage("Livro cadastrado com sucesso"));
		// para limpar o formulario
		// limpaFormulario();
		// return "/livros/lista"; // esse redirect vai ser feito soh no servidor. isso
		// vai cadastrar dado no banco sem querer. vai submeter de novo POST
		return "/livros/lista?faces-redirect=true"; // esse redirect vai ser feito pelo navegador p evitar cadastrar
													// dado no banco sem querer
	}

	

//	private void limpaFormulario() {
//		this.livro = new Livro();
//		this.autoresId = new ArrayList<>();
//	}

	public List<Autor> getAutores() {
		return autorDAO.listar();
		// return Arrays.asList(new Autor(1, "Paulo Silveira"), new Autor(2, "Sergio
		// Lopes"));

	}

	public Livro getLivro() {
		return livro;
	}

	public void setLivro(Livro livro) {
		this.livro = livro;
	}

	public Part getCapaLivro() {
		return capaLivro;
	}

	public void setCapaLivro(Part capaLivro) {
		this.capaLivro = capaLivro;
	}

//	public List<Integer> getAutoresId() {
//		return autoresId;
//	}
//
//	public void setAutoresId(List<Integer> autoresId) {
//		this.autoresId = autoresId;
//	}
}