package br.com.casadocodigojavaee.conf;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/services")
public class JaxRSConfiguration extends Application{

}
