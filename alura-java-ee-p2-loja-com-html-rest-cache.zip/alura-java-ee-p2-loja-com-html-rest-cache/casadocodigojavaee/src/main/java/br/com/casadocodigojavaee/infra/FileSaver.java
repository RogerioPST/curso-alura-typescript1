package br.com.casadocodigojavaee.infra;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.file.Path;

import javax.servlet.http.Part;

public class FileSaver {
	
	public static final String SERVER_PATH = "C:\\Users\\Rogerio\\eclipse-workspace-jee-2019\\casadocodigojavaee";
	
	public String write(Part arquivo, String path) {
		
		String relativePath = path + "/" + arquivo.getSubmittedFileName();
		try {
			arquivo.write(SERVER_PATH + "/" + relativePath);
			return relativePath;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
	}

	//qdo estamos fazendo transferencia, primeiro temos q fazer o input do arquivo para depois fazer a saida
	//por isso o inputstream inicial
	public static void transfer(Path source, OutputStream outputStream) {
		 try {
			FileInputStream input = new FileInputStream(source.toFile());
			try( ReadableByteChannel inputChannel = Channels.newChannel(input); 
					WritableByteChannel outputChannel = Channels.newChannel(outputStream);){ // abre um canal de entrada especifico
				//agora precisamos fazer o buffer de saida
				ByteBuffer buffer = ByteBuffer.allocateDirect(1024*10); //taxa de transferencia
				
				while(inputChannel.read(buffer) != -1) {
					//-1 significa q encerrou, ja leu tudo
					buffer.flip(); //vai setar os bytes para 0 de novo
					outputChannel.write(buffer);
					buffer.clear(); //limpamos o buffer p q na prox operacao ele possa rodar sem nenhuma info, nenhuma sujeira
				}
				
				
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				throw new RuntimeException(e);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}
		
	}

}
