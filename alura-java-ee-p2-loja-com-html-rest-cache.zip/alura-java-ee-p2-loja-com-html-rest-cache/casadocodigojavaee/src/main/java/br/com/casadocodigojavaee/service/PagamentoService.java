package br.com.casadocodigojavaee.service;

import java.net.URI;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.inject.Inject;
import javax.servlet.ServletContext;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import br.com.casadocodigojavaee.daos.CompraDao;
import br.com.casadocodigojavaee.models.Compra;

@Path("/pagamento")
public class PagamentoService {
	
	@Context
	private ServletContext context;
	
	@Inject
	CompraDao compraDao;
	
	@Inject
	PagamentoGateway pagamentoGateway;
	
	//cria um pool de threads auto gerenciaveis // p trabalhar de forma assincrona
	private static ExecutorService executor = Executors.newFixedThreadPool(50);
	
	
	//@Suspended final AsyncResponse ar - a chamada do metodo vai ser feito de forma assincrona
	@POST
	public void pagar(@Suspended final AsyncResponse ar, @QueryParam("uuid") String uuid) {
		Compra compra = compraDao.buscaPorUuid(uuid);
		
		String contextPath = context.getContextPath();
		
		executor.submit(() ->{
			try {
			pagamentoGateway.pagar(compra.getTotal());
			System.out.println("uuid: "+ uuid);
			
			URI responseURI = UriBuilder.fromPath("http://localhost:8081" + 
					contextPath + "/index.xhtml").queryParam("msg", "compra realizada com sucesso")
					.build();
			
			Response response = Response.seeOther(responseURI).build();	
			//depois q a req eh feita de maneira assincrona, chamamos o resume
			//qdo chama o resume, ele notifica o servidor q pode continuar, 
			//qdo entrou nesse metodo, informou q podia liberar a thread principal
			ar.resume(response);									
			 

			} catch(Exception e) {
				ar.resume(new WebApplicationException(e));
			}
		});		
	}
	
	

}
