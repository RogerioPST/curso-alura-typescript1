package br.com.casadocodigojavaee.service;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;

import br.com.casadocodigojavaee.models.Pagamento;

public class PagamentoGateway implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String pagar(BigDecimal total) {
		//realizando a requisicao para o serviço de pagamento
		//criando o client para isso.
		Client client = ClientBuilder.newClient();
		Pagamento pagamento = new Pagamento(total);		
		String target = "http://book-payment.herokuapp.com/payment";		
		Entity<Pagamento> json = Entity.json(pagamento);
		WebTarget webTarget = client.target(target);		
		Builder request = webTarget.request();		
		String response = request.post(json, String.class);
		
		return response;
	}

}
