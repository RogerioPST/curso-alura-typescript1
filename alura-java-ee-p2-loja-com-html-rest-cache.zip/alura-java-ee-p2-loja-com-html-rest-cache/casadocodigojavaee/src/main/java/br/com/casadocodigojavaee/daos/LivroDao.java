package br.com.casadocodigojavaee.daos;

import java.util.List;

import javax.ejb.Stateful;
import javax.persistence.Cache;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.hibernate.SessionFactory;
import org.hibernate.annotations.QueryHints;

import br.com.casadocodigojavaee.models.Livro;

//uam forma eh manter REquestScoped no Bean , stateful com EXTENDED no DAO
@Stateful  //p manter o manager aberto p n dar erro de LazyException; junto  @PersistenceContext(type=PersistenceContextType.EXTENDED) no manager
public class LivroDao {

    @PersistenceContext(type=PersistenceContextType.EXTENDED) //p manter o manager aberto p n dar erro de LazyException
    private EntityManager manager;
    
    public void salvar(Livro livro) {
        manager.persist(livro);
    }
    
    public void limpaCache() {
    	Cache cache = manager.getEntityManagerFactory().getCache();
    	cache.evict(Livro.class, 1L ); //vai limpar o cache soh do livro de id =1 
		cache.evict(Livro.class);//vai limpar o cache de todos os livros
		cache.evictAll();//vai limpar o cache de todas as entidades
		
		SessionFactory factory = manager.getEntityManagerFactory().unwrap(SessionFactory.class);
		factory.getCache().evictAllRegions();
		factory.getCache().evictQueryRegion("home"); //das outras telas vai continuar cacheada; apenas vai evitar cachear a home q foi criada com o sethint abaixo
		
		
    }

	public List<Livro> listar() {
		// TODO Auto-generated method stub
		//como eu posso ter mais de um autor para cada livro, faz distinct para trazer apenas uma vez aquele livro
		String jpql = "select distinct(l) from Livro l join fetch l.autores";
		
		return manager.createQuery(jpql, Livro.class).getResultList();
	}

	public List<Livro> ultimosLancamentos() {
		// TODO Auto-generated method stub			
	
		
		String jpql = "select l from Livro l order by l.dataPublicacao desc";
		return manager.createQuery(jpql, Livro.class)
				.setMaxResults(5)
				.setHint(QueryHints.CACHEABLE, true)
				.setHint(QueryHints.CACHE_REGION, "home") //das outras telas vai continuar cacheada; apenas vai evitar cachear a home q foi criada com o sethint abaixo
				.getResultList();
		
	}

	public List<Livro> demaisLivros() {
		// TODO Auto-generated method stub
		String jpql = "select l from Livro l order by l.dataPublicacao desc";
		return manager.createQuery(jpql, Livro.class)
				.setFirstResult(5)
				.setHint(QueryHints.CACHEABLE, true)
				.setHint(QueryHints.CACHE_REGION, "home")
				.getResultList();
	}

	public Livro buscaPorId(Integer id) {
		return manager.find(Livro.class, id);
//		String jpql = "select l from Livro l join fetch l.autores where l.id = :id ";
//		return manager.createQuery(jpql, Livro.class).setParameter("id", id).getSingleResult();
	}
}