package br.com.casadocodigojavaee.servlet;

import java.io.IOException;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.casadocodigojavaee.infra.FileSaver;

@WebServlet("/file/*")
public class FileServlet extends HttpServlet{
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String relativePath = req.getRequestURI().split("/file")[1]; // /file eh obrigatorio p chegar no nosso servlet
		
		Path source = Paths.get(FileSaver.SERVER_PATH + "/" + relativePath); // aqui busca o arquivo onde salvei (olha o metodo write do FileSaver)
		FileNameMap fileNameMap = URLConnection.getFileNameMap(); //vai retornar varios nomes de arquivo q a gente consegue
		String type = fileNameMap.getContentTypeFor("file:"+source); //vamos querer o tipo de arquivo do nosso source.  o protocolo eh file p buscar no nosso S.O.
		
		resp.reset(); //com JSF, precisa usar esse reset()..
		resp.setContentType(type); //um type mais generico. pode vim pdf, png, qualquer coisa. estamos tratando acima.
		resp.setHeader("Content-Length", String.valueOf(Files.size(source)));
		resp.setHeader("Content-Disposition", "filename=\""+source.getFileName().toString() + "\""); //esse header e o filename eh p o navegador poder baixar o arquivo	
		FileSaver.transfer(source, resp.getOutputStream());
		
	}

}
