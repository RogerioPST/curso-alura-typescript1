package br.com.casadocodigojavaee.beans;

import java.util.List;

import javax.enterprise.inject.Model;
import javax.inject.Inject;

import br.com.casadocodigojavaee.daos.LivroDao;
import br.com.casadocodigojavaee.models.CarrinhoCompras;
import br.com.casadocodigojavaee.models.CarrinhoItem;
import br.com.casadocodigojavaee.models.Livro;

@Model
public class CarrinhoComprasBean {
	
	@Inject
	private LivroDao livroDAO;
	
	@Inject
	private CarrinhoCompras carrinho;
	
	public String add(Integer id) {
		Livro livro = livroDAO.buscaPorId(id);
		CarrinhoItem item = new CarrinhoItem(livro);
		carrinho.add(item);
		
		return "carrinho?faces-redirect=true";
		
	}
	
	public void remover(CarrinhoItem item) {
		carrinho.remover(item);
	}
	
	public List<CarrinhoItem> getItens(){
		return carrinho.getItens();
	}
	

}
