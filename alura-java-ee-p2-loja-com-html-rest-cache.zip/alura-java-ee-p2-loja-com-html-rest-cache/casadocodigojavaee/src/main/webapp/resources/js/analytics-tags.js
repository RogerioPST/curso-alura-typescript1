_urq.push(['_resourcesLoaded', 'TrackingPixels', (function() {
	var urls = [];

	urls.push('https://cdw-dcl.userreport.com/gs/init/pixel.gif');
	urls.push(location.protocol + '//server.adformdsp.net/serving/cookie/match/?party=1001&cid={RespondentId}&Today={Date}');

	return urls;
})()]);
