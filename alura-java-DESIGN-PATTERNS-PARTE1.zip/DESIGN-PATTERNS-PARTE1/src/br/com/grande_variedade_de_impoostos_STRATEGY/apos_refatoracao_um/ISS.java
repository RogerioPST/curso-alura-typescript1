package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

import br.com.grande_variedade_de_impoostos_STRATEGY.antes.Orcamento;

public class ISS implements Imposto{
	public double calcula(Orcamento orcamento) {
		return orcamento.getValor() * 0.06;
	}

}