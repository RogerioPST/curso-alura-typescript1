package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

public class CONSERVADOR implements Investimento {

	@Override
	public double calculaInvestimento(double valorDaAplicacao) {
		// TODO Auto-generated method stub
		return valorDaAplicacao * 0.008;
	}

}
