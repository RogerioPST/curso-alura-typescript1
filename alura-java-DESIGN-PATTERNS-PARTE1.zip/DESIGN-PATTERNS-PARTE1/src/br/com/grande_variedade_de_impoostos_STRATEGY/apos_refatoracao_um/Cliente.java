package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

public class Cliente {
	
	private double saldoConta;

	public Cliente(double saldoConta) {
		this.saldoConta = saldoConta;
		// TODO Auto-generated constructor stub
	}

	public double getSaldoConta() {
		return saldoConta;
	}
	
	public void deposita(double valor) {
		this.saldoConta += valor;
	}
	
	

}
