package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

import java.util.Random;

public class TesteDeInvestimentos {
	
	public static void main(String[] args) {
		
		Cliente cliente = new Cliente(1000);
		
		RealizadorDeInvestimentos realizador = new RealizadorDeInvestimentos();
		
		CONSERVADOR conservador = new CONSERVADOR();
		
		double retorno = realizador.realizaInvestimento(cliente, conservador);
		cliente.deposita(retorno*0.75);
		
		System.out.println("saldo da conta: " + cliente.getSaldoConta());
		
		for (int i = 0; i < 100; i++) {
			System.out.println(new Random().nextInt(2));
		}
		
		
		
		
	}

}
