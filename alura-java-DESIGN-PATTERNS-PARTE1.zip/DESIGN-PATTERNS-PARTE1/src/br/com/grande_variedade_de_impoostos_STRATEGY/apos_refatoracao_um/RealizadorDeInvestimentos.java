package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

public class RealizadorDeInvestimentos {
	
	public double realizaInvestimento(Cliente cliente, Investimento investimentoQualquer) {
		double retorno = investimentoQualquer.calculaInvestimento(cliente.getSaldoConta());
		System.out.println(retorno);
		return retorno;
		
	}

}
