package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

public interface Investimento {
	
	public double calculaInvestimento(double valorDaAplicacao);

}
