package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

import br.com.grande_variedade_de_impoostos_STRATEGY.antes.Orcamento;

//Repare que a cria��o de uma nova estrat�gia de c�lculo de imposto n�o implica em mudan�as no c�digo escrito acima! Basta criarmos uma nova classe que implementa a interface Imposto, que nosso CalculadorDeImpostos conseguir� calcul�-lo sem precisar de nenhuma altera��o!
public class CalculadorDeImpostos {
	//Quando utilizamos uma hierarquia, como fizemos com a interface Imposto e as implementa��es ICMS e ISS, e recebemos o tipo mais gen�rico como par�metro, para ganharmos o polimorfismo na regra que ser� executada, simplificando o c�digo e sua evolu��o, estamos usando o Design Pattern chamado Strategy.
	public void realizaCalculo(Orcamento orcamento, Imposto impostoQualquer) {		
		System.out.println(impostoQualquer.calcula(orcamento));
	}	
}
