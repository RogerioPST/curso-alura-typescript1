package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

import br.com.grande_variedade_de_impoostos_STRATEGY.antes.Orcamento;

/*
 * a nossa classe cliente passa uma estrategia de calculo de imposto para o calculador. este recebe uma estrategia qualquer e executa
 * para calcular o imposto.
 */
public class TesteDeImpostos {
	public static void main(String[] args) {
		Imposto icms = new ICMS();
		Imposto iss = new ISS();
		Imposto iccc = new ICCC();
		
		Orcamento orcamento = new Orcamento(500.0);
		
		CalculadorDeImpostos calculador  = new CalculadorDeImpostos();
		//Agora, com um �nico m�todo em nosso CalculadorDeImpostos, podemos realizar o c�lculo de diferentes tipos de impostos, apenas recebendo a estrat�gia do tipo do imposto que desejamos utilizar no c�lculo.
		
		calculador.realizaCalculo(orcamento, iss);
		calculador.realizaCalculo(orcamento, icms);
		calculador.realizaCalculo(orcamento, iccc);
		
	}

}
