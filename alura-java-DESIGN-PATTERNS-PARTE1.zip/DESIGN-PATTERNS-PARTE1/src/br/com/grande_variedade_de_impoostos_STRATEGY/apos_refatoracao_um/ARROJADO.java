package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

import java.util.Random;

public class ARROJADO implements Investimento {

	private Random random;

    public ARROJADO() {
      this.random = new Random();
    }

    @Override
	public double calculaInvestimento(double valorDaAplicacao) {
      int chute = random.nextInt(10);
      if(chute >= 0 && chute <= 1) return valorDaAplicacao * 0.05;
      else if (chute >= 2 && chute <= 4) return valorDaAplicacao * 0.03;
      else return valorDaAplicacao * 0.006;
    }		

}
