package br.com.grande_variedade_de_impoostos_STRATEGY.apos_refatoracao_um;

import java.util.Random;

public class MODERADO implements Investimento{

	private Random random;

    public MODERADO() {
      this.random = new Random();
    }

    @Override
    public double calculaInvestimento(double saldo) {
      if(random.nextInt(2) == 0) return saldo * 0.025;
      else return saldo * 0.007;
    }
  }