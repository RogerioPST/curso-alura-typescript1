package br.com.grande_variedade_de_impoostos_STRATEGY.antes;

public class Orcamento {
	
	private double valor;

	public Orcamento(double valor) {
		this.valor = valor;
		// TODO Auto-generated constructor stub
	}
	
	public double getValor() {
		return valor;
	}

}
