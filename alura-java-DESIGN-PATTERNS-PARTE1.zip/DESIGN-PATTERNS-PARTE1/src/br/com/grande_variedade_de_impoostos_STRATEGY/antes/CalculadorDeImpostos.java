package br.com.grande_variedade_de_impoostos_STRATEGY.antes;

/*
 * quando varias classes possuem uma coisa em comum, podemos definir um contrato entre elas.
 * 
 * 
 * a nossa classe cliente, q possui o metodo main,  passa uma estrategia de calculo de imposto para o calculador. este recebe uma estrategia qualquer e executa
 * para calcular o imposto.
 */
public class CalculadorDeImpostos {
	
	public void realizaCalculo(Orcamento orcamento, String imposto) {
		 if(imposto.equals("ICMS")){			 
			 double icms = orcamento.getValor() * 0.1;
		 }else if(imposto.equals("ISS")){			 
			 double iss = orcamento.getValor() * 0.06;
		 } 
		
	}

}
