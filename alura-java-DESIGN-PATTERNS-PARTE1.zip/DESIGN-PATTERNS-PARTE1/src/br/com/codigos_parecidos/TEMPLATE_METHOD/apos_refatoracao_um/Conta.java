package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

public class Conta {

	private String agencia;
	private String numero;
	private int saldo;

	public Conta(String agencia, String numero, int saldo) {
		this.agencia = agencia;
		this.numero = numero;
		this.saldo = saldo;
		// TODO Auto-generated constructor stub
	}

	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public int getSaldo() {
		return saldo;
	}

	public void setSaldo(int saldo) {
		this.saldo = saldo;
	}
	
	

}
