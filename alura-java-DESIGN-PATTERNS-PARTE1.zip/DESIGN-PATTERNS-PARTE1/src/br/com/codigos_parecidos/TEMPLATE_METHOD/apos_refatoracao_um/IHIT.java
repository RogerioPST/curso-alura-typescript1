package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

import java.util.ArrayList;
import java.util.List;

import br.com.codigos_parecidos.TEMPLATE_METHOD.antes.Item;
import br.com.codigos_parecidos.TEMPLATE_METHOD.antes.Orcamento;

public class IHIT extends TemplateDeImpostoCondicional{

	@Override
	public double minimaTaxacao(Orcamento orcamento) {
		// TODO Auto-generated method stub
		return orcamento.getValor() *( 0.01* orcamento.getItens().size());
	}

	@Override
	public double maximaTaxacao(Orcamento orcamento) {
		// TODO Auto-generated method stub
		System.out.println("entrei");
		return orcamento.getValor()*0.13+ 100;
	}

	@Override
	public boolean deveUsarMaximaTaxacao(Orcamento orcamento) {
		// TODO Auto-generated method stub
		return contemDoisItensDeMesmoNome(orcamento);
	}

	private boolean contemDoisItensDeMesmoNome(Orcamento orcamento) {
		// TODO Auto-generated method stub
		
		List<String> noOrcamento = new ArrayList<String>();

        for(Item item : orcamento.getItens()) {
          if(noOrcamento.contains(item.getNome())) return true;
          else noOrcamento.add(item.getNome());
        }

        return false;
	}

}
