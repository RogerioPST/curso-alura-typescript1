package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

import java.util.Date;

public class RelatorioComplexo extends TemplateDeRelatorio{

	@Override
	protected void montaBody(Cliente cliente) {
		// TODO Auto-generated method stub
		for (Conta conta : cliente.getContas()) {
			System.out.println(conta.getAgencia() +" , "+ conta.getNumero());
			System.out.println(cliente.getTitular() + " - R$ " + conta.getSaldo());			
			
		}
		
	}

	@Override
	protected void montaRodape(Cliente cliente) {
		// TODO Auto-generated method stub
		System.out.println(cliente.getEmail());
		System.out.println(new Date());
		
	}

	@Override
	protected void montaCabecalho(Cliente cliente) {
		// TODO Auto-generated method stub
		System.out.println("Relatorio Complexo");
		System.out.println(cliente.getBanco());
		System.out.println(cliente.getEndereco());
		System.out.println(cliente.getTelefone());
		
	}

}
