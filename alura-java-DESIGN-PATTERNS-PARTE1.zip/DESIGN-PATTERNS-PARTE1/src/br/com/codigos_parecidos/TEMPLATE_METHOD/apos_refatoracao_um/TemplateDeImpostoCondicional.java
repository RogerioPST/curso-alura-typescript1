package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

import br.com.codigos_parecidos.TEMPLATE_METHOD.antes.Imposto;
import br.com.codigos_parecidos.TEMPLATE_METHOD.antes.Orcamento;
/*
 * Ambos os impostos ICPP e IKCV decidem se vao aplicar a taxa maxima ou a minima. COmo sao parecidos, podemos criar um molde desse
 * algoritmo.
 * 
 * o Molde/template n tem q ter implementacao. ele eh apenas um exemplo de como tem q ser o algoritmo. para resolver isso, vamos
 * colocar os metodos como abstratos, deixa-los publicos, pq antes eram private. temos q remover o body dos metodos. e deixa a classe
 * abstrata.
 * 
 * Agora os impostos IKCV e ICPP vao ser filhos dessa classe e implementar esses metodos com os algoritmos de verdade. 
 * 
 * esse eh o Template mEthod
 */
public abstract class TemplateDeImpostoCondicional implements Imposto{

	@Override
	public final double calcula(Orcamento orcamento) {
		if(deveUsarMaximaTaxacao(orcamento)) {
			
			return maximaTaxacao(orcamento);
		} else {
			
			return minimaTaxacao(orcamento);
		}
	}

	public abstract double minimaTaxacao(Orcamento orcamento);

	public abstract double maximaTaxacao(Orcamento orcamento);

	public abstract boolean deveUsarMaximaTaxacao(Orcamento orcamento);
	

}
