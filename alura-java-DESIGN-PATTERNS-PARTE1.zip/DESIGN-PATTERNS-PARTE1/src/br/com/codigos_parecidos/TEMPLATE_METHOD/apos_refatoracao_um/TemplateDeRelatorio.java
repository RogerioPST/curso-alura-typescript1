package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

public abstract class TemplateDeRelatorio implements MontagemDeRelatorio{

	@Override
	public final void monta(Cliente cliente) {
		montaCabecalho(cliente);
		montaBody(cliente);
		montaRodape(cliente);		
	}

	protected abstract void montaBody(Cliente cliente);

	protected abstract void montaRodape(Cliente cliente);

	protected abstract void montaCabecalho(Cliente cliente);

}
