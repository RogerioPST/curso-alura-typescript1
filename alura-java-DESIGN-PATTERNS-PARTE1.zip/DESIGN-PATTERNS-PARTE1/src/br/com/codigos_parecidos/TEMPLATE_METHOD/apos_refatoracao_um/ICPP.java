package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

import br.com.codigos_parecidos.TEMPLATE_METHOD.antes.Orcamento;

public class ICPP extends TemplateDeImpostoCondicional
{

	@Override
	public double minimaTaxacao(Orcamento orcamento) {
		// TODO Auto-generated method stub
		return orcamento.getValor()*0.05;
	}

	@Override
	public double maximaTaxacao(Orcamento orcamento) {
		// TODO Auto-generated method stub
		return orcamento.getValor()*0.07;
	}

	@Override
	public boolean deveUsarMaximaTaxacao(Orcamento orcamento) {
		// TODO Auto-generated method stub
		return orcamento.getValor()>500;
	}

}
