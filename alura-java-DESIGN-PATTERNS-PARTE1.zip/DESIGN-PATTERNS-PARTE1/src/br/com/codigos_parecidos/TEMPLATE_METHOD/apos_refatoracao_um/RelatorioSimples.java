package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

public class RelatorioSimples extends TemplateDeRelatorio {

	@Override
	protected void montaBody(Cliente cliente) {
		// TODO Auto-generated method stub
		for (Conta conta : cliente.getContas()) {
			System.out.println(cliente.getTitular() + " - R$ " + conta.getSaldo());			
			
		}
		
		
	}

	@Override
	protected void montaRodape(Cliente cliente) {
		// TODO Auto-generated method stub
		System.out.println(cliente.getTelefone());
		
	}

	@Override
	protected void montaCabecalho(Cliente cliente) {
		
		// TODO Auto-generated method stub
		System.out.println("relatorio simples");
		System.out.println(cliente.getTitular());
	}

}
