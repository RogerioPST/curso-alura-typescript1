package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

public interface MontagemDeRelatorio {
	
	public void monta(Cliente cliente);

}
