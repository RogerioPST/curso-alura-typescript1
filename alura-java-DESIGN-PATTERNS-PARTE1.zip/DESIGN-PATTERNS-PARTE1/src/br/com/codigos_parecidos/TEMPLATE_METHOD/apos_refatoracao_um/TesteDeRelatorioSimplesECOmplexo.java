package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

import java.util.ArrayList;
import java.util.List;

public class TesteDeRelatorioSimplesECOmplexo {
	public static void main(String[] args) {
		
		Conta conta1 = new Conta("1234", "123456", 500);
		Conta conta2 = new Conta("1234", "123456", 500);
		
		List<Conta> contas = new ArrayList<>();
		
		contas.add(conta1);
		contas.add(conta2);
		
		Cliente cliente = new Cliente("Rogerio", "CEF", "tel 5272-8182", "Rua X", "teste@teste.com", contas );
		
		RelatorioSimples simples = new RelatorioSimples();
		//simples.monta(cliente);
		
		RelatorioComplexo complexo = new RelatorioComplexo();
		complexo.monta(cliente);
	}

}
