package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

import java.util.List;

public class Cliente {

	private String titular;
	private String banco;
	private String telefone;
	private String endereco;
	private String email;
	private List<Conta> contas;

	public Cliente(String titular, String banco, String telefone, String endereco, String email, List<Conta> contas) {
		this.titular = titular;
		this.banco = banco;
		this.telefone = telefone;
		this.endereco = endereco;
		this.email = email;
		this.contas = contas;
		// TODO Auto-generated constructor stub
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Conta> getContas() {
		return contas;
	}

	public void setContas(List<Conta> contas) {
		this.contas = contas;
	}
	
	

}
