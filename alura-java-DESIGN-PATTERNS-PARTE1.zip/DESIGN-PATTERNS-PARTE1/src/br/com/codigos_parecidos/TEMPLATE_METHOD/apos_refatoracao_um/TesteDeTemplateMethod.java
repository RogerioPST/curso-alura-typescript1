package br.com.codigos_parecidos.TEMPLATE_METHOD.apos_refatoracao_um;

import br.com.codigos_parecidos.TEMPLATE_METHOD.antes.Item;
import br.com.codigos_parecidos.TEMPLATE_METHOD.antes.Orcamento;

public class TesteDeTemplateMethod {
	public static void main(String[] args) {
		Orcamento orcamento = new Orcamento(600);
		
		orcamento.adicionaItem(new Item("Caneta", 250.0));
		orcamento.adicionaItem(new Item("Caneta", 250.0));
		
		IKCV ikcv = new IKCV();
		ICPP icpp = new ICPP();
		IHIT ihit = new IHIT();
		
		System.out.println(icpp.calcula(orcamento));
		
		System.out.println(ikcv.calcula(orcamento));
		System.out.println(ihit.calcula(orcamento));
	}

}
