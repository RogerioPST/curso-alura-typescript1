package br.com.codigos_parecidos.TEMPLATE_METHOD.antes;



public interface Imposto {
	public double calcula(Orcamento orcamento);

}
