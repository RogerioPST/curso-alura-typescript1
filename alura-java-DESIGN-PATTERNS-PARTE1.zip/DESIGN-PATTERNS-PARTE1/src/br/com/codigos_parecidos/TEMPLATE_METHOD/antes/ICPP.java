package br.com.codigos_parecidos.TEMPLATE_METHOD.antes;

/*
 * Ambos os impostos ICPP e IKCV decidem se vao aplicar a taxa maxima ou a minima. COmo sao parecidos, podemos criar um molde desse
 * algoritmo.
 */

public class ICPP implements Imposto{

	@Override
	public double calcula(Orcamento orcamento) {
		if(orcamento.getValor() > 500) {
			return orcamento.getValor() * 0.07;
		} else {
			return orcamento.getValor() * 0.05;
		}
			
	}

}
