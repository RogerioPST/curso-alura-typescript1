package br.com.comportamentos_compostos_por_outros.DECORATOR.apos_refatoracao_um;

import br.com.comportamentos_compostos_por_outros.DECORATOR.antes.Orcamento;

public class ISS extends Imposto {

	public ISS(Imposto outroImposto) {
		// TODO Auto-generated constructor stub
		super(outroImposto);
	}

	public ISS() {
		// TODO Auto-generated constructor stub
		super();
	}

	@Override
	public double calcula(Orcamento orcamento) {
		// TODO Auto-generated method stub
		return orcamento.getValor() * 0.06 + calculoDoOutroImposto(orcamento);
	}

	

}
