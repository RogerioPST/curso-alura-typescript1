package br.com.comportamentos_compostos_por_outros.DECORATOR.apos_refatoracao_um;

import java.util.ArrayList;
import java.util.List;

abstract class Filtro {
	
	private Filtro outroFiltro;
	public Filtro(Filtro outroFiltro) {
		this.outroFiltro = outroFiltro;
	}
	public Filtro() {
		// TODO Auto-generated constructor stub
	}
    public abstract List<Conta> filtra(List<Conta> contas);
    
    protected List<Conta> proximo(List<Conta> contas) {
        if(outroFiltro != null) return outroFiltro.filtra(contas);
        else return new ArrayList<Conta>();
      }
}
