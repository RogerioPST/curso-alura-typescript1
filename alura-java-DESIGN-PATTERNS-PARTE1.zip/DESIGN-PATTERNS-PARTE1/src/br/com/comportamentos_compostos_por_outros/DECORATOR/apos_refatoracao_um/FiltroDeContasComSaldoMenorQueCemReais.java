package br.com.comportamentos_compostos_por_outros.DECORATOR.apos_refatoracao_um;

import java.util.ArrayList;
import java.util.List;

public class FiltroDeContasComSaldoMenorQueCemReais extends Filtro {

	public FiltroDeContasComSaldoMenorQueCemReais(Filtro outroFiltro) {
		// TODO Auto-generated constructor stub
		super(outroFiltro);
	}

	public FiltroDeContasComSaldoMenorQueCemReais() {
		// TODO Auto-generated constructor stub
		super();
	}

	@Override
	public List<Conta> filtra(List<Conta> contas) {
		// TODO Auto-generated method stub
		List<Conta> novaLista = new ArrayList<Conta>();
		for (Conta conta : contas) {
			if (conta.getSaldo() < 100) {
				novaLista.add(conta);
			}

		}

		novaLista.addAll(proximo(contas));
		
		return novaLista;

	}

}
