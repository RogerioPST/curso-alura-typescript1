package br.com.comportamentos_compostos_por_outros.DECORATOR.apos_refatoracao_um;

import br.com.comportamentos_compostos_por_outros.DECORATOR.antes.Orcamento;

public abstract class Imposto {
	
	protected Imposto outroImposto;
	
	public Imposto(Imposto outroImposto) {
		
		this.outroImposto = outroImposto;
	}
	
	public Imposto() {
		// TODO Auto-generated constructor stub
	}
	
	public abstract double calcula(Orcamento orcamento);
	
	protected double calculoDoOutroImposto(Orcamento orcamento) {
		// TODO Auto-generated method stub
		if(outroImposto == null) return 0;
		return outroImposto.calcula(orcamento);
	}

}
