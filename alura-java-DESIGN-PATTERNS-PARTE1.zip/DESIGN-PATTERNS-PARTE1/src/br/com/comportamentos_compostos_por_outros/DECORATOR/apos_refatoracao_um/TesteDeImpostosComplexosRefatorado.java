package br.com.comportamentos_compostos_por_outros.DECORATOR.apos_refatoracao_um;

import br.com.comportamentos_compostos_por_outros.DECORATOR.antes.Orcamento;

public class TesteDeImpostosComplexosRefatorado {
	
		public static void main(String[] args) {
			Imposto iss = new ICMS(new ICMS(new ISS(new ImpostoMuitoAlto(new IKCV()))));	
			
			Imposto ikcvcom = new IKCV(new ICMS());
			
			Orcamento orcamento = new Orcamento(500);
			
			double valor = iss.calcula(orcamento);
			
			System.out.println(valor);
		}

	}
