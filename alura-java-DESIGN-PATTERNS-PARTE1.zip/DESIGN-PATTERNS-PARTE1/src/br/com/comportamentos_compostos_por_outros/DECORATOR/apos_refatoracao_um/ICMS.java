package br.com.comportamentos_compostos_por_outros.DECORATOR.apos_refatoracao_um;

import br.com.comportamentos_compostos_por_outros.DECORATOR.antes.Orcamento;

public class ICMS extends Imposto {

	public ICMS(Imposto outroImposto) {
		// TODO Auto-generated constructor stub
		super(outroImposto);
	}

	public ICMS() {
		// TODO Auto-generated constructor stub
		super();
	}

	@Override
	public double calcula(Orcamento orcamento) {
		// TODO Auto-generated method stub
		return orcamento.getValor() * 0.1 + calculoDoOutroImposto(orcamento);
	}

}
