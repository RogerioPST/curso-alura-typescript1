package br.com.comportamentos_compostos_por_outros.DECORATOR.antes;

/*
 * posso ter impostos compostos
 * Imposto iss = new Iss();
 * Imposto issComICMS = new ISSComICMS();
 * Imposto issComICMSComICPP = new ISSComICMSComICPP();
 * 
 * precisamos achar uma forma de compor esse comportamento? a maneira OO eh passando pelo construtor de forma opcional.
 * tod imposto pode ser composto ou nao por outro impoosto. agora a interface Imposto vai virar uma classe abstrata.
 */


public class TesteDeImpostosComplexos {
	public static void main(String[] args) {
		Imposto iss = new ICMS();
		
		
		Orcamento orcamento = new Orcamento(500);
		
		double valor = iss.calcula(orcamento);
		
		System.out.println(valor);
	}

}
