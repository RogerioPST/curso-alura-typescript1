package br.com.comportamentos_compostos_por_outros.DECORATOR.antes;



public class ISS implements Imposto{
	public double calcula(Orcamento orcamento) {
		return orcamento.getValor() * 0.06;
	}

}
