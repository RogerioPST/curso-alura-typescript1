package br.com.comportamentos_compostos_por_outros.DECORATOR.antes;



public interface Imposto {
	public double calcula(Orcamento orcamento);

}

