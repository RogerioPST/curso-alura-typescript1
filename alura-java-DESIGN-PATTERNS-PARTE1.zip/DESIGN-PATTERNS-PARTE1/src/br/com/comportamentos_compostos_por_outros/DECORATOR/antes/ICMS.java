package br.com.comportamentos_compostos_por_outros.DECORATOR.antes;



public class ICMS implements Imposto{
	public double calcula(Orcamento orcamento) {
		return orcamento.getValor() * 0.05 + 50;
	}

}
