package br.com.executando_diferentes_acoes.OBSERVER.apos_refatoracao_um;

import br.com.executando_diferentes_acoes.OBSERVER.antes.NotaFiscal;

public class Impressora {
	public void imprime(NotaFiscal nf) {
		// TODO Auto-generated method stub
		System.out.println("imprime");
		
	}

}
