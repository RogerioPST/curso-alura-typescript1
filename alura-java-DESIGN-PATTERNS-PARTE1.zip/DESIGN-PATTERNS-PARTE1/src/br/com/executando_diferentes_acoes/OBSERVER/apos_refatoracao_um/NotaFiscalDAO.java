package br.com.executando_diferentes_acoes.OBSERVER.apos_refatoracao_um;

import br.com.executando_diferentes_acoes.OBSERVER.antes.NotaFiscal;

public class NotaFiscalDAO {
	public void salvaNoBanco(NotaFiscal nf) {
		System.out.println("salvei no banco");
	}

}
