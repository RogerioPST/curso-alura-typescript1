package br.com.executando_diferentes_acoes.OBSERVER.apos_refatoracao_um;

import br.com.executando_diferentes_acoes.OBSERVER.antes.NotaFiscal;

public class EnviadorDeEmail {
	
	public void enviaEmail(NotaFiscal nf) {
		System.out.println("envia por email");
	}

}
