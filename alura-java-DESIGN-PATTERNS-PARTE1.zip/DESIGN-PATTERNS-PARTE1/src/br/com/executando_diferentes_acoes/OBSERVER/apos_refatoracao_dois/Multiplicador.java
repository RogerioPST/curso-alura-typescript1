package br.com.executando_diferentes_acoes.OBSERVER.apos_refatoracao_dois;

import br.com.executando_diferentes_acoes.OBSERVER.antes.NotaFiscal;

public class Multiplicador implements AcaoAposGerarNotaFiscal {
	
	private double fator;

	public Multiplicador(double fator) {
		this.fator = fator;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void executa(NotaFiscal nf) {
		System.out.println(nf.getValorBruto()*fator);
		// TODO Auto-generated method stub
		
	}

}
