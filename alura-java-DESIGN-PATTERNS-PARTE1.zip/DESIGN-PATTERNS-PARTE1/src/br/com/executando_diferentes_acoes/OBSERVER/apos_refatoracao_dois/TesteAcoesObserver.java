package br.com.executando_diferentes_acoes.OBSERVER.apos_refatoracao_dois;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import br.com.executando_diferentes_acoes.OBSERVER.antes.ItemDaNota;
import br.com.executando_diferentes_acoes.OBSERVER.antes.NotaFiscal;

public class TesteAcoesObserver {
	public static void main(String[] args) {
		List<AcaoAposGerarNotaFiscal> todasAcoesASeremExecutadas = new ArrayList<AcaoAposGerarNotaFiscal>();
		todasAcoesASeremExecutadas.add(new EnviadorDeEmail());
		NotaFiscalBuilder builder = new NotaFiscalBuilder(todasAcoesASeremExecutadas);

		builder.adicionaAcao(new EnviadorDeEmail());
		builder.adicionaAcao(new EnviadorDeSMS());
		builder.adicionaAcao(new Impressora());
		builder.adicionaAcao(new NotaFiscalDAO());
		builder.adicionaAcao(new Multiplicador(12));

		NotaFiscal nf = builder.paraEmpresa("caelum").comCNPJ("1234").com(new ItemDaNota("it1", 100))
				.comObservacoes("qq").naData(Calendar.getInstance()).constroi();
		
		System.out.println(nf.getValorBruto());
	}

}
