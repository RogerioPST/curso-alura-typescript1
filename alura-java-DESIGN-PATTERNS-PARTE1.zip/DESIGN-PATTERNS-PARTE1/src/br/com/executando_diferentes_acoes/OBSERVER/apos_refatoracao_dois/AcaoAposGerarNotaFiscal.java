package br.com.executando_diferentes_acoes.OBSERVER.apos_refatoracao_dois;

import br.com.executando_diferentes_acoes.OBSERVER.antes.NotaFiscal;

public interface AcaoAposGerarNotaFiscal {
	void executa(NotaFiscal nf);

}
