package br.com.executando_diferentes_acoes.OBSERVER.apos_refatoracao_dois;

import br.com.executando_diferentes_acoes.OBSERVER.antes.NotaFiscal;

public class EnviadorDeEmail implements AcaoAposGerarNotaFiscal{
	
	public void executa(NotaFiscal nf) {
		System.out.println("envia por email");
	}

}