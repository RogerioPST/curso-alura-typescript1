package br.com.criacao_de_objetos.BUILDER.apos_refatoracao_um;

import br.com.criacao_de_objetos.BUILDER.antes.ItemDaNota;

public class ItemDaNotaBuilder {
	
	private String nome;
	private double valor;

	public ItemDaNotaBuilder com(String nome) {
		this.nome = nome;
				return this;
		
	}
	public ItemDaNotaBuilder comValor(double valor) {
		
				this.valor = valor;
				return this;
		
	}
	
	public ItemDaNota constroi() {
		return new ItemDaNota(nome, valor);
		
	}
	
	
	
	

}
