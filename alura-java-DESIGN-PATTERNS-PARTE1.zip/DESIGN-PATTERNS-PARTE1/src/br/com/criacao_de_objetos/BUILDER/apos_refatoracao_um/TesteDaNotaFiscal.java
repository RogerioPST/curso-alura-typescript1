package br.com.criacao_de_objetos.BUILDER.apos_refatoracao_um;

import br.com.criacao_de_objetos.BUILDER.antes.NotaFiscal;

public class TesteDaNotaFiscal {
	public static void main(String[] args) {
		
		NotaFiscalBuilder builder = new NotaFiscalBuilder();
		builder.paraEmpresa("Caelum")
		.comCNPJ("12")
		.com(new ItemDaNotaBuilder().com("item1").comValor(200).constroi())
		.com(new ItemDaNotaBuilder().com("item2").comValor(300).constroi())
		.com(new ItemDaNotaBuilder().com("item3").comValor(400).constroi())
		.comObservacoes("obs");
		
		
		NotaFiscal nf = builder.constroi();
		
		System.out.println(nf.getValorBruto());
		System.out.println(nf.getDataDeEmissao());
	}

}
