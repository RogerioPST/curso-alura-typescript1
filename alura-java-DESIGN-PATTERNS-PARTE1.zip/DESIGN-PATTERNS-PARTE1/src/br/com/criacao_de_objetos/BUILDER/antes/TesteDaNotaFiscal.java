package br.com.criacao_de_objetos.BUILDER.antes;

import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class TesteDaNotaFiscal {
	public static void main(String[] args) {
		List<ItemDaNota> itens = Arrays.asList(new ItemDaNota("item1", 200), new ItemDaNota("item2", 400));
		
		double valorTotal = 0;
		for(ItemDaNota item : itens) {
			valorTotal += item.getValor();
		}
		
		double impostos = valorTotal * 0.05;
		
		
		NotaFiscal nf = new NotaFiscal("razaoSocial", "cnpj", Calendar.getInstance(), valorTotal, impostos, itens, "obs qualquer");
	}

}
