package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

import br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes.Orcamento;

public class DescontoPorVendaCasada implements Desconto {

	private Desconto proximoDesconto;

	@Override
	public double desconta(Orcamento orcamento) {
		if (orcamento.contemItemDeNome("Caneta") && orcamento.contemItemDeNome("Lapis"))
			return orcamento.getValor() * 0.05;
		else
			return proximoDesconto.desconta(orcamento);
	}

	@Override
	public void setProximoDesconto(Desconto proximoDesconto) {
		this.proximoDesconto = proximoDesconto;
		// TODO Auto-generated method stub
		
	}

}
