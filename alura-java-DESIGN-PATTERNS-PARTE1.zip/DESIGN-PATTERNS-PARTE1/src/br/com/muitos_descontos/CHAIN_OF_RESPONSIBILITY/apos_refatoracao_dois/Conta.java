package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

public class Conta {
	private String titular;
	private double saldo;
	
	public Conta() {
		// TODO Auto-generated constructor stub
	}
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}		

}
