package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

public class RespostaDefault implements Resposta{

		//private Resposta resposta;

		@Override
		public void responde(Requisicao req, Conta conta) {
			//if (req.getFormato().equals(Formato.CSV)) {
				System.out.println("resposta serializada default");
			//} else {
			//	resposta.responde(req, conta);			
			//}
			
		}

		@Override
		public void setProxima(Resposta resposta) {
			
			// TODO Auto-generated method stub
			
		}

	}