package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

public class TesteDeRequisicaoClienteServidor {
	public static void main(String[] args) {
		Conta conta = new Conta();
		conta.setSaldo(200);
		conta.setTitular("Rogerio");
		
		RespostaXML xml = new RespostaXML();
		RespostaPorcento porcento = new RespostaPorcento();
		RespostaCSV csv = new RespostaCSV();
		//RespostaDefault padrao = new RespostaDefault();
		
		xml.setProxima(porcento);
		porcento.setProxima(csv);
		//csv.setProxima(padrao);
		
		Requisicao req = new Requisicao(Formato.CSV);
		xml.responde(req , conta);
		
		
	}

}
