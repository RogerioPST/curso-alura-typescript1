package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

import br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes.Orcamento;

public class SemDesconto implements Desconto{

	@Override
	public double desconta(Orcamento orcamento) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setProximoDesconto(Desconto proximoDesconto) {
		// TODO Auto-generated method stub
		
	}

}
