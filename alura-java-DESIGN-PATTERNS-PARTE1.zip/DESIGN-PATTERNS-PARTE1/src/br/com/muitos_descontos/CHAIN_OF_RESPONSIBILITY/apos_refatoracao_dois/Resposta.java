package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

public interface Resposta {
    void responde(Requisicao req, Conta conta);
    void setProxima(Resposta resposta);

}
