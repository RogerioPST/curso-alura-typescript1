package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

public enum Formato {
	XML, 
	CSV, 
	PORCENTO
}
