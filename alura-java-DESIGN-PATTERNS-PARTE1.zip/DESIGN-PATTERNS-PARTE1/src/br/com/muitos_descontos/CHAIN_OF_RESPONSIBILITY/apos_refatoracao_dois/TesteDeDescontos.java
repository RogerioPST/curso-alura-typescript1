package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

import br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes.Item;
import br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes.Orcamento;

public class TesteDeDescontos {
	public static void main(String[] args) {
		CalculadorDeDescontos descontos = new CalculadorDeDescontos();
		
		Orcamento orcamento = new Orcamento(500.0);
		
		orcamento.adicionaItem(new Item("Caneta", 250));
		orcamento.adicionaItem(new Item("Lapiss", 250));
	
		
		
		
		double descontoFinal = descontos.calcula(orcamento);
		
		System.out.println(descontoFinal);
	}

}
