package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

import br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes.Orcamento;

public class CalculadorDeDescontos {
	
	public double calcula(Orcamento orcamento) {
		Desconto d1 = new DescontoPorCincoItens();
		Desconto d2 = new DescontoPorMaisDeQuinhentosReais();
		Desconto d3 = new DescontoPorVendaCasada();		
		Desconto d4 = new SemDesconto();
		
		d1.setProximoDesconto(d2);
		d2.setProximoDesconto(d3);
		d3.setProximoDesconto(d4);
		
		return d1.desconta(orcamento);
	}

}
