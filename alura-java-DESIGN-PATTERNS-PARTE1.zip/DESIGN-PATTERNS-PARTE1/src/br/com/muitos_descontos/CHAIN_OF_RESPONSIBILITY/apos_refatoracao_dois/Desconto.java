package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

import br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes.Orcamento;

public interface Desconto {
	
	double desconta(Orcamento orcamento);
	void setProximoDesconto(Desconto proximoDesconto);

}
