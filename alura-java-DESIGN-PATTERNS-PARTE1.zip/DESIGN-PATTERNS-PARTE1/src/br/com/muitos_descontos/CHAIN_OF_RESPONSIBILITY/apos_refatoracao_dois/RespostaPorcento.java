package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_dois;

public class RespostaPorcento implements Resposta{

		private Resposta resposta;

		@Override
		public void responde(Requisicao req, Conta conta) {
			if (req.getFormato().equals(Formato.PORCENTO)) {
				System.out.println("resposta serializada em Porcento");
			} else {
				resposta.responde(req, conta);			
			}
			
		}

		@Override
		public void setProxima(Resposta resposta) {
			this.resposta = resposta;
			// TODO Auto-generated method stub
			
		}

	}
