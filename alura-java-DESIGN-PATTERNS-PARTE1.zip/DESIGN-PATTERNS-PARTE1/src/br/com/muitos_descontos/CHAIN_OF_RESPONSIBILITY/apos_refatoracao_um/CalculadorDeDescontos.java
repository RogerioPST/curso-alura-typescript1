package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_um;

import br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes.Orcamento;

public class CalculadorDeDescontos {

	public double calcula(Orcamento orcamento) {
		double desconto = new DescontoPorCincoItens().desconta(orcamento);
		if (desconto == 0) { // se o primeiro desconto falhar, pq n tem 5 itens, mas pode ser maior que 500
								// reais, tenho q chamar o proximo
			desconto = new DescontoPorMaisDeQuinhentosReais().desconta(orcamento);

		}
		//toda vez q eu tiver um novo desconto, tenho q verificar se foi zero e tento aplicar o prox desconto.
		return 0;
	}

}
