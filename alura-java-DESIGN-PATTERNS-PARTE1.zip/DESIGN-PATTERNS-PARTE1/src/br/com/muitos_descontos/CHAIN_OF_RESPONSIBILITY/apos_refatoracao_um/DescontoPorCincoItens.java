package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_um;

import br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes.Orcamento;

public class DescontoPorCincoItens {
	public double desconta(Orcamento orcamento) {
		if (orcamento.getItens().size() > 5) {
			return orcamento.getValor() * 0.1;
		} else {
			return 0;
		}
	}

}
