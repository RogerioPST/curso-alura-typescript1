package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.apos_refatoracao_um;

import br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes.Orcamento;

public class DescontoPorMaisDeQuinhentosReais {

	
		public double desconta(Orcamento orcamento) {
			if (orcamento.getValor()> 500) {
				return orcamento.getValor() * 0.07;
			} else {
				return 0;
			}
		}

	}

