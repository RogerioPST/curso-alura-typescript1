package br.com.muitos_descontos.CHAIN_OF_RESPONSIBILITY.antes;

public class CalculadorDeDescontos {
	
	public double calcula(Orcamento orcamento) {
		//mais de 5 itens, tem desconto!
		if (orcamento.getItens().size() > 5) {
			return orcamento.getValor() * 0.1;
		}
		
		//segunda regra
		if (orcamento.getValor() > 500) {
			return orcamento.getValor() * 0.07;
		}
		
		//em caso contrario
		
		return 0;
	}

}
