package br.com.estados_que_variam.STATE.apos_refatoracao_um;

public class EmAprovacao implements EstadoDeUmOrcamento{
	
	private boolean descontoAplicado = false;
	
	public void aplicaDescontoExtra(Orcamento orcamento) {
		if (!descontoAplicado) {
			
			orcamento.valor -= orcamento.valor * 0.05;
			descontoAplicado = true;
		}else {
			throw new RuntimeException("desconto ja aplicado");
		}
		
	}

	@Override
	public void aprova(Orcamento orcamento) {
		// TODO Auto-generated method stub
		orcamento.estadoAtual = new Aprovado();
		
	}

	@Override
	public void finaliza(Orcamento orcamento) {
		// TODO Auto-generated method stub
		orcamento.estadoAtual = new Reprovado();
		
		
	}

	@Override
	public void reprova(Orcamento orcamento) {
		// TODO Auto-generated method stub
		throw new RuntimeException("orcamento em aprovacao n podem ir direto p finalizado");
		
	}

}
