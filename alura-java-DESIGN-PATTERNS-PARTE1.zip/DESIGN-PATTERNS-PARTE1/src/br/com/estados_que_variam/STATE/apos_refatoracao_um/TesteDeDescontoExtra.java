package br.com.estados_que_variam.STATE.apos_refatoracao_um;


/*
 * qdo temos obj cujam acoes variam de acordo com o estado interno, podemos optar por diferentes classes q geralmente sao menores e mais
 * faceis de serem entendidas.
 * o obj principal entao contem o estado q apenas repassa suas acoes p ele e ele define o comportamento a ser executado e as possiveis 
 * transicoes
 * padrao ESTATE.
 */

public class TesteDeDescontoExtra {
	
	public static void main(String[] args) {
		Orcamento reforma = new Orcamento(500);
		
		reforma.aplicaDescontoExtra();
		
		System.out.println(reforma.getValor());
		
		reforma.aprova();
		
		reforma.aplicaDescontoExtra();
		
		System.out.println(reforma.getValor());
		
		reforma.finaliza();
		
		reforma.aplicaDescontoExtra();
		
		System.out.println(reforma.getValor());
		
	}

}