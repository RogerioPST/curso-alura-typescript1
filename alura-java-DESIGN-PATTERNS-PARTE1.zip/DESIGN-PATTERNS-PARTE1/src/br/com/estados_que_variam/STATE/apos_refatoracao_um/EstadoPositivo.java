package br.com.estados_que_variam.STATE.apos_refatoracao_um;

public class EstadoPositivo implements EstadoDeUmaConta{

	@Override
	public void saca(Conta conta, double valor) {
		// TODO Auto-generated method stub
		conta.saldo -= valor;
		if(conta.saldo < 0 ) conta.estadoDaConta = new EstadoNegativo();
		
	}

	@Override
	public void deposita(Conta conta, double valor) {
		// TODO Auto-generated method stub
		conta.saldo += 0.98 *valor;
		
	}
	
	

}
