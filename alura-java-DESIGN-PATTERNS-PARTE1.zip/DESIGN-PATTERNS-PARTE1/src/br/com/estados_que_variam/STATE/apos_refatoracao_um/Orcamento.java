package br.com.estados_que_variam.STATE.apos_refatoracao_um;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import br.com.estados_que_variam.STATE.antes.Item;

public class Orcamento {	
	
	protected double valor;
	private final List<Item> itens;
	
	
	protected EstadoDeUmOrcamento estadoAtual;
	

	public Orcamento(double valor) {
		this.valor = valor;
		itens = new ArrayList<Item>();
		estadoAtual = new EmAprovacao();

	}

	public double getValor() {
		return valor;
	}
	
	public void adicionaItem(Item item) {
		itens.add(item);
	}

	public List<Item> getItens() {
		return Collections.unmodifiableList(itens);
	}
	
	public boolean contemItemDeNome(String nomeDoItem) {
        for (Item item : itens) {
            if (item.getNome().equals(nomeDoItem)) return true;
        }
        return false;
    }

	public void aplicaDescontoExtra() {
		estadoAtual.aplicaDescontoExtra(this);
		
		
	}
	
	//precisamos fazer agora com que o orcamento repasse a ordem de transacao p o estado corrente do obj, pois eh o estado q conhece a 
	//proxima transicao
	public void aprova() {
		estadoAtual.aprova(this);
	}
	public void reprova() {
		estadoAtual.reprova(this);
	}
	public void finaliza() {
		estadoAtual.finaliza(this);
	}	
}
