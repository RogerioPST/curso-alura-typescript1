package br.com.estados_que_variam.STATE.apos_refatoracao_um;

public class EstadoNegativo implements EstadoDeUmaConta{

	@Override
	public void saca(Conta conta, double valor) {
		// TODO Auto-generated method stub
		throw new RuntimeException("contas c saldo negativo n podem ter saques");
		
	}

	@Override
	public void deposita(Conta conta, double valor) {
		// TODO Auto-generated method stub
		conta.saldo += 0.95 *valor;
		if(conta.saldo > 0 ) conta.estadoDaConta = new EstadoPositivo();
		
	}

}
