package br.com.estados_que_variam.STATE.apos_refatoracao_um;

public interface EstadoDeUmOrcamento {
	
	void aplicaDescontoExtra(Orcamento orcamento);
	
	void aprova(Orcamento orcamento);
	void finaliza(Orcamento orcamento);
	void reprova(Orcamento orcamento);

}
