package br.com.estados_que_variam.STATE.apos_refatoracao_um;

public class Conta {
	
	protected double saldo;
	
	protected EstadoDeUmaConta estadoDaConta;

	public Conta(double saldo) {
		this.saldo = saldo;
		estadoDaConta = new EstadoPositivo();
		// TODO Auto-generated constructor stub
	}

	public double getSaldo() {
		return saldo;
	}

	public void saca(double valor) {
		// TODO Auto-generated method stub		
		estadoDaConta.saca(this, valor);
		
	}

	public void deposita(double valor) {
		// TODO Auto-generated method stub
		estadoDaConta.deposita(this, valor);
		
	}
	
	

}
