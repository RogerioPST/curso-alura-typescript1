package br.com.estados_que_variam.STATE.apos_refatoracao_um;

public class TesteDosEstadosDeUmaConta {
	public static void main(String[] args) {
		Conta conta = new Conta(50);
		
		conta.saca(100);
		conta.deposita(200);
		
		conta.saca(50);
	}

}
