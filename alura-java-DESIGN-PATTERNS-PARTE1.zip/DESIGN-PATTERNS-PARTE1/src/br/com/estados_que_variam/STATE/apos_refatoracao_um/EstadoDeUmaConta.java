package br.com.estados_que_variam.STATE.apos_refatoracao_um;

public interface EstadoDeUmaConta {
	
	public void saca(Conta conta, double valor);
	public void deposita(Conta conta, double valor);
	
	

}
