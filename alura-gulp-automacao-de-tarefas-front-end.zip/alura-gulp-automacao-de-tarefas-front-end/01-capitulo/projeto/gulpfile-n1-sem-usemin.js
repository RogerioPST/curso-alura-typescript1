var gulp = require('gulp'),
    imagemin = require('gulp-imagemin'),
    clean = require('gulp-clean'),
    concat = require('gulp-concat')
    htmlReplace = require('gulp-html-replace'),
    uglify = require('gulp-uglify'),
    usemin = require('gulp-usemin');

gulp.task('default', ['copy'], function(){
    gulp.start('build-img', 'build-js', 'build-html');
})    ;

//tarefa do gulp q copia todo o conteudo da pasta src para pasta dist,  
//mas q depende da tarefa clean ser executada primeiro
// - /informo q depende de clean ser executado - 
//2ºparam da funcao task - ['clean']
//isso vai fazer executar clean primeiro qdo eu chamar npm run gulp copy
gulp.task('copy', ['clean'], function () {
    //o return eh obrigatorio em gulp qdo essa tarefa precisa ser executada primeiro do q outra
    //isso ocorre pq gulp eh assincrono
    //Para que a tarefa copy espere a tarefa clean terminar, a tarefa clean precisa retornar seu stream. Quando uma tarefa retorna um stream ela sinaliza para o Gulp que a tarefa na qual ela é dependência tem que esperar seu processamento    
    return gulp.src('src/**/*')
        .pipe(gulp.dest('dist'));
});

//tarefa do gulp q apaga toda a pasta dist
gulp.task('clean', function () {
    //o return eh obrigatorio em gulp qdo essa tarefa precisa ser executada primeiro do q outra
    return gulp.src('dist')
        .pipe(clean());
});


//É através da função gulp.task que criamos tarefas. Ela recebe como primeiro parâmetro o nome da tarefa e como segundo uma função. O bloco desta função contém o código que desejamos executar para a tarefa.
//qdo eu chamar 'npm run gulp build-img', vai executar primeiro a tarefa dependente 'copy'
//se 'copy' depender de alguem, vai executar primeiro esse alguem, no caso 'clean'
gulp.task('build-img', function () {
    //'src/img/**/*' - indica todos os arquivos de todos os diretorios dentro da pasta img
    gulp.src('dist/img/**/*')
        //A analogia com tubos não foi por acaso, porque é através do método .pipe (tubo) que ligamos fluxos, seja ele de leitura ou escrita. Ele recebe como parâmetro outro fluxo que desejamos nos conectar. Vamos ligar o fluxo de leitura ao imagemin e este último ao fluxo de escrita:
        .pipe(imagemin())
        .pipe(gulp.dest('dist/img'));

});
gulp.task('build-js', function(){
    //gulp.src('dist/js/**/*.js') //pega todos os arquivos js sem ordem
    gulp.src(['dist/js/jquery.js', 'dist/js/home.js', 'dist/js/produto.js']) //pega na ordem
        .pipe(concat('all.js')) //e concatena em um arquivo soh chamado 'all.js'
        .pipe(uglify()) //soh eh feito em memoria
        .pipe(gulp.dest('dist/js')); //e poe na pasta dist
});


gulp.task('build-html', function(){
    gulp.src('dist/**/*.html')
        //o htmlReplace vai procurar pelo comentario/metatag '<!-- build:js-->' no arquivo index.html
        // e vai substituir onde ele encontrou o 'js', vai substituir p all.js
        .pipe(htmlReplace({
            js: 'js/all.js' 
        }))
        .pipe(gulp.dest('dist'));
});

