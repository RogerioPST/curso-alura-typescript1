var gulp = require('gulp'),
    imagemin = require('gulp-imagemin'),
    clean = require('gulp-clean'),
    concat = require('gulp-concat')
    htmlReplace = require('gulp-html-replace'),
    uglify = require('gulp-uglify'),
    usemin = require('gulp-usemin'), 
    cssmin = require('gulp-cssmin'),
    browserSync = require('browser-sync'),
    jshint = require("gulp-jshint"),
    jshintStylish = require("jshint-stylish")//maneira menos verbosa e mais elegante
    jshint = require("gulp-jshint"),
    autoprefixer = require("gulp-autoprefixer"),
    less = require("gulp-less"),
    csslint = require("gulp-csslint")    ;

/*
Mas imagine configurar nosso gulpfile.js para que tenha uma lista de arquivos que serão concatenados por página? E não podemos nos esquecer de colocá-los na ordem correta. Trabalhoso não?

Foi pensando nesse problema que foi criado o plugin gulp-usemin.
*/

gulp.task('default', ['copy'], function(){
    gulp.start('build-img', 'usemin');
})    ;

//tarefa do gulp q copia todo o conteudo da pasta src para pasta dist,  
//mas q depende da tarefa clean ser executada primeiro
// - /informo q depende de clean ser executado - 
//2ºparam da funcao task - ['clean']
//isso vai fazer executar clean primeiro qdo eu chamar npm run gulp copy
gulp.task('copy', ['clean'], function () {
    //o return eh obrigatorio em gulp qdo essa tarefa precisa ser executada primeiro do q outra
    //isso ocorre pq gulp eh assincrono
    //Para que a tarefa copy espere a tarefa clean terminar, a tarefa clean precisa retornar seu stream. Quando uma tarefa retorna um stream ela sinaliza para o Gulp que a tarefa na qual ela é dependência tem que esperar seu processamento    
    return gulp.src('src/**/*')
        .pipe(gulp.dest('dist'));
});

//tarefa do gulp q apaga toda a pasta dist
gulp.task('clean', function () {
    //o return eh obrigatorio em gulp qdo essa tarefa precisa ser executada primeiro do q outra
    return gulp.src('dist')
        .pipe(clean());
});


//É através da função gulp.task que criamos tarefas. Ela recebe como primeiro parâmetro o nome da tarefa e como segundo uma função. O bloco desta função contém o código que desejamos executar para a tarefa.
//qdo eu chamar 'npm run gulp build-img', vai executar primeiro a tarefa dependente 'copy'
//se 'copy' depender de alguem, vai executar primeiro esse alguem, no caso 'clean'
gulp.task('build-img', function () {
    //'src/img/**/*' - indica todos os arquivos de todos os diretorios dentro da pasta img
    gulp.src('dist/img/**/*')
        //A analogia com tubos não foi por acaso, porque é através do método .pipe (tubo) que ligamos fluxos, seja ele de leitura ou escrita. Ele recebe como parâmetro outro fluxo que desejamos nos conectar. Vamos ligar o fluxo de leitura ao imagemin e este último ao fluxo de escrita:
        .pipe(imagemin())
        .pipe(gulp.dest('dist/img'));

});

//com o usemin, eu n preciso da task do build-html e build-js
//As chaves do objeto passado para htmlReplace devem coincidir com os nomes nos comentários. Se no comentário temos <!-- build:css --> deve existir a chave css. Se o comentário fosse <!-- build:vaporware --> chave seria vaporware. O valor da chave é o nome do arquivo que substituirá o comentário.
//Veja que ainda precisamos distinguir entre build:js e build:css, porém cada recebe ao lado o nome do arquivo resultante da concatenação.
gulp.task('usemin', function(){
    gulp.src('dist/**/*.html')
        .pipe(usemin({
            'js' : [uglify], //js eh o nome do comentario build-js nos arquivos.html; uglify eh o plugin usado p esses arquivos
            'css': [autoprefixer, cssmin] //css eh o nome do comentario build-css nos arquivos.html; cssmin eh o plugin usado p esses arquivos
        }))
        .pipe(gulp.dest('dist'));
});

gulp.task('server', function(){
    //A função init do BrowserSync recebe um objeto com a chave server. É no atributo baseDir deste objeto que indicamos a pasta que o BrowserSync considerará como raiz quando acessarmos o endereço padrão localhost:3000. Isso significa que se houver o arquivo projeto/src/index.html podemos acessa-lo como localhost:3000/index.html, porque a pasta raiz é src da pasta projetos.
    browserSync.init({
        server:{
            baseDir: 'src'
        }
    });
    //A função gulp.watch recebe como primeiro parâmetro o evento que desejamos observar, em nosso caso, estamos interessados apenas nos arquivos que mudaram, por isso passamos change. Por fim, o útlimo parâmetro é a função que desejamos executar, nesse caso, passamos diretamente BrowserSync.reload. Como passamos a função e não a invocamos, será o watcher que a chamará toda vez que um arquivo for alterado.
    gulp.watch('src/js/*.js').on('change', function(qualquerNomeDeEvent){
        //exibe o arquivo modificado
        console.log(qualquerNomeDeEvent.path);
        gulp.src(qualquerNomeDeEvent.path)
            .pipe(jshint())
            .pipe(jshint.reporter(jshintStylish));


    });
    gulp.watch('src/css/*.css').on('change', function(qualquerNomeDeEvent){
        //exibe o arquivo modificado
        console.log(qualquerNomeDeEvent.path);
        gulp.src(qualquerNomeDeEvent.path)
            .pipe(csslint())
            .pipe(csslint.reporter());


    });

    gulp.watch('src/less/*.less').on('change', function(qualquerNomeDeEvent){
        //exibe o arquivo modificado
        console.log(qualquerNomeDeEvent.path);
        gulp.src(qualquerNomeDeEvent.path)
            .pipe(less().on('error', function(erro){
                console.log('problema na compilação: '+ erro.message);
            }))
            .pipe(gulp.dest('src/css'));


    });
    gulp.watch('src/**/*').on('change', browserSync.reload);
});






