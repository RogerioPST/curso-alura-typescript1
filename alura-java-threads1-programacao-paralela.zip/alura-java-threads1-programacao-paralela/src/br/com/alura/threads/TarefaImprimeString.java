package br.com.alura.threads;

public class TarefaImprimeString implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		String nome = "Teste";
		
		System.out.println(nome);
		
	}

}
