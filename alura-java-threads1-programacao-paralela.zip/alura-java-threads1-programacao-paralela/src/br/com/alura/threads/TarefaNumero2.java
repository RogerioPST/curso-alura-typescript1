package br.com.alura.threads;

public class TarefaNumero2 implements Runnable {
	
	private Banheiro banheiro;
	
	public TarefaNumero2(Banheiro banheiro){
		this.banheiro = banheiro;
		
		
	}
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		banheiro.fazNumero2();
		
		

	}

}
