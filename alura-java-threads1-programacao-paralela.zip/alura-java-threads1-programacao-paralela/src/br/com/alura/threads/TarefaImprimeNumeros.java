package br.com.alura.threads;

public class TarefaImprimeNumeros implements Runnable{

    @Override
    public void run() {
        for(int i=0;i<1000;i++) {
            Thread threadAtual = Thread.currentThread();
            
            try {
				threadAtual.sleep(5000);
				if (threadAtual.isAlive()) {
					System.out.println("estou viva: " +threadAtual.getId() + " - " + i);
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            
            System.out.println(threadAtual.getId() + " - " + i);
        }
    }
}