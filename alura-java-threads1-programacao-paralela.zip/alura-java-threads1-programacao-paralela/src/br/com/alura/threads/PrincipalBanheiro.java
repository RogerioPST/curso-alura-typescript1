package br.com.alura.threads;import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

public class PrincipalBanheiro {
	
	public static void main(String[] args) {
		
		Banheiro banheiro = new Banheiro();
		
		Thread convidado1 = new Thread(new TarefaNumero1(banheiro), "Joao");
		Thread convidado2 = new Thread(new TarefaNumero2(banheiro), "Pedro");
		Thread limpeza = new Thread(new TarefaLimpeza(banheiro), "Limpeza");
		//isso indica q vai rodar no background enquanto existirem outras threads rodando
		limpeza.setDaemon(true);
		limpeza.setPriority(Thread.MAX_PRIORITY);
//		Thread convidado3 = new Thread(new TarefaNumero1(banheiro), "Maria");
//		Thread convidado4 = new Thread(new TarefaNumero2(banheiro), "Ana");
		
		convidado1.start();
		convidado2.start();
		limpeza.start();
//		convidado3.start();
//		convidado4.start();
		
	}

}
