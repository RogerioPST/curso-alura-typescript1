package br.com.alura.threads;

public class Principal {
	
	public static void main(String[] args) throws InterruptedException {
		System.out.println("isso eh um thread main");
		
		//Thread.sleep(300000);
	}

}
