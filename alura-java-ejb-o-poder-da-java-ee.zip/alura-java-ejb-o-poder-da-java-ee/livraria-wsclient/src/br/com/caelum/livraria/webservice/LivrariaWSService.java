/**
 * LivrariaWSService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.caelum.livraria.webservice;

public interface LivrariaWSService extends javax.xml.rpc.Service {
    public java.lang.String getLivrariaWSPortAddress();

    public br.com.caelum.livraria.webservice.LivrariaWS getLivrariaWSPort() throws javax.xml.rpc.ServiceException;

    public br.com.caelum.livraria.webservice.LivrariaWS getLivrariaWSPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
