package br.com.caelum.livraria.webservice;

import java.rmi.RemoteException;

public class TesteRequestSoapComJava {
	public static void main(String[] args) throws RemoteException {
		
		// obj q sabe fazer a chamada remota e gerar soap. esses obj sao os proxys
		
		LivrariaWS cliente = new LivrariaWSProxy();
		//uma chamada remota. parece q eh chamada local, mas na verdade sera feita uma req htp enviando todo soap
		//o resultado eh um array de autores		
		Autor[] autoresPeloNome = cliente.getAutoresPeloNome("nico");
		
		for (Autor autor : autoresPeloNome) {
			System.out.println(autor.getNome());
			
		}
		
	}

}
