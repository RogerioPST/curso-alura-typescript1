package br.com.caelum.livraria.interceptador;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class LogInterceptador {
	
	@AroundInvoke
	public Object intercepta(InvocationContext context) throws Exception {
		
		long millis = System.currentTimeMillis();
		
		//chamada do metodo
		Object object = context.proceed();
		
		String metodo = context.getMethod().getName();
		String nomeClass = context.getTarget().getClass().getSimpleName();
		
		System.out.println("Classe interceptada: "+ nomeClass + " - metodo interceptado: " + metodo);
		System.out.println("tempo gasto: "+ (System.currentTimeMillis() - millis));
		
		return object; 
		
	}

}
