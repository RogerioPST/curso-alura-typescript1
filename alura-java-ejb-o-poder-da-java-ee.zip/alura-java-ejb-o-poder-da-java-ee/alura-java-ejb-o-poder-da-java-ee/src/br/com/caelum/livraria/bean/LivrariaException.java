package br.com.caelum.livraria.bean;

import javax.ejb.ApplicationException;

/*
 * Através da anotação @ApplicationException podemos reconfigurar o padrão para Application Exceptions. Veja o exemplo:

@ApplicationException(rollback=true)
public class ValidationException extends Exception {
}
Repare que, sem a anotação @ApplicationException, a ValidationException não causaria rollback da transação. Usando a anotação @ApplicationException podemos até criar uma exceção do tipo unchecked, normalmente uma System Exception:

@ApplicationException(rollback=true)
public class ValidationException extends RuntimeException {
}
Como estendemos a classe RuntimeException criamos uma exceção do tipo unchecked.
 */
@ApplicationException(rollback=true)
public class LivrariaException extends RuntimeException {

}
