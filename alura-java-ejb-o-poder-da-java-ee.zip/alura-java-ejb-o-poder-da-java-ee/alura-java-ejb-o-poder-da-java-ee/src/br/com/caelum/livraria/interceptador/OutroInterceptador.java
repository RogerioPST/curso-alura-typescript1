package br.com.caelum.livraria.interceptador;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class OutroInterceptador {
	
	@AroundInvoke
	public Object intercepta(InvocationContext context) throws Exception {
		
		long millis = System.currentTimeMillis();
		
		//chamada do metodo
		Object object = context.proceed();
		
		System.out.println("tempo gasto novamente: "+ (System.currentTimeMillis() - millis));
		
		return object; 
		
	}

}
