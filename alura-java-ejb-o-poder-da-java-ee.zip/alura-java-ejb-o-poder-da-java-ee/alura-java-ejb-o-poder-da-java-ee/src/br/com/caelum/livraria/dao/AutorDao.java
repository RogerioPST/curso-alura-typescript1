package br.com.caelum.livraria.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import br.com.caelum.livraria.modelo.Autor;

@Stateless
//@Interceptors({LogInterceptador.class, OutroInterceptador.class})
@TransactionManagement(TransactionManagementType.CONTAINER) // opcional, pq com o ejb e injecao de dependencias, isso ja
															// acontece por padrao no session bean e por isso n se usa
															// getTransaction.begin() e commit()
public class AutorDao {

	@PersistenceContext
	private EntityManager manager;

	// assim que o container ejb cria e inicializa o session bean, o metodo ap�s a
	// cria��o � executado
	// esse metodo eh chamado de callback
	@PostConstruct
	void aposCriacao() {
		System.out.println("AutorDAO foi criado");
	}

	// @TransactionAttribute(TransactionAttributeType.REQUIRED) //opcional, pq com o
	// ejb e injecao de dependencias, isso ja acontece por padrao no session bean e
	// por isso n se usa getTransaction.begin() e commit()
	@TransactionAttribute(TransactionAttributeType.MANDATORY) // com isso, se usa getTransaction.begin(), mas o lugar
																// ideal n eh na Dao, mas sim no AutorService
																// intermediario e commit()
	public void salva(Autor autor) {

		System.out.println("inicio de salvando autor: " + autor.getNome());

//		try {
//			Thread.sleep(20000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		manager.persist(autor);
		System.out.println("fim de salvando autor: " + autor.getNome());
		
		//simulando q ao chamar um web service vai dar uma exceção e n vai ser salvo no banco
		//throw new RuntimeException("servico indisponviel");
	}

	public List<Autor> todosAutores() {
		return manager.createQuery("select a from Autor a", Autor.class).getResultList();
	}

	public Autor buscaPelaId(Integer autorId) {
		Autor autor = this.manager.find(Autor.class, autorId);
		return autor;
	}

	public List<Autor> autoresPeloNome(String nome) {
		// TODO Auto-generated method stub
		TypedQuery<Autor> query = this.manager.createQuery("select a from Autor a where a.nome like :pNome", Autor.class);
		query.setParameter("pNome", "%" + nome + "%");
		
		return query.getResultList();
	}

}
