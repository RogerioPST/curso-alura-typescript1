package br.com.bytebank.teste;

import br.com.bytebank.modelo.CalculadorImposto;
import br.com.bytebank.modelo.ContaCorrente;
import br.com.bytebank.modelo.SeguroDeVida;

public class TesteCalculadorImposto {
	public static void main(String[] args) {
		
		ContaCorrente cc = new ContaCorrente(1212, 447);
		cc.deposita(100);
		
		SeguroDeVida s = new SeguroDeVida();
		
		CalculadorImposto c = new CalculadorImposto();
		c.registra(cc);
		c.registra(s);
		
		System.out.println(c.getTotalImposto());
		
	}
	
	
	

}
