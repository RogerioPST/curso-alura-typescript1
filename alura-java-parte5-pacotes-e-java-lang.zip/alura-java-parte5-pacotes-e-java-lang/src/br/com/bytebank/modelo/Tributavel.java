package br.com.bytebank.modelo;

interface Tributavel {
	
	double getValorImposto();

}
