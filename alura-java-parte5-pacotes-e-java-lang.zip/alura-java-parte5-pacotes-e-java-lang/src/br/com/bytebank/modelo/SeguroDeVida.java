package br.com.bytebank.modelo;

public class SeguroDeVida implements Tributavel{

	@Override
	public double getValorImposto() {
		// TODO Auto-generated method stub
		return 42;
	}
	
	

}
