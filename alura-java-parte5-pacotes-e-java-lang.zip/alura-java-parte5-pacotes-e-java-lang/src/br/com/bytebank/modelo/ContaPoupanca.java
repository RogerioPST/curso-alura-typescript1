package br.com.bytebank.modelo;

public class ContaPoupanca extends Conta {

	public ContaPoupanca(int agencia, int numero) {
		super(agencia, numero);
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Conta Poupan�a - " + super.toString();
	}
	
}
