import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Home from './Pages/Home/Home';

import Sobre from './Pages/Sobre/Sobre';
import Autores from './Pages/Autores/Autores';
import Livros from './Pages/Livros/Livros';
import NotFound from './Pages/NotFound/NotFound';

import { BrowserRouter, Switch, Route } from 'react-router-dom';

import * as serviceWorker from './serviceWorker';
//agora quero utilizar um componente de acordo com a rota
//BrowserRouter - a partir daqui , eu indico q estou querendo utilizar as rotas
//Switch - dentro dele, vou conter as rotas propriamente ditas da aplicacao
//Route - para cada rota q eu quiser, vou ter um Route

//exact={true} - eh pq o match eh parcial . por isso, eh importante colocar na rota /, 
//pq se n, qq outra rota q comecar com /, vai dar match
ReactDOM.render(
    <BrowserRouter>
        <Switch>
            <Route path='/' exact={true} component={Home} />
            <Route path='/sobre' component={Sobre} />
            <Route path='/autores' component={Autores} />
            <Route path='/livros' component={Livros} />
            <Route component={NotFound} />
        </Switch>

    </BrowserRouter>

    , document.getElementById('root'));

//ReactDOM.render(<Home />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
