import React, { Component, Fragment } from 'react';
import Header from '../../Components/Header/Header';
import DataTable from '../../Components/DataTable/DataTable';
import APIService from '../../utils/APIService';

import PopUp from '../../utils/PopUp';




class Autores extends Component {
    constructor(props) {
        super(props);

        this.state = {
            nomes: [],
              titulo: 'Autores'
        };
    }

    componentDidMount(){
      APIService.ListaNomes()
      
        .then(res =>{
          //success eh a msg de retorno da API
          if (res.message === 'success'){
            this.setState({
              nomes: [...this.state.nomes, ...res.data]
            });
            PopUp.exibeMensagem('success', 'listados c sucesso os autores');
          } 
        })
        .catch(err => PopUp.exibeMensagem('error', 'n foi possivel listar os autores'));
    }

    render() {
        return (
            <Fragment>
                <Header />
                <div className='container'>
                    <h1>Página de Autores</h1>
                    <DataTable dados={this.state.nomes} titulo={this.state.titulo} colunas={['nome']}/>
                </div>
            </Fragment>
        );
    }
}

export default Autores;