import React, { Component , Fragment} from 'react';
//webpack q permite importar svg, css dentro do arquivo javascript
//import logo from './logo.svg';
import './Home.css';
import 'materialize-css/dist/css/materialize.min.css';
import Tabela from '../../Components/Tabela/Tabela';

import Form from '../../Components/Formulario/Formulario';
import Header from '../../Components/Header/Header';

import PopUp from '../../utils/PopUp';

import APIService from '../../utils/APIService';

/*
E só pra te orientar em relação as suas dúvidas, um function component também chamado de stateless component é utilizado quando vc quer construir um componente mais enxuto que nem terá estado ( por isso eu prefiro o termo stateless component em vez de function component ).

Já a questão da importação do React e do Component não diz respeito ao React em si e sim ao sistema de módulos do ES6, tema esse tratado nos cursos que são pré-requisitos para o curso de React! Dê uma olhada nesse link e veja se o tema fica claro pra vc!
*/
//babel q permite colocar xml, html (JSX) dentro do codigo javascript, pois babel eh um transpiler 
class App extends Component {
constructor(props){
  super(props);
  //esse array nada mais eh do q o controle de estado da aplicacao, por isso, o state
  this.state ={
    autores : [],
  };
  //esse array nada mais eh do q o controle de estado da aplicacao, por isso, o state
  /*
  state = {
    autores: [
      {
        nome: 'Paulo',
        livro: 'React',
        preco: '1000'
      },
      {
        nome: 'Daniel',
        livro: 'Java',
        preco: '99'
      },
      {
        nome: 'Marcos',
        livro: 'Design',
        preco: '150'
      },
      {
        nome: 'Bruno',
        livro: 'DevOps',
        preco: '100'
      }
    ],
  };
  */
}

  removeAutor = (id) => {
    const { autores } = this.state;

    const autoresAtualizado = autores.filter(autor =>{
      return autor.id !== id;
    });

    APIService.RemoveAutor(id)      
      .then( res => {
        //deleted eh a msg de retorno da API
        if(res.message === 'deleted'){
          this.setState({autores: [...autoresAtualizado]});
          PopUp.exibeMensagem('info', 'Autor removido com sucesso');
        }
      })
      .catch(err => PopUp.exibeMensagem('error', 'n foi possivel remover o autor') );
    //o State serve para armazenar estado/valores de um componente, portanto, esse State deve ser constantemente atualizado de acordo com a interação do usuário.

    //Porém, não devemos alterar esse objeto diretamente, devemos seguir a convenção do React para conseguirmos modificá-lo.
    //Devemos alterar/atualizar o state utilizando o método setState() do React.
    

  }

  escutadorDeSubmit = autor =>{
    APIService.CriaAutor(JSON.stringify(autor))
      

      .then(res => {
        //success eh a msg de retorno da API
        if (res.message === 'success'){
          //utilizando spreadOperator
          this.setState({autores: [...this.state.autores, res.data]});
          PopUp.exibeMensagem('success', 'Autor add com sucesso');
        }
      })
      .catch(err =>PopUp.exibeMensagem('error', 'n foi possivel add o autor'));

  }

  //executado depois do metodo render. depois q o componente for construido, esse metodo eh chamado
  //depois q o componente App.js for construido, vou fazer a req p a minha API, alterar o estado do componente e automaticamente ele vai
  //ser redesenhado na minha tela.
  //alterei o estado, ele chama novamente o metodo render e eh redesenhado.
  componentDidMount(){
    APIService.ListaAutores()
      
      .then(res => {
        //success eh a msg de retorno da API
        if (res.message === 'success'){
        this.setState({autores: [...this.state.autores, ...res.data]});   
        }     
      })
      .catch(err => PopUp.exibeMensagem('error', 'n foi possivel listar os autores'));
  }

  render() {

    //fetch('http://localhost:8000/api/autor')
    //.then(res => res.json())
   // .then(res => console.log(res.data));

   //const autores = APIService.ListaAutores();

   //APIService.ListaLivros().then(res => console.log(res.data));

   //console.log(autores);


    return (
      //usa o JSX para referenciar como se fosse uma tag
      //n se usa class, pq eh palavra reservada do javascript. <div className="teste">
      //n se usa for, pq eh palavra reservada tb. usa 'htmlFor'. <label htmlFor="livro">Livro</label>  
      //passo uma propriedade dando o nome q quero e o valor entre {}
      //usa Fragment, pois n se pode ter dois elementos raiz nas linguagens de marcacao
      <Fragment>
        <Header />        
        <div className="container mb-10">        
        <h1>Casa do código</h1>
        <Tabela autores={this.state.autores} removeAutor={this.removeAutor} />
        <Form escutadorDeSubmit = {this.escutadorDeSubmit}/>
        </div>
      </Fragment>
      
    );
  }
}

export default App;
