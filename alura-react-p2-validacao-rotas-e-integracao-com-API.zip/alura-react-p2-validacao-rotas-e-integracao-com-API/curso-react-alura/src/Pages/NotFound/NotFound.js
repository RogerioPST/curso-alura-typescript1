import React, {Fragment} from 'react';
import Header from '../../Components/Header/Header';

//um function component. stateless component
const NotFound = () =>{
    return (
        <Fragment>
            <Header />
            <h1>pag n ecnontrada</h1>
        </Fragment>
    )

}

export default NotFound;