import React, {Component} from  'react';

//Function component é o modo mais simples de se declarar um componente no React (simple component), sendo necessário apenas retonar um JSX
const TableHead = () =>{
    return (<thead>
        <tr>
          <th>Autores</th>
          <th>Livros</th>
          <th>Precos</th>
          <th>Remover</th>
        </tr>

      </thead>);
}
//Function component é o modo mais simples de se declarar um componente no React (simple component), sendo necessário apenas retonar um JSX
//p funcoes, passamos os parametros na funcao , diferente da classe Tabela usada abaixo, em q passamos como destructurin no metodo render
const TableBody = (props) =>{
    // linha = elemento da iteracao
    const linhas = props.autores.map((linha) =>{
        return (
            //key eh a identificacao unica do elemento
            <tr key={linha.id}>
                <td>{linha.nome}</td>
                <td>{linha.livro}</td>
                <td>{linha.preco}</td>
                <td><button className="waves-effect waves-light indigo lighten-2 btn " onClick= {() => props.removeAutor(linha.id)}>Remover</button></td>                
            </tr>
        );
    });

    return (
        <tbody>
            {linhas}
        </tbody>
    );
}
//já o Class component precisa herdar de Component e conter um método render() obrigatório para que funcione.
//Alternativa correta! Essa são algumas das diferenças, mas lembre-se que das duas formas precisamos exportar esses elementos para utilizarmos em outro local.
class Tabela extends Component{
//todo class component precisa do metodo render
render(){
    // usando destructuring, pego a propriedade autores e qualquer outra propriedade q eu passar 
    //q coloquei no arquivo q chamou esse Tabela.js. props eh um array
    const {autores, removeAutor} = this.props;
    console.log(autores);
    return (
        <table className="centered highlight">
        <TableHead />
        <TableBody autores={autores} removeAutor={removeAutor}/>
        
      </table>
    );
}

}

export default Tabela;