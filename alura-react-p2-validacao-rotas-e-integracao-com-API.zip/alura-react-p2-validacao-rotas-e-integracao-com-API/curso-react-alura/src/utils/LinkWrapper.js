import React from 'react';

import {NavLink} from 'react-router-dom';


//recebe props p receber p qual rota ele tem q levar/direcionar 
//deixando os props por ultimo, como spread operator, consigo sobreescrever um estilo italico 
//por cima do bold
const LinkWrapper = props =>{
    return (
        <NavLink activeStyle={{fontWeight: 'bold'}} {...props} />
    );
}

export default LinkWrapper;
