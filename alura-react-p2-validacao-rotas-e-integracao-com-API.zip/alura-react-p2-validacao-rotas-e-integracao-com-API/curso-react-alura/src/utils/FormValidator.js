import validador from 'validator';

class FormValidator{

    constructor(validacoes){
        this.validacoes =validacoes;
    }

    valida(state){
        //itera pelo array de regras de validação e constrói
        //um objeto validacao e retorna-o

        //começa assumindo que está tudo válido, recebe o 
     //objeto do método valido.
        let validacao = this.valido();
        console.log(validacao);

        this.validacoes.forEach(regra =>{
            //Se o campo não tiver sido marcado 
            //anteriormente como invalido por uma regra.
            if (!validacao[regra.campo].isInvalid) {
                //Determina o valor do campo, o método a ser invocado
                //e os argumentos opcionais pela definição da regra
            //converto p string pq a lib validator eh strings only
            const campoValor = state[regra.campo.toString()];
            const args = regra.args || [];
                //if ternário para estar preparado caso 
                //alguém passe o método direto sem ser string
            const metodoValidacao = typeof regra.metodo === 'string' ? 
                validador[regra.metodo] : regra.metodo;

            //invoca o método específico da regra
            //metodoValidacao eh da lib validator.js. 
            //2º param - array opcional de config opcionais, argumentos opcionais do metodo
            //param 3 - state atual da app
            if(metodoValidacao(campoValor, ...args, state) !== regra.validoQuando){
                //modifica o objeto no campo específico
                validacao[regra.campo] ={
                    isInvalid: true,
                    message: regra.mensagem
                }

                validacao.isValid = false;
                
            } 
        }
        });
        console.log('chamou a validacao do form');  
        return validacao;
                      
    }

    //vai retornar um gde objeto, gde elemento, q vou devolver para o meu formulario dizendo se eh valido ou n.
    //vou pegar todas as info de validação, ja q agora tenho um array e devolver um objeto mais estruturado para o meu formulario
    //para ele saber trabalhar c isso

    /*
    O método valido é utilizado para a criação do objeto que enviaremos para o componente Formulário. Por definição, ele assume que todos os campos são válidos. Esse objeto gerado é alterado pelo método valida caso algum campo esteja inválido e então enviado para o componente Formulario
    */
    valido(){
        // cara q vai ser modificado dentro dele
        const validacao ={       }

        //populando o objeto de acordo com a quantidade de campos
    //criando a chave isInvalid e atribuindo false para cada
    //**TODOS OS CAMPOS COMEÇAM VÁLIDOS!**
        this.validacoes.map(regra => (
            validacao[regra.campo] = {isInvalid: false, message: ''}
        ));        
        //retorna um grande objeto com uma chave externa isValid 
    //junto com todos os outros campos.
    /*
    Para ficar mais claro, a estrutura do objeto retornado é:

{
isValid: true,
nome: { isInvalid: false, message: '' },
livro: { isInvalid: false, message: '' },
preco: { isInvalid: false, message: ''}
}
*/
        return {isValid: true, ...validacao};


    }
}

export default FormValidator;