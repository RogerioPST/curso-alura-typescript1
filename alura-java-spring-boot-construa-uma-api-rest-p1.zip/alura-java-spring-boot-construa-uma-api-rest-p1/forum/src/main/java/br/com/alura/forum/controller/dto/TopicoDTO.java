package br.com.alura.forum.controller.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import br.com.alura.forum.modelo.Topico;

//UM DTO só precisa dos getters
public class TopicoDTO {
	private Long id;
	private String titulo;
	private String mensagem;
	private LocalDateTime dataCriacao;

	public TopicoDTO(Topico topico) {
		this.id = topico.getId();
		this.titulo = topico.getTitulo();
		this.mensagem = topico.getMensagem();
		this.dataCriacao = topico.getDataCriacao();
	}

	public Long getId() {
		return id;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getMensagem() {
		return mensagem;
	}

	public LocalDateTime getDataCriacao() {
		return dataCriacao;
	}

	public static List<TopicoDTO> converter(List<Topico> topicos) {
		// return topicos.stream().map(TopicoDTO::new).collect(Collectors.toList()); //java 8
		// sem java 8, como abaixo, teria q pegar essa lista de topicos, fazer um for e para cada
		// topico, dar new no TopicoDTO, guardar em uma lista de TopicoDTO e devolver
		// uma lista de TopicoDTO
		List<TopicoDTO> topicosDTO = new ArrayList<TopicoDTO>();
		for (Topico topico : topicos) {
			topicosDTO.add(new TopicoDTO(topico));
		}
		return topicosDTO;

	}

}
