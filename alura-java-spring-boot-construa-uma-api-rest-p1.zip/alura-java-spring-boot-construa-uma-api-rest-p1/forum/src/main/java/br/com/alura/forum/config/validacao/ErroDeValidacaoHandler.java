package br.com.alura.forum.config.validacao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/*
 * O Spring tem uma solução para esse tipo de cenário. A solução é criar um interceptador. Toda vez que acontecer uma exception, em qualquer método, o Spring automaticamente vai chamar esse interceptador, onde fazemos o tratamento apropriado. Esse interceptador é chamado de controller advice. A ideia é criarmos uma classe e transformá-la em um controller advice, onde vamos fazer o tratamento do erro.

[01:48] Precisamos criar uma nova classe do projeto. Mas vou colocar em um pacote config.validacao, porque depois teremos outras configurações no projeto. Vamos chamar essa classe de “errodevalidacaohandler”. Vai ser a classe que vai tratar os erros de validação.

[02:23] Agora preciso dizer para o Spring que essa classe é um controller advice. Existe a anotação @RestControllerAdvice, porque estamos usando REST controllers. Agora, precisamos ensinar para o Spring que esse controller advice vai fazer tratamentos de erros, para quando tiver uma exceção.
 */
@RestControllerAdvice
public class ErroDeValidacaoHandler {

	@Autowired
	private MessageSource messageSource;

	/*
	 * Precisamos criar um método. E preciso dizer para o Spring que esse método
	 * deve ser chamado quando houver uma exceção dentro de algum controller. Para
	 * falar isso para o Spring, em cima do método vamos colocar uma anotação. E
	 * temos que passar para o parâmetro que tipo de exceção que quando acontecer
	 * dentro do controller o Spring vai direcionar para o método. No nosso caso, é
	 * exceção de validação de formulário. Quando dá um erro de validação de
	 * formulário, que exceção que o Spring lança? Uma exception chamada
	 * MethodArgumentNotValidException. Temos que passar o nome da classe. Agora o
	 * Spring sabe que se acontecer essa execption em qualquer REST controller, ele
	 * vai cair nesse método.
	 * 
	 * [04:05] Nesse método, preciso pegar a exceção que aconteceu, para pegar as
	 * mensagens, fazer o tratamento. Esse método recebe como parâmetro um objeto do
	 * tipo MethodArgumentNotValidException, que é o mesmo handler que estou
	 * utilizando.
	 * 
	 * [04:32] Toda vez que acontecer alguma exception desse tipo em qualquer REST
	 * Controller do projeto, o Spring vai chamar esse método handle passando como
	 * parâmetro a exception que aconteceu. Ele considera que deu um erro, mas que
	 * não vai devolver o 400 para o cliente. Ele vai chamar o interceptador, e aqui
	 * dentro você está fazendo o tratamento. Ele considera que fizemos o tratamento
	 * e por padrão vai devolver 200 para o cliente. Mas não quero isso, quero que
	 * ele devolva 400.
	 * 
	 * [05:20] Por mais que eu tenha tratado o erro, não é para devolver 200. É para
	 * continuar devolvendo 400, porque meu tratamento é só para mudar as mensagens.
	 * Agora, aqui dentro faço o tratamento.
	 * 
	 * [05:33] Só que o Spring, além de devolver o @ResponseStatus, devolve o que o
	 * método estiver retornando. Nosso método não pode ser void. Ele tem que
	 * devolver alguma coisa, que no nosso caso vai ser uma lista com as mensagens
	 * de erro. Mas ao invés de ser aquela mensagem bizarra, vai ser uma mensagem
	 * que nós vamos personalizar.
	 * 
	 * [05:55] Esse método vai devolver um list. Para representar o erro, vou criar
	 * um novo dto que serve para representar um erro de formulário. Vou criar uma
	 * classe chamada ErroDeFormulario, por exemplo. Essa classe não existe, então
	 * vou criar. Essa classe que vai representar um erro de validação. O JSON, que
	 * vai ser devolvido para o cliente, não vai ser mais aquele maluco do Spring.
	 * Vai ser o JSON representado por essa classe.
	 */
	@ResponseStatus(code = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public List<ErroDeFormularioDTO> handle(MethodArgumentNotValidException exception) {
		/*
		 * Voltando ao nosso handler, esse que vai ser o retorno, ele vai devolver uma
		 * lista com cada um dos erros que aconteceram.
		 * 
		 * [08:02] Como eu descubro que erros aconteceram? Por isso o método recebe o
		 * tal do MethodArgumentNotValidException. Dentro desse objeto tem todos os
		 * erros que aconteceram.
		 * 
		 * [08:41] Essa variável tem os erros de formulário. Só que não quero devolver
		 * essa lista de field. Quero devolver uma lista de erro formulário dto. Então
		 * preciso criar uma lista de erro de formulário dto. O que vou devolver nesse
		 * método é justamente o dto. Estou devolvendo uma lista de erro de formulário
		 * dto. Só que no momento essa lista está vazia.
		 * 
		 * [09:24] Eu vou ter que percorrer para cada fiel error criar um objeto erro
		 * dto e guardar nessa lista representada pela minha variável dto. Só que aí vou
		 * usar os recursos do Java8.
		 * 
		 * [10:00] Lembre-se que quando eu dou um new, tenho que passar uma mensagem e
		 * qual o campo que deu erro. O campo pego pelo e-getField(). Agora, para pegar
		 * a mensagem, até porque podemos ter aquele esquema de internacionalização, com
		 * vários idiomas, o Spring nos ajuda com uma classe chamada messagesource. Vou
		 * injetar nessa classe handler um atributo do tipo messagesource. Essa classe
		 * te ajuda a pegar mensagens de erro, de acordo com o idioma que o cliente
		 * requisitar.
		 * 
		 * [11:15] Para pegar mensagens de erro. Falta só pegar o dto, que é minha lista
		 * de erros, e adicionar essa mensagem de erro. Essa vai ser a lógica do nosso
		 * handler. É um pouco estranha, mas a ideia do handler é justamente isso. Pense
		 * que o handler é um interceptador, em que estou configurando a Spring, para
		 * que sempre que houver um erro, alguma exception em algum método de qualquer
		 * controller, ele chama automaticamente esse interceptador, passando o erro que
		 * aconteceu.
		 * 
		 * [12:33] Pronto. É só isso. Você só precisa criar esse handler. Você não
		 * precisa mexer nos controllers. Automaticamente o Spring sabe que é para
		 * chamar esse erro em qualquer controller quando houver um erro de validação.
		 */
		List<ErroDeFormularioDTO> dto = new ArrayList<ErroDeFormularioDTO>();
		List<FieldError> fieldErrors = exception.getBindingResult().getFieldErrors();
		fieldErrors.forEach(e -> {
			/*
			 * Podemos adicionar outro cabeçalho. Existe um chamado accept:language, para
			 * dizermos qual é a linguagem que nós aceitamos como resposta. Nele, posso
			 * passar em-US, para dizer que é em inglês americano.
			 * 
			 * [14:08] Se eu mandar isso, o Spring detecta que o cabeçalho está vindo, e por
			 * causa da classe LocaleContextHolder, ele sabe que é para pegar as mensagens
			 * em inglês.
			 */
			String mensagem = messageSource.getMessage(e, LocaleContextHolder.getLocale());
			ErroDeFormularioDTO erro = new ErroDeFormularioDTO(e.getField(), mensagem);
			dto.add(erro);
		});

		return dto;

	}

}
