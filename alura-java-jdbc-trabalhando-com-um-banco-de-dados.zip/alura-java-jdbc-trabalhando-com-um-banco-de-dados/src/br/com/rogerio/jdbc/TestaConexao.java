package br.com.rogerio.jdbc;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;

public class TestaConexao {
	public static void main(String[] args) throws SQLException {
		// o drivermanager escolhe uma conexao que vai permitir conectar com o banco
		Connection connection = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/loja-virtual", "SA", "");
		//ou Connection connection = Database.getConnection();
		System.out.println("abrindo uma conexao");
		//connection.execute("select * from produto");
		connection.close();

	}
}
