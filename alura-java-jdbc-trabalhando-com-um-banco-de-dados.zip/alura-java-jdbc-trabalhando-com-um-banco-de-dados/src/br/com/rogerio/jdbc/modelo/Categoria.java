package br.com.rogerio.jdbc.modelo;

import java.util.ArrayList;
import java.util.List;

import br.com.rogerio.modelo.Produto;

public class Categoria {

	private final int id;
	private final String nome;
	private final List<Produto> produtos = new ArrayList<>();

	public Categoria(int id, String nome) {
		this.id = id;
		this.nome = nome;

	}

	public int getId() {
		return id;
	}

	

	public String getNome() {
		return nome;
	}

	public void adiciona(Produto p) {
		// TODO Auto-generated method stub
		getProdutos().add(p);
		
	}

	public List<Produto> getProdutos() {
		return produtos;
	}

	


}
