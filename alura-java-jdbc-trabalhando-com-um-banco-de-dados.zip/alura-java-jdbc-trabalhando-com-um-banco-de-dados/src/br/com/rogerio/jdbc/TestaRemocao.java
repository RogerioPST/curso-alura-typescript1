package br.com.rogerio.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class TestaRemocao {
	public static void main(String[] args) throws SQLException {
		ConnectionPool connectionPool = new ConnectionPool();
		for (int i = 0; i < 100; i++) {
			// nessa linha abaixo, s�o abertos 100 objetos conexoes. sem reaproveitamento
			// Connection connection = new ConnectionPool().getConnection();
			// nessa linha abaixo, s�o abertas 100 conexoes e um unico pool. com reaproveitamento
			Connection connection = connectionPool.getConnection();
			Statement stmt = connection.createStatement();
			String sql = "delete from Produto where id > 3 ";
			stmt.execute(sql);

			int count = stmt.getUpdateCount();

			System.out.println(count + " linhas atualizadas");

			stmt.close();
			connection.close();
		}
	}

}
