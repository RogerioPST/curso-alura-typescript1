package br.com.rogerio.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestaListagem {
	public static void main(String[] args) throws SQLException {
		ConnectionPool database = new ConnectionPool();
		for (int i = 0; i < 100; i++) {

			Connection connection = database.getConnection();
			// statement = afirmacao
			Statement statement = connection.createStatement();
			// resultado vai devolver true, se for uma lista de dados
			// se n for, devolve false
			boolean resultado = statement.execute("select * from Produto");
			System.out.println(resultado);
			ResultSet resultSet = statement.getResultSet();
			while (resultSet.next()) {
				int id = resultSet.getInt("id");
				System.out.println(id);
				String nome = resultSet.getString("nome");
				System.out.println(nome);
				String descricao = resultSet.getString("descricao");
				System.out.println(descricao);

			}
			resultSet.close();
			statement.close();
			//qdo uso o pool, qdo fecha  a conexao, devolve p o pool e reutiliza
			connection.close();
		}
	}
}
