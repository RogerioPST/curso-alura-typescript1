package br.com.rogerio.jdbc.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.rogerio.jdbc.ConnectionPool;
import br.com.rogerio.jdbc.ProdutosDAO;
import br.com.rogerio.modelo.Produto;

public class TestaDAODeProduto {
	public static void main(String[] args) throws SQLException {
		
		Produto mesa = new Produto("Mesa Azul", "mesa com 4 pes");
		
		try(Connection con = new ConnectionPool().getConnection()){
			ProdutosDAO dao = new ProdutosDAO(con);
			dao.salva(mesa);
			
			List<Produto> produtos = dao.lista();
			
			for (Produto produto: produtos) {
				System.out.println("existe o produto: " + produto);
				
			}
		}
		
		//System.out.println("a mesa foi inserida com sucesso: " + mesa);
	}

	
	}
	


