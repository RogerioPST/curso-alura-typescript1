package br.com.alura.gerenciador.servlet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Banco {

	private static List<Empresa> empresas = new ArrayList<>();
	private static Integer chaveSequencial = 1;

	// metodo static executa qdo a classe eh carregada por padrao
	/*
	 * Para resolvermos essa quest�o, adicionaremos um bloco est�tico de empresas na
	 * classe Banco. Assim como existem atributos est�ticos, podemos criar c�digos
	 * est�ticos. O c�digo est�tico que criaremos ser� executado quando a m�quina
	 * virtual carregar a classe e a lista de empresas for inicializada. Neste
	 * ponto, ser�o cadastradas duas empresas nessa lista: Alura e Caelum.
	 * 
	 */
	static {
		Empresa empresa = new Empresa();
		empresa.setId(chaveSequencial++);
		empresa.setNome("Alura");
		Empresa empresa2 = new Empresa();
		empresa2.setId(chaveSequencial++);
		empresa2.setNome("Caelum");
		empresas.add(empresa);
		empresas.add(empresa2);
	}

	public void adiciona(Empresa empresa) {
		empresa.setId(chaveSequencial++);
		empresas.add(empresa);
	}

	public List<Empresa> getEmpresas() {
		return Banco.empresas;
	}

	public void apaga(int id) {

		Iterator<Empresa> it = empresas.iterator();

		while (it.hasNext()) {
			Empresa emp = it.next();
			if (emp.getId() == id) {
				it.remove();
			}
		}

		// qdo se tenta modificar uma lista enquanto se est� percorrendo, dah erro de
		// concurrentmodification como o codigo abaixo

//		for (Empresa empresa : empresas) {
//			if(empresa.getId() == id){
//				empresas.remove();
//			}
//			
//			
//		}

	}

	public Empresa buscaEmpresaPeloId(int id) throws IdNaoExisteException {
		for (Empresa empresa : empresas) {
			if(empresa.getId() == id){
				return empresa;
			}
		}
		throw new IdNaoExisteException("id n existe no banco");
		//return null;

		
	}

	public void altera(Empresa empresa) {
		// TODO Auto-generated method stub
		
	}
}
