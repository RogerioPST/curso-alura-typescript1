package br.com.alura.gerenciador.servlet;

public class IdNaoExisteException extends Exception {
	
	public IdNaoExisteException(String msg) {
		super(msg);
	}

}
