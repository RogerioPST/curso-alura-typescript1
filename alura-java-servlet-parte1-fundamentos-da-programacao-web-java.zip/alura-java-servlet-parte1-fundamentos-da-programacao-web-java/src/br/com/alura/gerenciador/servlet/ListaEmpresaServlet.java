package br.com.alura.gerenciador.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NovaEmpresaServlet
 */
@WebServlet("/listaEmpresas")
public class ListaEmpresaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
						
		Banco lista = new Banco();
		
		System.out.println("listando empresas: " );
		
		request.setAttribute("empresas", lista.getEmpresas());
		RequestDispatcher rd = request.getRequestDispatcher("listaEmpresas.jsp");
		rd.forward(request, response);
		
		
				
//		PrintWriter out = response.getWriter();
//		
//		out.println("<html>");
//		out.println("<body>");
//		out.println("<ul>");
//		for (Empresa empresa : lista.getEmpresas()) {
//			out.println("<li>empresa cadastrada: " + empresa.getNome() + "</li>");
//		}
//		out.println("</ul>");
//		out.println("</html>");
//		
	}

}
