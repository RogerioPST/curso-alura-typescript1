package br.com.alura.gerenciador.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NovaEmpresaServlet
 */
@WebServlet("/alteraEmpresa")
public class AlteraEmpresaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String paramId = request.getParameter("id");

		int id = Integer.parseInt(paramId);

		String nome = request.getParameter("nome");
		String dataEmpresa = request.getParameter("data");
		Date dataAbertura = null;

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			dataAbertura = sdf.parse(dataEmpresa);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServletException(e);
		}

		System.out.println("alterando empresa: " + nome);

		Banco banco = new Banco();

		Empresa empresa;
		try {
			empresa = banco.buscaEmpresaPeloId(id);
			empresa.setNome(nome);
			empresa.setDataAbertura(dataAbertura);

			//banco.altera(empresa);

//		PrintWriter out = response.getWriter();
//		out.println("<html>");
//		out.println("<body>");
//		out.println("empresa cadastrada: " + nome);
//		out.println("</html>");
			request.setAttribute("empresa", empresa.getNome());
			/*
			 * Nessa aula aprendemos: o problema de reenviar uma requisi��o a diferen�a
			 * entre redirecionamento pelo cliente e servidor para redirecionar pelo
			 * navegador usamos o m�todo response.sendRedirect("endere�o") o c�digo de
			 * resposta para redirecionamento HTTP � 30X (301 ou 302)
			 * 
			 */
			response.sendRedirect("listaEmpresas");

//		RequestDispatcher rd = request.getRequestDispatcher("/listaEmpresas");
//		request.setAttribute("empresa", empresa.getNome());
//		rd.forward(request, response);
		} catch (IdNaoExisteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
