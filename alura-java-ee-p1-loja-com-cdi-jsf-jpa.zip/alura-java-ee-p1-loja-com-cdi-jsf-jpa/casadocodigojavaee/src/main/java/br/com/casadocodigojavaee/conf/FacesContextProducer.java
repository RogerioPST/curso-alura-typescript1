package br.com.casadocodigojavaee.conf;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Produces;
import javax.faces.context.FacesContext;

//como o cdi n sabe injetar esse FacesContext, essa classe faz c q consigamos usar @inject
public class FacesContextProducer {
	
	@RequestScoped
	@Produces
	public FacesContext getFacesContext() {
		return FacesContext.getCurrentInstance();
	}

}
