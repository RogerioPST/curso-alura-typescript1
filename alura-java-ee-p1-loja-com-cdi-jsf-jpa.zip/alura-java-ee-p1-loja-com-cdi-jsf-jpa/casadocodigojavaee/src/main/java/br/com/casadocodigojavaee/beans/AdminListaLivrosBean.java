package br.com.casadocodigojavaee.beans;

import java.util.ArrayList;
import java.util.List;

import javax.enterprise.inject.Model;
import javax.inject.Inject;

import br.com.casadocodigojavaee.daos.LivroDao;
import br.com.casadocodigojavaee.models.Livro;

@Model //essa anotacao do CDI ja engloba RequestScoped e Named
public class AdminListaLivrosBean {
	
	@Inject
	private LivroDao dao;
	
	private List<Livro> livros = new ArrayList<>();

	public List<Livro> getLivros() {
		
		this.livros = dao.listar();
		return livros;
	}

	

}
