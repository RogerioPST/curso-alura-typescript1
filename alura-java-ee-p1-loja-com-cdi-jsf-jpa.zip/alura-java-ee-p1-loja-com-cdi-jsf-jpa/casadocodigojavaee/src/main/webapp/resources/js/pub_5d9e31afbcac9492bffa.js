// Last edit: Thu, 11 Feb 16 19:13:19 -0500
_rfsn_tracker.load_settings({
	version : 2.0,
	base_url : 'https://casadocodigo.refersion.com/',
	xdomains: [],
	verbose: false,
	is_loaded: true
})
