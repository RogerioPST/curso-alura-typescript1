#include <stdio.h>
#include <string.h>
void abertura() {
    printf("/****************/\n");
    printf("/ Jogo de Forca */\n");
    printf("/****************/\n\n");
}

//declarando um ponteiro - int* tentativas
void chuta(char chutes[26], int* tentativas){
    char chute;
        //precisa dar espaço %c toda vez q for ler um char no scanf, 
        //pq o enter fica no buffer
        //o enter pode ser um char digitado e o compilador se perde um pouco.
        scanf(" %c", &chute);


        //(*tentativas) - pega o conteudo do ponteiro
        chutes[(*tentativas)] = chute;
        (*tentativas)++;
        

        //enquanto n encontrar o caracter \0, a funcao strlen conta a qtd de caracteres
       // for (int i=0; i< strlen(palavrasecreta); i++){
         //   if (palavrasecreta[i] == chute){
           //     printf("a posicao %d tem essa letra %c!\n", i, chute);
            //}
        //}    
}

int jachutou(char letra, char chutes[26], int tentativas){
     int achou =0;
           // printf("estou vendo a letra secreta %d = %c\n",i, letra);
            for (int j=0; j< tentativas; j++){
               // printf("-> chute %d = %c\n",j, chutes[j]);
                if (chutes[j] == letra){
               //     printf("------> chute correto \n");
                    achou =1;
                    break;
                }
            }  
            return achou;
}


void desenhaForca(char palavrasecreta[20], char chutes[26], int tentativas){
     //imprime a palavra secreta
        //enquanto n encontrar o caracter \0, a funcao strlen conta a qtd de caracteres
        for (int i=0; i< strlen(palavrasecreta); i++){    
           
            int achou = jachutou(palavrasecreta[i], chutes, tentativas);


            if (achou){
                printf("%c ", palavrasecreta[i]);
            }else{
                printf("_");            
            }
        }

        printf("\n");
}

void escolhePalavraSecreta(char palavrasecreta[20]){
    // colocando o \0 para indicar que a string acabou
    sprintf(palavrasecreta, "MELANCIA"); //vai colocar a string melancia na variavel palavrasecreta

}

int main(){
    //Que se guardamos uma string em um array de char, o caractere \0 deve ser colocado ao fim da palavra.
    char letra1 = 'A';
    char letra2 = 'S';
    printf("%c%c\n", letra1, letra2);

    int notas[10];
    char palavrasecreta[20];
    int acertou = 0;
    int enforcou = 0;
    char chutes[26];
    int tentativas =0;

                        //chutes - array jah eh um ponteiro e guarda o mesmo endereço de memoria q o 1º indice do array
                        //&chutes[0] e chutes tem o mesmo valor de endereco de memoria
                        printf("%d %d\n", &chutes[0], chutes);
                        //1º indice do array guarda o endereco de memoria
                        //2º indice guarda o endereco de memoria do primeiro + o numero de bytes que o tipo do array possui
                        //, no caso char eh um byte || int eh de 4 em 4 bytes
                        //e assim por diante
                        printf("%d %d %d\n", &chutes[0], &chutes[1], &chutes[2]);

    
    escolhePalavraSecreta(palavrasecreta);    

    abertura();

    do{
       desenhaForca(palavrasecreta, chutes, tentativas);
        //&tentativas - passa o endereço de memoria
        chuta(chutes, &tentativas);                

    } while(!acertou && !enforcou);

    // colocando o \0 para indicar que a string acabou
    //imprime enquanto n encontrar o caracter \0
    //qdo encontra o caracter \0, sabe que eh o final da string e para de imprimir.
    //printf("%s", palavrasecreta);
    

}