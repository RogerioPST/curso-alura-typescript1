#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "forca.h"


char palavrasecreta[TAMANHO_PALAVRA];
char chutes[26];
int chutesdados = 0;


void abertura() {
    printf("/****************/\n");
    printf("/ Jogo de Forca */\n");
    printf("/****************/\n\n");
}

//declarando um ponteiro - int* tentativas
void chuta(){
    char chute;
        //precisa dar espaço %c toda vez q for ler um char no scanf, 
        //pq o enter fica no buffer
        //o enter pode ser um char digitado e o compilador se perde um pouco.
        scanf(" %c", &chute);


        //(*tentativas) - pega o conteudo do ponteiro
        chutes[chutesdados] = chute;
        chutesdados++;
        

        //enquanto n encontrar o caracter \0, a funcao strlen conta a qtd de caracteres
       // for (int i=0; i< strlen(palavrasecreta); i++){
         //   if (palavrasecreta[i] == chute){
           //     printf("a posicao %d tem essa letra %c!\n", i, chute);
            //}
        //}    
}




void desenhaForca(){
    int erros = chuteserrados();

    printf("  _______       \n");
    printf(" |/      |      \n");
    printf(" |      %c%c%c  \n", (erros>=1?'(':' '), 
        (erros>=1?'_':' '), (erros>=1?')':' ')); //if ternario
    printf(" |      %c%c%c  \n", (erros>=3?'\\':' '), 
        (erros>=2?'|':' '), (erros>=3?'/': ' '));
    printf(" |       %c     \n", (erros>=2?'|':' '));
    printf(" |      %c %c   \n", (erros>=4?'/':' '), 
        (erros>=4?'\\':' '));
    printf(" |              \n");
    printf("_|___           \n");
    printf("\n\n");

     //imprime a palavra secreta
        //enquanto n encontrar o caracter \0, a funcao strlen conta a qtd de caracteres
        for (int i=0; i< strlen(palavrasecreta); i++){    
           
            int achou = jachutou(palavrasecreta[i]);


            if (achou){
                printf("%c ", palavrasecreta[i]);
            }else{
                printf("_");            
            }
        }

        printf("\n");
}

void adicionapalavra() {
    char quer;

    printf("Você deseja adicionar uma nova palavra no jogo (S/N)?");
    scanf(" %c", &quer);

    if(quer == 'S') {
        char novapalavra[TAMANHO_PALAVRA];

        printf("Digite a nova palavra, em letras maiúsculas: ");
        scanf("%s", novapalavra);

        // agora falta salvar no arquivo
        FILE* f;

    // abre arquivo
    f = fopen("palavras.txt", "r+"); //r+ -ler e escrever
    if(f == 0) {
        printf("Banco de dados de palavras não disponível\n\n");
        exit(1);
    }

    int qtd;
    fscanf(f, "%d", &qtd);
    qtd++;

    //posiciona a cabeca de leitura
    fseek(f, 0, SEEK_SET);
    fprintf(f, "%d", qtd);

    fseek(f, 0, SEEK_END);
    fprintf(f, "\n%s", novapalavra);    

    // fecha
    fclose(f);

}
 

}

void escolhePalavraSecreta(){
    // colocando o \0 para indicar que a string acabou
    //sprintf(palavrasecreta, "MELANCIA"); //vai colocar a string melancia na variavel palavrasecreta
    FILE* f;
    f = fopen("palavras.txt", "r");
    if (f == 0){
        printf("desculpe. banco de dados n disponivel\n\n");
        exit(1);
    }

    int qtddepalavras;
    //no nosso padrao, na primeira linha do arquivo palavras.txt, vai ter o numero de palavras do arquivo
    //por isso, uso como abaixo fscanf    
    fscanf(f, "%d", &qtddepalavras); 
    srand(time(0));
    int randomico = rand() % qtddepalavras;

    for (int j=0; j< randomico; j++){
        fscanf(f, "%s", palavrasecreta);
    }

    fclose(f);
}

int acertou(){
    for (int j=0; j< strlen(palavrasecreta); j++){
        if(!jachutou(palavrasecreta[j])){
            return 0;
        }
    }
    return 1;
}
// extraímos pra cá o pedaço daquela função 
// que contava a quantidade de erros
int chuteserrados() {
    int erros = 0;

    for(int i = 0; i < chutesdados; i++) {

        int existe = 0;

        for(int j = 0; j < strlen(palavrasecreta); j++) {
            if(chutes[i] == palavrasecreta[j]) {
                existe = 1;
                break;
            }
        }

        if(!existe) erros++;
    }

    return erros;
}

int enforcou(){
  // usamos a função que acabamos de criar
    return chuteserrados() >= 5;
}

int jachutou(char letra){
     int achou =0;
           // printf("estou vendo a letra secreta %d = %c\n",i, letra);
            for (int j=0; j< chutesdados; j++){
               // printf("-> chute %d = %c\n",j, chutes[j]);
                if (chutes[j] == letra){
               //     printf("------> chute correto \n");
                    achou =1;
                    break;
                }
            }  
            return achou;
}

int main(){
    //Que se guardamos uma string em um array de char, o caractere \0 deve ser colocado ao fim da palavra.
    char letra1 = 'A';
    char letra2 = 'S';
    printf("%c%c\n", letra1, letra2);

    int notas[10];
    char palavrasecreta[TAMANHO_PALAVRA];
    //int acertou = 0;
    //int enforcou = 0;
    char chutes[26];
    int tentativas =0;

                        //chutes - array jah eh um ponteiro e guarda o mesmo endereço de memoria q o 1º indice do array
                        //&chutes[0] e chutes tem o mesmo valor de endereco de memoria
                        printf("%d %d\n", &chutes[0], chutes);
                        //1º indice do array guarda o endereco de memoria
                        //2º indice guarda o endereco de memoria do primeiro + o numero de bytes que o tipo do array possui
                        //, no caso char eh um byte || int eh de 4 em 4 bytes
                        //e assim por diante
                        printf("%d %d %d\n", &chutes[0], &chutes[1], &chutes[2]);

    
    escolhePalavraSecreta();    

    abertura();

    do{
       desenhaForca();
        //&tentativas - passa o endereço de memoria
        chuta();                

    } while(!acertou() && !enforcou());

    if(acertou()) {
    printf("\nParabéns, você ganhou!\n\n");

    printf("       ___________      \n");
    printf("      '._==_==_=_.'     \n");
    printf("      .-\\:      /-.    \n");
    printf("     | (|:.     |) |    \n");
    printf("      '-|:.     |-'     \n");
    printf("        \\::.    /      \n");
    printf("         '::. .'        \n");
    printf("           ) (          \n");
    printf("         _.' '._        \n");
    printf("        '-------'       \n\n");

} else {
    printf("\nPuxa, você foi enforcado!\n");
    printf("A palavra era **%s**\n\n", palavrasecreta);

    printf("    _______________         \n");
    printf("   /               \\       \n"); 
    printf("  /                 \\      \n");
    printf("//                   \\/\\  \n");
    printf("\\|   XXXX     XXXX   | /   \n");
    printf(" |   XXXX     XXXX   |/     \n");
    printf(" |   XXX       XXX   |      \n");
    printf(" |                   |      \n");
    printf(" \\__      XXX      __/     \n");
    printf("   |\\     XXX     /|       \n");
    printf("   | |           | |        \n");
    printf("   | I I I I I I I |        \n");
    printf("   |  I I I I I I  |        \n");
    printf("   \\_             _/       \n");
    printf("     \\_         _/         \n");
    printf("       \\_______/           \n");
}

    // colocando o \0 para indicar que a string acabou
    //imprime enquanto n encontrar o caracter \0
    //qdo encontra o caracter \0, sabe que eh o final da string e para de imprimir.
    //printf("%s", palavrasecreta);

    adicionapalavra();
    

}