#define TAMANHO_PALAVRA 20
void abertura();
void chuta();
int jachutou(char letra);
void desenhaForca();
void escolhePalavraSecreta();
int acertou();
int enforcou();
void adicionapalavra();
int chuteserrados();