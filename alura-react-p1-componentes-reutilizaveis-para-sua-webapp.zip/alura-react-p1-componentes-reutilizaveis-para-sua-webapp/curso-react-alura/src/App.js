import React, { Component , Fragment} from 'react';
//webpack q permite importar svg, css dentro do arquivo javascript
//import logo from './logo.svg';
import './App.css';
import 'materialize-css/dist/css/materialize.min.css';
import Tabela from './Tabela';

import Form from './Formulario';
import Header from './Header';

/*
E só pra te orientar em relação as suas dúvidas, um function component também chamado de stateless component é utilizado quando vc quer construir um componente mais enxuto que nem terá estado ( por isso eu prefiro o termo stateless component em vez de function component ).

Já a questão da importação do React e do Component não diz respeito ao React em si e sim ao sistema de módulos do ES6, tema esse tratado nos cursos que são pré-requisitos para o curso de React! Dê uma olhada nesse link e veja se o tema fica claro pra vc!
*/
//babel q permite colocar xml, html (JSX) dentro do codigo javascript, pois babel eh um transpiler 
class App extends Component {

  //esse array nada mais eh do q o controle de estado da aplicacao, por isso, o state
  state = {
    autores: [
      {
        nome: 'Paulo',
        livro: 'React',
        preco: '1000'
      },
      {
        nome: 'Daniel',
        livro: 'Java',
        preco: '99'
      },
      {
        nome: 'Marcos',
        livro: 'Design',
        preco: '150'
      },
      {
        nome: 'Bruno',
        livro: 'DevOps',
        preco: '100'
      }
    ],
  };

  removeAutor = (index) => {
    const { autores } = this.state;
    //o State serve para armazenar estado/valores de um componente, portanto, esse State deve ser constantemente atualizado de acordo com a interação do usuário.

    //Porém, não devemos alterar esse objeto diretamente, devemos seguir a convenção do React para conseguirmos modificá-lo.
    //Devemos alterar/atualizar o state utilizando o método setState() do React.
    this.setState(
      {
        autores: autores.filter((autor, posAtual) => {
          console.log(index, posAtual)
          //qdo for diferente o index da posAtual, quero manter no array
          return posAtual !== index;
        }),
      }
    );
  }

  escutadorDeSubmit = autor =>{
    //utilizando spreadOperator
    this.setState({autores: [...this.state.autores, autor]})

  }

  render() {
    return (
      //usa o JSX para referenciar como se fosse uma tag
      //n se usa class, pq eh palavra reservada do javascript. <div className="teste">
      //n se usa for, pq eh palavra reservada tb. usa 'htmlFor'. <label htmlFor="livro">Livro</label>  
      //passo uma propriedade dando o nome q quero e o valor entre {}
      //usa Fragment, pois n se pode ter dois elementos raiz nas linguagens de marcacao
      <Fragment>
        <Header />
        <div className="container mb-10">        
        <Tabela autores={this.state.autores} removeAutor={this.removeAutor} />
        <Form escutadorDeSubmit = {this.escutadorDeSubmit}/>
        </div>
      </Fragment>
      
    );
  }
}

export default App;
