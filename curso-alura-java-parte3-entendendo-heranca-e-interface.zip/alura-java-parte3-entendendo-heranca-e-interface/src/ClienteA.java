
public class ClienteA implements Autenticavel {

	//composi��o - tem um Autenticador - para n duplicar codigo
	private Autenticador autenticadorUtil;

	public ClienteA() {
		// para evitar a repeti��o, delego a chamada e passo para o Autenticador
		this.autenticadorUtil = new Autenticador();
	}

	@Override
	public void setSenha(int senha) {
		// para evitar a repeti��o, delego a chamada e passo para o Autenticador chamar
		// o metodo setSenha
		this.autenticadorUtil.setSenha(senha);

	}

	@Override
	public boolean autentica(int senha) {
		// para evitar a repeti��o, delego a chamada e passo para o Autenticador (util)
		// chamar o metodo autentica
		return this.autenticadorUtil.autentica(senha);
	}

}
