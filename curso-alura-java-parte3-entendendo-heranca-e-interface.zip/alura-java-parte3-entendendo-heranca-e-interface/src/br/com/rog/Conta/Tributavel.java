package br.com.rog.Conta;

interface Tributavel {
	
	double getValorImposto();

}
