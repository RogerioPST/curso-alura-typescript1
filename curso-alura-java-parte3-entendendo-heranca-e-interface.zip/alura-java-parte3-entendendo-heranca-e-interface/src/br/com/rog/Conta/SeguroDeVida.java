package br.com.rog.Conta;

public class SeguroDeVida implements Tributavel{

	@Override
	public double getValorImposto() {
		// TODO Auto-generated method stub
		return 42;
	}
	
	

}
