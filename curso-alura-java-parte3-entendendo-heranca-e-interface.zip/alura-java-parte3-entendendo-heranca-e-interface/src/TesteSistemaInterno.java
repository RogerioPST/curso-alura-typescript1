
public class TesteSistemaInterno {
	public static void main(String[] args) {
		Gerente g = new Gerente();
		
		g.setSenha(2222);
		Administrador ad = new Administrador();
		ad.setSenha(3333);
		
		ClienteA c = new ClienteA();
		c.setSenha(5555);
		
		SistemaInterno si = new SistemaInterno();
		si.autentica(g);
		si.autentica(ad);
		si.autentica(c);
	}
}
