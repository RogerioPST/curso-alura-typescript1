
public class TesteGerente {
	public static void main(String[] args) {
		Autenticavel referencia = new Gerente();
		
		
		Gerente nico = new Gerente();
		nico.setNome("Marco Stepat");
		nico.setSalario(2500);
		nico.setCpf("32030210245");
		
		nico.setSenha(2222);
		
		
		
		System.out.println(nico.getNome());
		System.out.println(nico.getBonificacao());
		System.out.println(nico.autentica(2222));
	}
}
