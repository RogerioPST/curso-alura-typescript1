
public class Administrador extends Funcionario implements Autenticavel{
	
	//composi��o - tem um Autenticador - para n duplicar codigo
	private Autenticador autenticadorUtil;
	
	public Administrador() {
		this.autenticadorUtil = new Autenticador();
	}
	
	@Override
	public boolean autentica(int senha) {
		return this.autenticadorUtil.autentica(senha)	;
	}
	
	public double getBonificacao() {
		System.out.println("chamando bonif do administrador");
		return 50;
	}	

	@Override
	public void setSenha(int senha) {
		this.autenticadorUtil.setSenha(senha);
	}	


}
