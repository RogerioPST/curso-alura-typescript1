

// eh uma classe abstrata com todos os metodos abstratos
//uma interface n pode ter nada concreto 
//contrato Autenticavel que define obriga��es
//quem (a classe) assina esse contrato, precisa implementar o metodo setSenha e autentica
public interface Autenticavel {
	
	public abstract void setSenha(int senha);
	
	public abstract boolean autentica(int senha);

}
