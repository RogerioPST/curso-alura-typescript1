
public class Autenticador {
	
	private int senha;
	
	
	public void setSenha(int senha) {
		this.senha = senha;
		
		
	}

	
	public boolean autentica(int senha) {
		// TODO Auto-generated method stub
		if (this.senha == senha) {
			return true;
		}
		return false;
	}
}
