
public class EditorVideo extends Funcionario{
	
	
	
	
	public double getBonificacao() {
		System.out.println("chamando bonif do editor de video");
		return 100;
	}



}
