
public class TesteFuncionario {
	public static void main(String[] args) {
		Funcionario nico = new Gerente();
		nico.setNome("Nico Stepat");
		nico.setSalario(2500);
		nico.setCpf("32030210245");
		
		System.out.println(nico.getNome());
		System.out.println(nico.getBonificacao());
	}
}
