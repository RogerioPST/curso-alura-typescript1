import { Component, OnInit, OnDestroy, Output, EventEmitter, Input } from "@angular/core";
import { Subject } from "rxjs";
import {debounceTime} from 'rxjs/operators';

@Component({
    selector : 'alurapic-search',
    templateUrl: './search.component.html'
})
export class SearchComponent implements OnInit, OnDestroy{
    // como eu vou jogar so valor de texto, uso o generics de string
    //assim vou conseguir capturar do photo-list.component.html o evento criado por mim aoDigitar.
    @Output() aoDigitar = new EventEmitter<string>();
    @Input() value = '';
    debounce: Subject<string> = new Subject<string>();

    ngOnInit() : void{   
    // so vai disparar o subscribe qdo eu parar 300 milisegundos         
    this.debounce
        .pipe(debounceTime(300))
        .subscribe(filter => this.aoDigitar.emit(filter));
    }

    ngOnDestroy(): void{
        // para n dar leak de memoria. memory leak!
        this.debounce.unsubscribe();
    }

}