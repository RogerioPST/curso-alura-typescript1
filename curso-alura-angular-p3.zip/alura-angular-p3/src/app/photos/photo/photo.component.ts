import { Component, Input } from "@angular/core";

const CLOUD = "http://localhost:3000/imgs/";

@Component({
    selector: 'alurapic-photo',
    templateUrl: 'photo.component.html'
})
export class PhotoComponent{

  private _url = '';

  @Input() alt = '';

  // posso fazer uma inbound property p um setter e aih eu posso aplicar uma logica 
  // no momento q eu estiver atribuindo esse valor
  @Input() set url(url : string) {
    if (!url.startsWith('data')){
      this._url = CLOUD + url;

    }
    else{
      this._url = url;
    }
    
  }
  get url(){
    return this._url;
  }

}