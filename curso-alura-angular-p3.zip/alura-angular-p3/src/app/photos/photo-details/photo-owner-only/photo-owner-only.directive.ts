import { Directive, ElementRef, Renderer } from "@angular/core";
import { Photo } from "../../photo/photo";
import { Input } from "@angular/core";
import { UserService } from "../../../core/user/user.service";
import { OnInit } from "@angular/core";

@Directive({
    selector: '[photoOwnerOnly]'
})
export class PhotoOwnerOnlyDirective implements OnInit{

    ngOnInit(): void {
        //diretiva q so exibe o elemento do dom (a imagem para remover foto), caso o user seja o dono da foto e 
        // possa remover
        this.userService
            .getUser()
            .subscribe(user => {
                // !user || user.id != this.ownedPhoto.userId -> estrategia , caso o usuario seja nulo.
                if(!user || user.id != this.ownedPhoto.userId){
                    this.renderer
                        .setElementStyle(this.element.nativeElement, 'display', 'none');
                }
            })
    }
    @Input() ownedPhoto : Photo;

    constructor(
        private element: ElementRef<any>,
        private renderer : Renderer,
        private userService: UserService
        
        ){

        }

}