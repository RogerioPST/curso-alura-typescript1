import { Injectable } from "@angular/core";


const KEY = 'authToken';

@Injectable({
    providedIn: 'root'
    
})
export class TokenService{

    hasToken(){
        //se esse cara eh nulo, o exclamação, troca p true e depois falso
        //truque p converter p booleano valor q pode vim nulo
        return !!this.getToken();

    }

    setToken(token){
        // guardando o token no localStorage..
        // window.localStorage.setItem('authToken', authToken);
        window.localStorage.setItem(KEY, token);
    }

    getToken(){
        return window.localStorage.getItem(KEY);
    }

    removeToken(){  
        window.localStorage.removeItem(KEY);
    }

}