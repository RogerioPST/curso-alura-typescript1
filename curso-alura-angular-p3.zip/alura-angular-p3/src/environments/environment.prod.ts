export const environment = {
  production: true,
  ApiUrl: 'http://endereco_producao'
};
