package br.com.casadocodigo.loja.models;

public enum TipoPreco {
	EBOOK, IMPRESSO, COMBO;

}
