package br.com.casadocodigo.loja.controllers;

import java.util.List;

import javax.persistence.NoResultException;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.casadocodigo.loja.daos.ProdutoDAO;
import br.com.casadocodigo.loja.infra.FileSaver;
import br.com.casadocodigo.loja.models.Produto;
import br.com.casadocodigo.loja.models.TipoPreco;
import br.com.casadocodigo.loja.validation.ProdutoValidation;

@Controller
@RequestMapping("/produtos")
public class ProdutosController {
	
	
	@Autowired //eh o spring q injeta o produtoDao p usarmos, mas soh se o spring conhecer	//para isso, colocar a anotacao no produtoDAo - @Repository
	private ProdutoDAO produtoDAO;
	
	
	@Autowired
	private FileSaver fileSaver;
	
	//Quando utilizamos o Validator do Spring, temos a possibilidade de configurar o controller para que utilize automaticamente o validador todas as vezes que for necessário validar a classe desejada, ou seja, a classe que precisa ser validada (anotada com @Valid). Vale lembrar que o uso do InitBinder é necessário para que seja possível essa validação automática.
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.addValidators(new ProdutoValidation());
		
	}
	
	@RequestMapping("/form")
	public ModelAndView form(Produto produto) {
		//quero enviar um objeto do modelo para a view; por isso, o uso abaixo;
		//no construtor tem o viewName "produtos/form" q eh o endereço /jsp p onde vai ser direcionado
		ModelAndView modelAndView = new ModelAndView("produtos/form");
		modelAndView.addObject("tipos", TipoPreco.values());
		return modelAndView;
	}
	
	//para validação, a ordem do BindingResult result importa demais no spring- BindingResult result vem primeiro 
	//Quando utilizamos o Validator do Spring, temos a possibilidade de configurar o controller para que utilize automaticamente o validador todas as vezes que for necessário validar a classe desejada, ou seja, a classe que precisa ser validada (anotada com @Valid). Vale lembrar que o uso do InitBinder é necessário para que seja possível essa validação automática.
	@RequestMapping(method=RequestMethod.POST)
	@CacheEvict(value="produtosHome", allEntries = true) //vai limpar o cache  criado para a home
	public ModelAndView grava(MultipartFile sumario,  @Valid Produto produto,BindingResult result, RedirectAttributes redirectAttributes ) {
		System.out.println("gravando produto: "+ produto);
		
		System.out.println(sumario.getOriginalFilename());
		
		String path  = fileSaver.write("arquivos-sumario", sumario);
		produto.setSumarioPath(path);
		
		
		
		//if (produto.getTitulo() == null || produto.getTitulo().isEmpty()) {
		//	return form();
		//}
		
		if (result.hasErrors()) {
			return form(produto);
		}
		
		produtoDAO.gravar(produto);
		//return "produtos/ok"; //procura por uma pagina ok.jsp
		ModelAndView modelAndView = new ModelAndView("redirect:produtos");
		redirectAttributes.addFlashAttribute("sucesso", "produto cadastrado com sucesso!");
		//modelAndView.addObject("sucesso", "produto cadastrado com sucesso!");
		return modelAndView;
		
	}
	
	@RequestMapping(method=RequestMethod.GET)
	public ModelAndView listar() {
		List<Produto> produtos = produtoDAO.listar();
		//quero enviar um objeto do modelo para a view; por isso, o uso abaixo;
		//no construtor tem o viewName "produtos/form" q eh o endereço /jsp p onde vai ser direcionado
		ModelAndView modelAndView = new ModelAndView("produtos/lista");
		modelAndView.addObject("produtos", produtos);
		return modelAndView;
	}
	
//	//o spring vai tratar as exceções do tipo noResultException
//	@ExceptionHandler(NoResultException.class)
//	public String trataDetalheNaoEcontrado(){
//	    return "error";
//	}
	
	@RequestMapping("/detalhe/{id}")
	public ModelAndView detalhe(@PathVariable("id") Integer id) {
		//quero enviar um objeto do modelo para a view; por isso, o uso abaixo;
		//no construtor tem o viewName "produtos/form" q eh o endereço /jsp p onde vai ser direcionado
		ModelAndView modelAndView = new ModelAndView("produtos/detalhe");
		Produto produto = produtoDAO.find(id);
		modelAndView.addObject("produto", produto);
		return modelAndView;
	}
	
	//com o metodo no appwebconfig - public ViewResolver contentNegotiationViewResolver(ContentNegotiationManager manager), n precisa desse codigo abaixo
//	@RequestMapping("/json/{id}")
//	@ResponseBody //transforma o retorno do nosso metodo para JSON, mas isso pq ja tem o jackson como lib do projeto
//	public Produto detalheJSON(@PathVariable("id") Integer id) {
//		return produtoDAO.find(id);
//		
//	}

}
